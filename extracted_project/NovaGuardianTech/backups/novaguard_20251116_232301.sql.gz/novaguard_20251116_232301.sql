--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (415ebe8)
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: domainkind; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.domainkind AS ENUM (
    'EXACT',
    'REGEX'
);


ALTER TYPE public.domainkind OWNER TO neondb_owner;

--
-- Name: domainstatus; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.domainstatus AS ENUM (
    'ACTIVE',
    'INACTIVE'
);


ALTER TYPE public.domainstatus OWNER TO neondb_owner;

--
-- Name: piholemode; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.piholemode AS ENUM (
    'NXDOMAIN',
    'NULL'
);


ALTER TYPE public.piholemode OWNER TO neondb_owner;

--
-- Name: userrole; Type: TYPE; Schema: public; Owner: neondb_owner
--

CREATE TYPE public.userrole AS ENUM (
    'ADMIN',
    'USER'
);


ALTER TYPE public.userrole OWNER TO neondb_owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO neondb_owner;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    actor_user_id integer,
    client_id integer,
    action character varying(255) NOT NULL,
    payload_json json,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO neondb_owner;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO neondb_owner;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: clients; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.clients (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.clients OWNER TO neondb_owner;

--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clients_id_seq OWNER TO neondb_owner;

--
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- Name: domain_rules; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.domain_rules (
    id integer NOT NULL,
    client_id integer NOT NULL,
    domain character varying(500) NOT NULL,
    kind public.domainkind NOT NULL,
    status public.domainstatus NOT NULL,
    reason text,
    created_by integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.domain_rules OWNER TO neondb_owner;

--
-- Name: domain_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.domain_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.domain_rules_id_seq OWNER TO neondb_owner;

--
-- Name: domain_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.domain_rules_id_seq OWNED BY public.domain_rules.id;


--
-- Name: ip_whitelist; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.ip_whitelist (
    id integer NOT NULL,
    client_id integer NOT NULL,
    ip_address character varying(45) NOT NULL,
    label character varying(255),
    created_by integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ip_whitelist OWNER TO neondb_owner;

--
-- Name: ip_whitelist_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.ip_whitelist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ip_whitelist_id_seq OWNER TO neondb_owner;

--
-- Name: ip_whitelist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.ip_whitelist_id_seq OWNED BY public.ip_whitelist.id;


--
-- Name: locations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.locations (
    id integer NOT NULL,
    client_id integer NOT NULL,
    label character varying(255) NOT NULL,
    public_ip character varying(45),
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.locations OWNER TO neondb_owner;

--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.locations_id_seq OWNER TO neondb_owner;

--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.locations_id_seq OWNED BY public.locations.id;


--
-- Name: pihole_instances; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.pihole_instances (
    id integer NOT NULL,
    client_id integer NOT NULL,
    container_name character varying(255) NOT NULL,
    upstream_dns1 character varying(45),
    upstream_dns2 character varying(45),
    mode public.piholemode NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    internal_ip character varying(45),
    public_ip character varying(45),
    dns_port integer DEFAULT 53,
    web_port integer,
    admin_password character varying(255),
    status character varying(50) DEFAULT 'unknown'::character varying
);


ALTER TABLE public.pihole_instances OWNER TO neondb_owner;

--
-- Name: pihole_instances_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.pihole_instances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pihole_instances_id_seq OWNER TO neondb_owner;

--
-- Name: pihole_instances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.pihole_instances_id_seq OWNED BY public.pihole_instances.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role public.userrole NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    client_id integer
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- Name: domain_rules id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.domain_rules ALTER COLUMN id SET DEFAULT nextval('public.domain_rules_id_seq'::regclass);


--
-- Name: ip_whitelist id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ip_whitelist ALTER COLUMN id SET DEFAULT nextval('public.ip_whitelist_id_seq'::regclass);


--
-- Name: locations id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.locations ALTER COLUMN id SET DEFAULT nextval('public.locations_id_seq'::regclass);


--
-- Name: pihole_instances id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.pihole_instances ALTER COLUMN id SET DEFAULT nextval('public.pihole_instances_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.alembic_version (version_num) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.audit_logs (id, actor_user_id, client_id, action, payload_json, created_at) FROM stdin;
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.clients (id, name, slug, is_active, created_at) FROM stdin;
1	Empresa Demo	empresa-demo	t	2025-11-13 00:03:55.642812+00
2	Cliente Teste Atualizado	cliente-teste	f	2025-11-13 01:58:28.861898+00
\.


--
-- Data for Name: domain_rules; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.domain_rules (id, client_id, domain, kind, status, reason, created_by, created_at, updated_at) FROM stdin;
5	1	test.com	EXACT	ACTIVE	\N	1	2025-11-16 23:11:48.825088+00	2025-11-16 23:11:48.825088+00
\.


--
-- Data for Name: ip_whitelist; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.ip_whitelist (id, client_id, ip_address, label, created_by, created_at) FROM stdin;
1	2	192.168.1.100	Teste IP	1	2025-11-13 01:58:49.159098+00
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.locations (id, client_id, label, public_ip, is_active, created_at) FROM stdin;
1	1	Escritório Central	203.0.113.10	t	2025-11-13 00:03:55.753679+00
\.


--
-- Data for Name: pihole_instances; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.pihole_instances (id, client_id, container_name, upstream_dns1, upstream_dns2, mode, created_at, internal_ip, public_ip, dns_port, web_port, admin_password, status) FROM stdin;
1	1	pihole_cliente_demo	1.1.1.1	8.8.8.8	NXDOMAIN	2025-11-13 00:03:55.886227+00	\N	\N	53	\N	\N	unknown
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, name, email, password_hash, role, created_at, updated_at, client_id) FROM stdin;
1	Administrador	admin@novaguardian.com	$2b$12$P2XF59/zUHc3ugPT5JuTIeCYhaSbLqjLFlxrhz22J2YLqytOqSKeG	ADMIN	2025-11-13 00:03:54.969644+00	2025-11-13 00:09:11.689725+00	1
2	Usuário Demo	user@example.com	$2b$12$sQgRel9DeLt2mgsUl7xEz.bLN5Yi2YwPjBP4HaIoYRcBczk8JlrIS	USER	2025-11-13 00:03:54.969644+00	2025-11-13 00:09:11.83858+00	1
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.clients_id_seq', 2, true);


--
-- Name: domain_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.domain_rules_id_seq', 5, true);


--
-- Name: ip_whitelist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.ip_whitelist_id_seq', 1, true);


--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.locations_id_seq', 1, true);


--
-- Name: pihole_instances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.pihole_instances_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: domain_rules domain_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.domain_rules
    ADD CONSTRAINT domain_rules_pkey PRIMARY KEY (id);


--
-- Name: ip_whitelist ip_whitelist_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ip_whitelist
    ADD CONSTRAINT ip_whitelist_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: pihole_instances pihole_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.pihole_instances
    ADD CONSTRAINT pihole_instances_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_logs_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_audit_logs_id ON public.audit_logs USING btree (id);


--
-- Name: ix_clients_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_clients_id ON public.clients USING btree (id);


--
-- Name: ix_clients_slug; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX ix_clients_slug ON public.clients USING btree (slug);


--
-- Name: ix_domain_rules_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_domain_rules_id ON public.domain_rules USING btree (id);


--
-- Name: ix_ip_whitelist_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_ip_whitelist_id ON public.ip_whitelist USING btree (id);


--
-- Name: ix_locations_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_locations_id ON public.locations USING btree (id);


--
-- Name: ix_pihole_instances_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_pihole_instances_id ON public.pihole_instances USING btree (id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: audit_logs audit_logs_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id);


--
-- Name: audit_logs audit_logs_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: domain_rules domain_rules_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.domain_rules
    ADD CONSTRAINT domain_rules_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: domain_rules domain_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.domain_rules
    ADD CONSTRAINT domain_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: ip_whitelist ip_whitelist_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ip_whitelist
    ADD CONSTRAINT ip_whitelist_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: ip_whitelist ip_whitelist_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ip_whitelist
    ADD CONSTRAINT ip_whitelist_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: locations locations_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: pihole_instances pihole_instances_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.pihole_instances
    ADD CONSTRAINT pihole_instances_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: users users_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

