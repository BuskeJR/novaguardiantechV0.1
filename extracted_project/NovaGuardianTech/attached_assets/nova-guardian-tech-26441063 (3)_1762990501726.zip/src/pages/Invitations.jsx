import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { UserPlus, Search, Mail, Ban } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { Alert, AlertDescription } from "@/components/ui/alert";
import InviteUserDialog from "../components/invitations/InviteUserDialog";
import InvitationsList from "../components/invitations/InvitationsList";

export default function InvitationsPage() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [showInviteDialog, setShowInviteDialog] = useState(false);

  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: invitations = [], isLoading } = useQuery({
    queryKey: ['invitations', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.Invitation.filter({ tenantId: user.tenantId }, '-created_date');
    },
    enabled: !!user?.tenantId && user?.role === 'admin',
    initialData: [],
  });

  const sendInviteMutation = useMutation({
    mutationFn: async ({ email, role }) => {
      // Generate unique token
      const token = `invite_${Date.now()}_${Math.random().toString(36).substr(2, 16)}`;
      
      // Set expiration to 7 days from now
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 7);

      // Create invitation
      const invitation = await base44.entities.Invitation.create({
        email,
        role,
        token,
        tenantId: user.tenantId,
        invitedBy: user.email,
        status: "pending",
        expiresAt: expiresAt.toISOString(),
      });

      // Generate invite link
      const inviteUrl = `${window.location.origin}${window.location.pathname}#/accept-invite?token=${token}`;

      // Send email
      await base44.integrations.Core.SendEmail({
        from_name: "NovaGuardian",
        to: email,
        subject: `Convite para NovaGuardian - ${user.company || 'Sua Organização'}`,
        body: `
Olá!

Você foi convidado por ${user.full_name} (${user.email}) para se juntar ao ${user.company || 'NovaGuardian'}.

Seu papel será: ${role === 'admin' ? 'Administrador' : 'Usuário'}

Para aceitar o convite, clique no link abaixo:
${inviteUrl}

Este convite expira em 7 dias.

Atenciosamente,
Equipe NovaGuardian
        `.trim()
      });

      // Log the action
      await base44.entities.BlockLog.create({
        action: "user_created",
        userId: user.id,
        userEmail: user.email,
        tenantId: user.tenantId,
        details: { 
          action: "invitation_sent",
          invitee_email: email,
          role: role
        },
      });

      return invitation;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['invitations'] });
      toast.success("✓ Convite enviado com sucesso!");
      setShowInviteDialog(false);
    },
    onError: (error) => {
      toast.error("✗ Erro ao enviar convite");
      console.error("Error sending invite:", error);
    },
  });

  const resendInviteMutation = useMutation({
    mutationFn: async (invitation) => {
      // Generate new token and expiration
      const token = `invite_${Date.now()}_${Math.random().toString(36).substr(2, 16)}`;
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 7);

      // Update invitation
      await base44.entities.Invitation.update(invitation.id, {
        token,
        expiresAt: expiresAt.toISOString(),
        status: "pending",
      });

      // Generate new invite link
      const inviteUrl = `${window.location.origin}${window.location.pathname}#/accept-invite?token=${token}`;

      // Resend email
      await base44.integrations.Core.SendEmail({
        from_name: "NovaGuardian",
        to: invitation.email,
        subject: `Novo Convite para NovaGuardian - ${user.company || 'Sua Organização'}`,
        body: `
Olá!

Você recebeu um novo convite de ${user.full_name} (${user.email}) para se juntar ao ${user.company || 'NovaGuardian'}.

Seu papel será: ${invitation.role === 'admin' ? 'Administrador' : 'Usuário'}

Para aceitar o convite, clique no link abaixo:
${inviteUrl}

Este convite expira em 7 dias.

Atenciosamente,
Equipe NovaGuardian
        `.trim()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['invitations'] });
      toast.success("✓ Convite reenviado!");
    },
    onError: () => {
      toast.error("✗ Erro ao reenviar convite");
    },
  });

  const cancelInviteMutation = useMutation({
    mutationFn: async (invitationId) => {
      await base44.entities.Invitation.update(invitationId, {
        status: "expired"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['invitations'] });
      toast.success("✓ Convite cancelado");
    },
    onError: () => {
      toast.error("✗ Erro ao cancelar convite");
    },
  });

  const filteredInvitations = invitations.filter(inv =>
    inv.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    inv.invitedBy?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (user?.role !== 'admin') {
    return (
      <div className="p-4 md:p-8 min-h-screen">
        <div className="max-w-7xl mx-auto">
          <Alert className="bg-red-500/10 border-red-500/20">
            <Ban className="h-4 w-4 text-red-500" />
            <AlertDescription className="text-red-400">
              Você não tem permissão para acessar esta página. Apenas administradores podem gerenciar convites.
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-purple-500 rounded-full opacity-5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-[#1284e1] rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Mail className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Convites</h1>
              <p className="text-gray-400">Convide usuários para sua organização</p>
            </div>
          </div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              onClick={() => setShowInviteDialog(true)}
              className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white shadow-lg shadow-purple-500/30"
            >
              <UserPlus className="w-4 h-4 mr-2" />
              Convidar Usuário
            </Button>
          </motion.div>
        </motion.div>

        <Card className="bg-[#01081c] border-[#1a2847] mb-6">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Search className="w-5 h-5" />
              Buscar Convites
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Buscar por email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-[#1a2847] border-[#1a2847] text-white"
              />
            </div>
          </CardContent>
        </Card>

        <InvitationsList
          invitations={filteredInvitations}
          isLoading={isLoading}
          onResend={(invitation) => resendInviteMutation.mutate(invitation)}
          onCancel={(invitationId) => cancelInviteMutation.mutate(invitationId)}
        />

        <InviteUserDialog
          open={showInviteDialog}
          onClose={() => setShowInviteDialog(false)}
          onInvite={(data) => sendInviteMutation.mutate(data)}
          isLoading={sendInviteMutation.isPending}
        />
      </div>
    </div>
  );
}