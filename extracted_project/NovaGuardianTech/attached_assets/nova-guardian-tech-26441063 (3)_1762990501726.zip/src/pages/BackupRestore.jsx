import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Upload, Database, AlertCircle, CheckCircle, FileJson } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function BackupRestorePage() {
  const [user, setUser] = useState(null);
  const [importing, setImporting] = useState(false);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: domains = [] } = useQuery({
    queryKey: ['domains', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.Domain.filter({ tenantId: user.tenantId });
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const { data: groups = [] } = useQuery({
    queryKey: ['groups', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.DomainGroup.filter({ tenantId: user.tenantId });
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const { data: whitelist = [] } = useQuery({
    queryKey: ['whitelist', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.Whitelist.filter({ tenantId: user.tenantId });
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const { data: schedules = [] } = useQuery({
    queryKey: ['schedules', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.BlockSchedule.filter({ tenantId: user.tenantId });
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const exportFullBackup = () => {
    const backup = {
      version: "1.0",
      exported_at: new Date().toISOString(),
      tenant_id: user.tenantId,
      data: {
        domains: domains.map(d => ({
          domain: d.domain,
          category: d.category,
          isActive: d.isActive,
          description: d.description,
        })),
        groups: groups.map(g => ({
          name: g.name,
          description: g.description,
          color: g.color,
          icon: g.icon,
        })),
        whitelist: whitelist.map(w => ({
          domain: w.domain,
          description: w.description,
          isActive: w.isActive,
        })),
        schedules: schedules.map(s => ({
          name: s.name,
          daysOfWeek: s.daysOfWeek,
          startTime: s.startTime,
          endTime: s.endTime,
          action: s.action,
        })),
      },
      stats: {
        total_domains: domains.length,
        total_groups: groups.length,
        total_whitelist: whitelist.length,
        total_schedules: schedules.length,
      }
    };

    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `novaguardian_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    
    toast.success("✓ Backup exportado com sucesso!");
  };

  const exportDomainsOnly = () => {
    const domainsList = domains.map(d => d.domain).join('\n');
    const blob = new Blob([domainsList], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `domains_${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    
    toast.success("✓ Lista de domínios exportada!");
  };

  const handleImportBackup = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setImporting(true);
    const reader = new FileReader();
    
    reader.onload = async (e) => {
      try {
        const backup = JSON.parse(e.target.result);
        
        if (!backup.version || !backup.data) {
          throw new Error("Formato de backup inválido");
        }

        // Import domains
        let imported = 0;
        for (const domain of backup.data.domains) {
          try {
            await base44.entities.Domain.create({
              ...domain,
              tenantId: user.tenantId,
              addedBy: user.email,
            });
            imported++;
          } catch (error) {
            console.error("Error importing domain:", domain.domain, error);
          }
        }

        // Import whitelist
        for (const item of backup.data.whitelist) {
          try {
            await base44.entities.Whitelist.create({
              ...item,
              tenantId: user.tenantId,
              addedBy: user.email,
            });
          } catch (error) {
            console.error("Error importing whitelist:", item.domain, error);
          }
        }

        toast.success(`✓ Backup restaurado! ${imported} domínios importados`);
        window.location.reload();
      } catch (error) {
        toast.error("✗ Erro ao importar backup: " + error.message);
      } finally {
        setImporting(false);
      }
    };

    reader.readAsText(file);
  };

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-purple-500 rounded-full opacity-5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-blue-500 rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-5xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Database className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Backup & Restauração</h1>
              <p className="text-gray-400">Exporte e importe suas configurações</p>
            </div>
          </div>
        </motion.div>

        <Alert className="bg-blue-500/10 border-blue-500/30 mb-6">
          <AlertCircle className="h-4 w-4 text-blue-400" />
          <AlertDescription className="text-blue-400">
            <strong>Dica:</strong> Faça backups regulares para não perder suas configurações.
            O backup inclui domínios, grupos, whitelist e agendamentos.
          </AlertDescription>
        </Alert>

        <div className="grid md:grid-cols-2 gap-6 mb-6">
          {/* Export Section */}
          <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Download className="w-5 h-5 text-blue-400" />
                Exportar Dados
              </CardTitle>
              <CardDescription className="text-gray-400">
                Faça backup das suas configurações
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 mb-6">
                <StatCard label="Domínios" value={domains.length} />
                <StatCard label="Grupos" value={groups.length} />
                <StatCard label="Whitelist" value={whitelist.length} />
                <StatCard label="Agendamentos" value={schedules.length} />
              </div>

              <Button
                onClick={exportFullBackup}
                className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
              >
                <FileJson className="w-4 h-4 mr-2" />
                Backup Completo (JSON)
              </Button>

              <Button
                onClick={exportDomainsOnly}
                variant="outline"
                className="w-full bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
              >
                <Download className="w-4 h-4 mr-2" />
                Apenas Domínios (TXT)
              </Button>
            </CardContent>
          </Card>

          {/* Import Section */}
          <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Upload className="w-5 h-5 text-green-400" />
                Restaurar Backup
              </CardTitle>
              <CardDescription className="text-gray-400">
                Importe configurações de um backup
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert className="bg-yellow-500/10 border-yellow-500/30">
                <AlertCircle className="h-4 w-4 text-yellow-400" />
                <AlertDescription className="text-yellow-400 text-sm">
                  <strong>Atenção:</strong> A importação irá adicionar novos itens às suas configurações existentes.
                  Domínios duplicados serão ignorados.
                </AlertDescription>
              </Alert>

              <label className="block">
                <div className="flex items-center justify-center w-full h-40 border-2 border-dashed border-[#1284e1]/30 rounded-lg hover:border-[#1284e1]/60 cursor-pointer transition-colors bg-[#1a2847]/30">
                  <div className="text-center">
                    <Upload className="w-12 h-12 mx-auto mb-3 text-blue-400" />
                    <p className="text-white font-medium mb-1">
                      {importing ? "Importando..." : "Clique para selecionar"}
                    </p>
                    <p className="text-sm text-gray-400">
                      Arquivo JSON de backup
                    </p>
                  </div>
                </div>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportBackup}
                  disabled={importing}
                  className="hidden"
                />
              </label>

              <div className="space-y-2">
                <p className="text-sm text-gray-400">Formato esperado:</p>
                <code className="block p-3 bg-[#1a2847] rounded text-xs text-gray-300 font-mono overflow-x-auto">
                  {`{
  "version": "1.0",
  "data": {
    "domains": [...],
    "groups": [...],
    "whitelist": [...]
  }
}`}
                </code>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Best Practices */}
        <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-400" />
              Boas Práticas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3 text-gray-300">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                <span>Faça backups semanais das suas configurações</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                <span>Armazene os backups em local seguro (nuvem ou disco externo)</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                <span>Teste a restauração periodicamente</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                <span>Mantenha múltiplas versões de backup</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ label, value }) {
  return (
    <div className="p-4 bg-[#1a2847] rounded-lg">
      <p className="text-gray-400 text-sm mb-1">{label}</p>
      <p className="text-2xl font-bold text-white">{value}</p>
    </div>
  );
}