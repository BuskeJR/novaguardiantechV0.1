import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, Plus, Search } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import ScheduleList from "../components/schedules/ScheduleList";
import AddScheduleDialog from "../components/schedules/AddScheduleDialog";

export default function SchedulesPage() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingSchedule, setEditingSchedule] = useState(null);

  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: schedules = [], isLoading } = useQuery({
    queryKey: ['schedules', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.BlockSchedule.filter({ tenantId: user.tenantId }, '-created_date');
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const { data: domains = [] } = useQuery({
    queryKey: ['domains', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.Domain.filter({ tenantId: user.tenantId });
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const createScheduleMutation = useMutation({
    mutationFn: async (data) => {
      const schedule = await base44.entities.BlockSchedule.create({
        ...data,
        tenantId: user.tenantId,
        createdBy: user.email,
      });

      await base44.entities.BlockLog.create({
        action: "settings_changed",
        userId: user.id,
        userEmail: user.email,
        tenantId: user.tenantId,
        details: { action: "schedule_created", schedule_name: data.name },
      });

      return schedule;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['schedules'] });
      toast.success("✓ Agendamento criado!");
      setShowAddDialog(false);
      setEditingSchedule(null);
    },
    onError: () => {
      toast.error("✗ Erro ao criar agendamento");
    },
  });

  const updateScheduleMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.BlockSchedule.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['schedules'] });
      toast.success("✓ Agendamento atualizado!");
      setShowAddDialog(false);
      setEditingSchedule(null);
    },
    onError: () => {
      toast.error("✗ Erro ao atualizar agendamento");
    },
  });

  const toggleScheduleMutation = useMutation({
    mutationFn: async ({ id, isActive }) => {
      return await base44.entities.BlockSchedule.update(id, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['schedules'] });
      toast.success("✓ Status atualizado!");
    },
  });

  const deleteScheduleMutation = useMutation({
    mutationFn: async (id) => {
      await base44.entities.BlockSchedule.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['schedules'] });
      toast.success("✓ Agendamento removido!");
    },
    onError: () => {
      toast.error("✗ Erro ao remover agendamento");
    },
  });

  const filteredSchedules = schedules.filter(schedule =>
    schedule.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-indigo-500 rounded-full opacity-5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-[#1284e1] rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Clock className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Agendamento de Bloqueios</h1>
              <p className="text-gray-400">Configure bloqueios por horário e dia da semana</p>
            </div>
          </div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              onClick={() => {
                setEditingSchedule(null);
                setShowAddDialog(true);
              }}
              className="bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white shadow-lg shadow-indigo-500/30"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Agendamento
            </Button>
          </motion.div>
        </motion.div>

        <Card className="bg-[#01081c] border-[#1a2847] mb-6">
          <CardHeader>
            <CardTitle className="text-white">Buscar</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Buscar agendamento..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-[#1a2847] border-[#1a2847] text-white"
              />
            </div>
          </CardContent>
        </Card>

        <ScheduleList
          schedules={filteredSchedules}
          domains={domains}
          isLoading={isLoading}
          onEdit={(schedule) => {
            setEditingSchedule(schedule);
            setShowAddDialog(true);
          }}
          onToggle={(id, isActive) => toggleScheduleMutation.mutate({ id, isActive })}
          onDelete={(id) => deleteScheduleMutation.mutate(id)}
        />

        <AddScheduleDialog
          open={showAddDialog}
          onClose={() => {
            setShowAddDialog(false);
            setEditingSchedule(null);
          }}
          schedule={editingSchedule}
          domains={domains}
          onSave={(data) => {
            if (editingSchedule) {
              updateScheduleMutation.mutate({ id: editingSchedule.id, data });
            } else {
              createScheduleMutation.mutate(data);
            }
          }}
          isLoading={createScheduleMutation.isPending || updateScheduleMutation.isPending}
        />
      </div>
    </div>
  );
}