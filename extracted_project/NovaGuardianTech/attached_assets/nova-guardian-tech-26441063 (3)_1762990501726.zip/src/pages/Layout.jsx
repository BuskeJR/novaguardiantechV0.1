

import React, { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import {
  LayoutDashboard,
  Shield,
  ScrollText,
  Settings,
  Users,
  Mail,
  LogOut,
  Menu,
  ChevronDown,
  Activity,
  BarChart,
  CheckCircle,
  Bell
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import NotificationsPanel from "./components/notifications/NotificationsPanel";
import ThemeToggle from "./components/settings/ThemeToggle";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showNotifications, setShowNotifications] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  // Pages that don't require authentication
  const publicPages = ["AcceptInvite"];

  useEffect(() => {
    if (!publicPages.includes(currentPageName)) {
      loadUser();
    } else {
      setLoading(false);
    }
  }, [currentPageName]);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      // Check if user needs onboarding (except on Onboarding page itself)
      if (!currentUser.onboarding_completed && currentPageName !== "Onboarding") {
        navigate(createPageUrl("Onboarding"));
      }

      // Load unread notifications count
      loadUnreadCount(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    } finally {
      setLoading(false);
    }
  };

  const loadUnreadCount = async (currentUser) => {
    try {
      const notifications = await base44.entities.Notification.filter({ 
        userId: currentUser.id,
        isRead: false
      });
      setUnreadCount(notifications.length);
    } catch (error) {
      console.error("Error loading notifications:", error);
    }
  };

  const handleLogout = () => {
    base44.auth.logout();
  };

  const navigationItems = [
    {
      title: "Dashboard",
      url: createPageUrl("Dashboard"),
      icon: LayoutDashboard,
      roles: ["admin", "user"],
    },
    {
      title: "Rede",
      url: createPageUrl("NetworkDashboard"),
      icon: Activity,
      roles: ["admin", "user"],
    },
    {
      title: "Domínios",
      url: createPageUrl("Domains"),
      icon: Shield,
      roles: ["admin", "user"],
    },
    {
      title: "Grupos",
      url: createPageUrl("Groups"),
      icon: Activity,
      roles: ["admin", "user"],
    },
    {
      title: "Lista Branca",
      url: createPageUrl("Whitelist"),
      icon: CheckCircle,
      roles: ["admin", "user"],
    },
    {
      title: "Agendamentos",
      url: createPageUrl("Schedules"),
      icon: Activity,
      roles: ["admin", "user"],
    },
    {
      title: "Alertas",
      url: createPageUrl("Alerts"),
      icon: Bell,
      roles: ["admin", "user"],
    },
    {
      title: "Relatórios",
      url: createPageUrl("Reports"),
      icon: BarChart,
      roles: ["admin", "user"],
    },
    {
      title: "Logs",
      url: createPageUrl("Logs"),
      icon: ScrollText,
      roles: ["admin", "user"],
    },
    {
      title: "Suporte",
      url: createPageUrl("Support"),
      icon: Activity,
      roles: ["admin", "user"],
    },
  ];

  const resourcesItems = [
    {
      title: "Teste DNS",
      url: createPageUrl("DNSTest"),
      icon: Activity,
      roles: ["admin", "user"],
    },
    {
      title: "Guia DNS",
      url: createPageUrl("DnsGuide"),
      icon: Activity,
      roles: ["admin", "user"],
    },
    {
      title: "QR Config",
      url: createPageUrl("QrConfig"),
      icon: Activity,
      roles: ["admin", "user"],
    },
    {
      title: "API Docs",
      url: createPageUrl("ApiDocs"),
      icon: Activity,
      roles: ["admin", "user"],
    },
    {
      title: "App Mobile",
      url: createPageUrl("MobileApp"),
      icon: Activity,
      roles: ["admin", "user"],
    },
    {
      title: "Backup",
      url: createPageUrl("BackupRestore"),
      icon: Activity,
      roles: ["admin", "user"],
    },
  ];

  const adminItems = [
    {
      title: "Gerenciar Usuários",
      url: createPageUrl("AdminUsers"),
      icon: Users,
      roles: ["admin"],
    },
    {
      title: "Convites",
      url: createPageUrl("Invitations"),
      icon: Mail,
      roles: ["admin"],
    },
    {
      title: "Sistema",
      url: createPageUrl("SystemConfig"),
      icon: Settings,
      roles: ["admin"],
    },
    {
      title: "Assinatura",
      url: createPageUrl("Billing"),
      icon: Activity,
      roles: ["admin"],
    },
  ];

  const filteredNavigation = navigationItems.filter(item =>
    item.roles.includes(user?.role || "user")
  );

  const filteredResources = resourcesItems.filter(item =>
    item.roles.includes(user?.role || "user")
  );

  const filteredAdmin = adminItems.filter(item =>
    item.roles.includes(user?.role || "user")
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-[#01081c] flex items-center justify-center">
        <div className="flex items-center gap-3 text-white">
          <Activity className="w-6 h-6 animate-spin" />
          <span>Carregando...</span>
        </div>
      </div>
    );
  }

  // Don't show layout on public pages
  if (publicPages.includes(currentPageName)) {
    return children;
  }

  // Don't show layout on Onboarding page
  if (currentPageName === "Onboarding") {
    return children;
  }

  return (
    <SidebarProvider>
      <style>{`
        :root {
          --sidebar-background: #01081c;
          --sidebar-foreground: #ffffff;
          --sidebar-primary: #1284e1;
          --sidebar-primary-foreground: #ffffff;
          --sidebar-accent: #1a1f3a;
          --sidebar-accent-foreground: #ffffff;
          --sidebar-border: #1a2847;
        }
      `}</style>
      
      <div className="min-h-screen flex w-full bg-[#0a1128]">
        <Sidebar className="border-r border-[#1a2847]" style={{ background: '#01081c' }}>
          <SidebarHeader className="border-b border-[#1a2847] p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#1284e1] to-[#0d5fb8] rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/20">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-white text-lg">NovaGuardian</h2>
                <p className="text-xs text-gray-400">DNS Protection</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-3">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-medium text-gray-400 uppercase tracking-wider px-3 py-2">
                Navegação
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {filteredNavigation.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`hover:bg-[#1a2847] hover:text-white transition-all duration-200 rounded-lg mb-1 ${
                          location.pathname === item.url ? 'bg-[#1284e1] text-white shadow-lg shadow-blue-500/20' : 'text-gray-300'
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-3 py-2.5">
                          <item.icon className="w-4 h-4" />
                          <span className="font-medium">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-medium text-gray-400 uppercase tracking-wider px-3 py-2 mt-4">
                Recursos
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {filteredResources.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`hover:bg-[#1a2847] hover:text-white transition-all duration-200 rounded-lg mb-1 ${
                          location.pathname === item.url ? 'bg-[#1284e1] text-white shadow-lg shadow-blue-500/20' : 'text-gray-300'
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-3 py-2.5">
                          <item.icon className="w-4 h-4" />
                          <span className="font-medium">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            {filteredAdmin.length > 0 && (
              <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-medium text-gray-400 uppercase tracking-wider px-3 py-2 mt-4">
                  Administração
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    {filteredAdmin.map((item) => (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton 
                          asChild 
                          className={`hover:bg-[#1a2847] hover:text-white transition-all duration-200 rounded-lg mb-1 ${
                            location.pathname === item.url ? 'bg-[#1284e1] text-white shadow-lg shadow-blue-500/20' : 'text-gray-300'
                          }`}
                        >
                          <Link to={item.url} className="flex items-center gap-3 px-3 py-2.5">
                            <item.icon className="w-4 h-4" />
                            <span className="font-medium">{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    ))}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            )}

            <div className="px-3 py-2 mt-4">
              <Link 
                to={createPageUrl("Settings")}
                className={`flex items-center gap-3 px-3 py-2.5 text-gray-300 hover:bg-[#1a2847] hover:text-white transition-all duration-200 rounded-lg ${
                  location.pathname === createPageUrl("Settings") ? 'bg-[#1284e1] text-white shadow-lg shadow-blue-500/20' : ''
                }`}
              >
                <Settings className="w-4 h-4" />
                <span className="font-medium">Configurações</span>
              </Link>
            </div>
          </SidebarContent>

          <SidebarFooter className="border-t border-[#1a2847] p-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  className="w-full justify-start hover:bg-[#1a2847] text-white px-3 py-6"
                >
                  <div className="flex items-center gap-3 w-full">
                    <div className="w-9 h-9 bg-gradient-to-br from-[#1284e1] to-[#0d5fb8] rounded-full flex items-center justify-center text-white font-semibold text-sm">
                      {user?.full_name?.charAt(0).toUpperCase() || "U"}
                    </div>
                    <div className="flex-1 text-left min-w-0">
                      <p className="font-medium text-sm truncate">{user?.full_name || "Usuário"}</p>
                      <p className="text-xs text-gray-400 truncate">{user?.email}</p>
                    </div>
                    <ChevronDown className="w-4 h-4 text-gray-400" />
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 bg-[#01081c] border-[#1a2847] text-white" align="end">
                <DropdownMenuLabel>
                  <div className="flex flex-col gap-1">
                    <span className="font-medium">{user?.full_name}</span>
                    <span className="text-xs text-gray-400 font-normal">{user?.email}</span>
                    {user?.role === 'admin' && (
                      <Badge className="bg-[#1284e1] text-white px-2 py-0.5 rounded mt-1 w-fit">Admin</Badge>
                    )}
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-[#1a2847]" />
                <DropdownMenuItem 
                  onClick={() => navigate(createPageUrl("Settings"))}
                  className="hover:bg-[#1a2847] cursor-pointer"
                >
                  <Settings className="w-4 h-4 mr-2" />
                  Configurações
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={handleLogout}
                  className="hover:bg-[#1a2847] cursor-pointer text-red-400"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sair
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-[#01081c] border-b border-[#1a2847] px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4 lg:hidden">
                <SidebarTrigger className="text-white hover:bg-[#1a2847] p-2 rounded-lg transition-colors duration-200">
                  <Menu className="w-5 h-5" />
                </SidebarTrigger>
                <h1 className="text-lg font-semibold text-white">NovaGuardian</h1>
              </div>
              
              <div className="ml-auto flex items-center gap-2">
                <ThemeToggle />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative text-white hover:bg-[#1a2847]"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <Badge className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center p-0 bg-red-500 text-white text-xs">
                      {unreadCount}
                    </Badge>
                  )}
                </Button>
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-auto bg-[#0a1128] relative">
            {children}
            
            {/* Notifications Panel */}
            {showNotifications && (
              <NotificationsPanel
                user={user}
                onClose={() => setShowNotifications(false)}
                onUpdateCount={(count) => setUnreadCount(count)}
              />
            )}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}

