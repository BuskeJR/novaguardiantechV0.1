import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, Zap, Users, TrendingUp, Server, Clock, Globe } from "lucide-react";
import { motion } from "framer-motion";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts";
import { format, subHours } from "date-fns";

export default function NetworkDashboardPage() {
  const [user, setUser] = useState(null);
  const [liveData, setLiveData] = useState([]);

  useEffect(() => {
    loadUser();
    // Simulate real-time data updates
    const interval = setInterval(() => {
      const newDataPoint = {
        time: format(new Date(), 'HH:mm:ss'),
        queries: Math.floor(Math.random() * 50) + 100,
        blocked: Math.floor(Math.random() * 20) + 10,
        allowed: Math.floor(Math.random() * 80) + 90,
      };
      setLiveData(prev => [...prev.slice(-19), newDataPoint]);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: logs = [] } = useQuery({
    queryKey: ['logs', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.BlockLog.filter({ tenantId: user.tenantId }, '-created_date', 500);
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const { data: domains = [] } = useQuery({
    queryKey: ['domains', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.Domain.filter({ tenantId: user.tenantId });
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  // Calculate queries per hour for last 24h
  const queriesPerHour = Array.from({ length: 24 }, (_, i) => {
    const hour = subHours(new Date(), 23 - i);
    const hourLogs = logs.filter(log => {
      const logDate = new Date(log.created_date);
      return logDate.getHours() === hour.getHours();
    });
    return {
      hour: format(hour, 'HH:00'),
      total: hourLogs.length,
      blocked: hourLogs.filter(l => l.action === 'domain_blocked').length,
      allowed: hourLogs.length - hourLogs.filter(l => l.action === 'domain_blocked').length,
    };
  });

  // Category performance radar
  const categoryPerformance = domains.reduce((acc, domain) => {
    const cat = domain.category || 'other';
    const existing = acc.find(item => item.category === cat);
    if (existing) {
      existing.blocks += domain.blockCount || 0;
      existing.domains += 1;
    } else {
      acc.push({
        category: cat.replace(/_/g, ' '),
        blocks: domain.blockCount || 0,
        domains: 1,
      });
    }
    return acc;
  }, []);

  // Active devices simulation
  const activeDevices = [
    { name: 'Desktop', count: 12, percentage: 40 },
    { name: 'Mobile', count: 15, percentage: 50 },
    { name: 'Tablet', count: 3, percentage: 10 },
  ];

  const totalQueries = logs.length;
  const totalBlocked = logs.filter(l => l.action === 'domain_blocked').length;
  const blockRate = totalQueries > 0 ? ((totalBlocked / totalQueries) * 100).toFixed(1) : 0;
  const avgQueriesPerHour = (totalQueries / 24).toFixed(0);

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-cyan-500 rounded-full opacity-5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-500 rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Dashboard de Rede</h1>
              <p className="text-gray-400">Monitoramento em tempo real</p>
            </div>
          </div>
        </motion.div>

        {/* Real-time Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Queries Total"
            value={totalQueries}
            icon={Globe}
            color="blue"
            trend={`${avgQueriesPerHour}/h`}
          />
          <MetricCard
            title="Taxa de Bloqueio"
            value={`${blockRate}%`}
            icon={TrendingUp}
            color="red"
            trend={`${totalBlocked} bloqueados`}
          />
          <MetricCard
            title="Dispositivos Ativos"
            value={activeDevices.reduce((sum, d) => sum + d.count, 0)}
            icon={Users}
            color="green"
            trend="Online agora"
          />
          <MetricCard
            title="Uptime"
            value="99.9%"
            icon={Server}
            color="purple"
            trend="30 dias"
          />
        </div>

        {/* Real-time Graph */}
        <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] mb-6">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-cyan-400" />
              Queries em Tempo Real
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={liveData}>
                <defs>
                  <linearGradient id="colorQueries" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorBlocked" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a2847" />
                <XAxis dataKey="time" stroke="#9ca3af" fontSize={12} />
                <YAxis stroke="#9ca3af" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#01081c',
                    border: '1px solid #1a2847',
                    borderRadius: '8px',
                    color: '#fff'
                  }}
                />
                <Area type="monotone" dataKey="queries" stroke="#06b6d4" fillOpacity={1} fill="url(#colorQueries)" />
                <Area type="monotone" dataKey="blocked" stroke="#ef4444" fillOpacity={1} fill="url(#colorBlocked)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-2 gap-6 mb-6">
          {/* Queries per Hour */}
          <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Clock className="w-5 h-5 text-blue-400" />
                Queries por Hora (24h)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={queriesPerHour}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1a2847" />
                  <XAxis dataKey="hour" stroke="#9ca3af" fontSize={12} />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#01081c',
                      border: '1px solid #1a2847',
                      borderRadius: '8px',
                      color: '#fff'
                    }}
                  />
                  <Line type="monotone" dataKey="total" stroke="#1284e1" strokeWidth={2} name="Total" />
                  <Line type="monotone" dataKey="blocked" stroke="#ef4444" strokeWidth={2} name="Bloqueados" />
                  <Line type="monotone" dataKey="allowed" stroke="#10b981" strokeWidth={2} name="Permitidos" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Category Radar */}
          <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Activity className="w-5 h-5 text-purple-400" />
                Performance por Categoria
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <RadarChart data={categoryPerformance}>
                  <PolarGrid stroke="#1a2847" />
                  <PolarAngleAxis dataKey="category" stroke="#9ca3af" fontSize={12} />
                  <PolarRadiusAxis stroke="#9ca3af" />
                  <Radar name="Bloqueios" dataKey="blocks" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.6} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#01081c',
                      border: '1px solid #1a2847',
                      borderRadius: '8px',
                      color: '#fff'
                    }}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Active Devices */}
        <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-green-400" />
              Dispositivos Ativos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activeDevices.map((device, index) => (
                <motion.div
                  key={device.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-4"
                >
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-white font-medium">{device.name}</span>
                      <span className="text-gray-400">{device.count} dispositivos</span>
                    </div>
                    <div className="w-full h-3 bg-[#1a2847] rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${device.percentage}%` }}
                        transition={{ duration: 1, delay: index * 0.1 }}
                        className="h-full bg-gradient-to-r from-green-500 to-green-600"
                      />
                    </div>
                  </div>
                  <span className="text-sm text-gray-400 min-w-[50px] text-right">{device.percentage}%</span>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function MetricCard({ title, value, icon: Icon, color, trend }) {
  const colorClasses = {
    blue: "from-blue-500/20 to-blue-600/5 border-blue-500/30 shadow-blue-500/20",
    red: "from-red-500/20 to-red-600/5 border-red-500/30 shadow-red-500/20",
    green: "from-green-500/20 to-green-600/5 border-green-500/30 shadow-green-500/20",
    purple: "from-purple-500/20 to-purple-600/5 border-purple-500/30 shadow-purple-500/20",
  };

  const iconColors = {
    blue: "text-blue-400",
    red: "text-red-400",
    green: "text-green-400",
    purple: "text-purple-400",
  };

  return (
    <motion.div whileHover={{ scale: 1.02, y: -5 }}>
      <Card className={`bg-gradient-to-br ${colorClasses[color]} border-[#1a2847] shadow-xl`}>
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <p className="text-gray-400 text-sm mb-1">{title}</p>
              <p className="text-3xl font-bold text-white">{value}</p>
            </div>
            <div className={`w-12 h-12 rounded-xl bg-[#1a2847] flex items-center justify-center ${iconColors[color]}`}>
              <Icon className="w-6 h-6" />
            </div>
          </div>
          {trend && (
            <p className="text-xs text-gray-500">{trend}</p>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}