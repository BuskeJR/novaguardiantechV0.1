import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { QrCode, Download, Smartphone, Wifi, Copy, CheckCircle, ExternalLink } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { createPageUrl } from "@/utils";

export default function QrConfigPage() {
  const dnsConfig = {
    primary: "10.0.0.1",
    secondary: "10.0.0.2",
    name: "NovaGuardian DNS"
  };

  const configUrl = `${window.location.origin}${createPageUrl("DnsGuide")}`;

  const copyDns = (dns) => {
    navigator.clipboard.writeText(dns);
    toast.success("DNS copiado!");
  };

  const copyConfigUrl = () => {
    navigator.clipboard.writeText(configUrl);
    toast.success("URL copiada!");
  };

  const openInNewTab = () => {
    window.open(configUrl, '_blank');
  };

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-purple-500 rounded-full opacity-5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-blue-500 rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-5xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20">
              <QrCode className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Configuração Rápida</h1>
              <p className="text-gray-400">Configure seus dispositivos rapidamente</p>
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* QR Code Info Card */}
          <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <QrCode className="w-5 h-5 text-purple-400" />
                Link de Configuração
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-6 bg-[#1a2847] rounded-lg border-2 border-dashed border-purple-500/30">
                <div className="text-center mb-4">
                  <QrCode className="w-24 h-24 mx-auto text-purple-400 mb-4" />
                  <p className="text-gray-400 text-sm">
                    Use um gerador de QR Code online com a URL abaixo
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-gray-400 text-sm">URL de Configuração:</p>
                <div className="flex gap-2">
                  <div className="flex-1 p-3 bg-[#1a2847] rounded-lg text-blue-400 text-sm font-mono break-all">
                    {configUrl}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={copyConfigUrl}
                    className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10 flex-shrink-0"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <Button
                onClick={openInNewTab}
                className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Abrir Guia de Configuração
              </Button>

              <p className="text-gray-500 text-xs text-center">
                Você pode usar ferramentas como qr-code-generator.com para criar um QR Code com esta URL
              </p>
            </CardContent>
          </Card>

          {/* DNS Info */}
          <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Wifi className="w-5 h-5 text-blue-400" />
                Servidores DNS
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-[#1a2847] rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-400 text-sm">DNS Primário</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => copyDns(dnsConfig.primary)}
                    className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
                <code className="text-xl font-bold text-white">{dnsConfig.primary}</code>
              </div>

              <div className="p-4 bg-[#1a2847] rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-400 text-sm">DNS Secundário</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => copyDns(dnsConfig.secondary)}
                    className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
                <code className="text-xl font-bold text-white">{dnsConfig.secondary}</code>
              </div>

              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                <p className="text-blue-400 text-sm">
                  💡 <strong>Dica:</strong> Copie estes endereços DNS e configure-os em suas configurações de rede
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Instructions */}
        <div className="grid md:grid-cols-3 gap-6">
          <InstructionCard
            icon={QrCode}
            title="1. Gere o QR Code"
            description="Use um gerador de QR Code online com a URL de configuração acima"
            color="purple"
          />
          <InstructionCard
            icon={Smartphone}
            title="2. Escaneie com seu Dispositivo"
            description="Use a câmera do seu smartphone para escanear o QR Code gerado"
            color="blue"
          />
          <InstructionCard
            icon={CheckCircle}
            title="3. Siga as Instruções"
            description="Configure os servidores DNS seguindo o guia específico do seu dispositivo"
            color="green"
          />
        </div>

        {/* Additional Info */}
        <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] mt-6">
          <CardHeader>
            <CardTitle className="text-white">Geradores de QR Code Recomendados</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              <a
                href="https://www.qr-code-generator.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 bg-[#1a2847] rounded-lg hover:bg-[#1a2847]/70 transition-colors border border-purple-500/20 hover:border-purple-500/40"
              >
                <h4 className="text-white font-semibold mb-2">QR Code Generator</h4>
                <p className="text-gray-400 text-sm mb-2">Gerador online gratuito e fácil de usar</p>
                <span className="text-purple-400 text-sm flex items-center gap-1">
                  Acessar <ExternalLink className="w-3 h-3" />
                </span>
              </a>
              <a
                href="https://qr.io/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 bg-[#1a2847] rounded-lg hover:bg-[#1a2847]/70 transition-colors border border-purple-500/20 hover:border-purple-500/40"
              >
                <h4 className="text-white font-semibold mb-2">QR.io</h4>
                <p className="text-gray-400 text-sm mb-2">Plataforma completa com analytics</p>
                <span className="text-purple-400 text-sm flex items-center gap-1">
                  Acessar <ExternalLink className="w-3 h-3" />
                </span>
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function InstructionCard({ icon: Icon, title, description, color }) {
  const colors = {
    purple: "from-purple-500/20 to-purple-600/10 border-purple-500/30 shadow-purple-500/20",
    blue: "from-blue-500/20 to-blue-600/10 border-blue-500/30 shadow-blue-500/20",
    green: "from-green-500/20 to-green-600/10 border-green-500/30 shadow-green-500/20",
  };

  const iconColors = {
    purple: "text-purple-400",
    blue: "text-blue-400",
    green: "text-green-400",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02, y: -5 }}
    >
      <Card className={`bg-gradient-to-br ${colors[color]} border-[#1a2847] h-full`}>
        <CardContent className="p-6">
          <div className={`w-12 h-12 rounded-xl bg-[#1a2847] flex items-center justify-center mb-4 ${iconColors[color]}`}>
            <Icon className="w-6 h-6" />
          </div>
          <h3 className="text-white font-semibold mb-2">{title}</h3>
          <p className="text-gray-400 text-sm">{description}</p>
        </CardContent>
      </Card>
    </motion.div>
  );
}