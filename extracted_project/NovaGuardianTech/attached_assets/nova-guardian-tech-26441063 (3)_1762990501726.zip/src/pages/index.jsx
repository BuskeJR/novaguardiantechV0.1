import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Domains from "./Domains";

import Logs from "./Logs";

import Settings from "./Settings";

import AdminUsers from "./AdminUsers";

import Onboarding from "./Onboarding";

import Invitations from "./Invitations";

import AcceptInvite from "./AcceptInvite";

import Reports from "./Reports";

import Whitelist from "./Whitelist";

import DnsGuide from "./DnsGuide";

import Schedules from "./Schedules";

import Groups from "./Groups";

import SystemConfig from "./SystemConfig";

import NetworkDashboard from "./NetworkDashboard";

import Billing from "./Billing";

import ApiDocs from "./ApiDocs";

import QrConfig from "./QrConfig";

import MobileApp from "./MobileApp";

import Support from "./Support";

import DNSTest from "./DNSTest";

import BackupRestore from "./BackupRestore";

import Alerts from "./Alerts";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Domains: Domains,
    
    Logs: Logs,
    
    Settings: Settings,
    
    AdminUsers: AdminUsers,
    
    Onboarding: Onboarding,
    
    Invitations: Invitations,
    
    AcceptInvite: AcceptInvite,
    
    Reports: Reports,
    
    Whitelist: Whitelist,
    
    DnsGuide: DnsGuide,
    
    Schedules: Schedules,
    
    Groups: Groups,
    
    SystemConfig: SystemConfig,
    
    NetworkDashboard: NetworkDashboard,
    
    Billing: Billing,
    
    ApiDocs: ApiDocs,
    
    QrConfig: QrConfig,
    
    MobileApp: MobileApp,
    
    Support: Support,
    
    DNSTest: DNSTest,
    
    BackupRestore: BackupRestore,
    
    Alerts: Alerts,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Domains" element={<Domains />} />
                
                <Route path="/Logs" element={<Logs />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/AdminUsers" element={<AdminUsers />} />
                
                <Route path="/Onboarding" element={<Onboarding />} />
                
                <Route path="/Invitations" element={<Invitations />} />
                
                <Route path="/AcceptInvite" element={<AcceptInvite />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/Whitelist" element={<Whitelist />} />
                
                <Route path="/DnsGuide" element={<DnsGuide />} />
                
                <Route path="/Schedules" element={<Schedules />} />
                
                <Route path="/Groups" element={<Groups />} />
                
                <Route path="/SystemConfig" element={<SystemConfig />} />
                
                <Route path="/NetworkDashboard" element={<NetworkDashboard />} />
                
                <Route path="/Billing" element={<Billing />} />
                
                <Route path="/ApiDocs" element={<ApiDocs />} />
                
                <Route path="/QrConfig" element={<QrConfig />} />
                
                <Route path="/MobileApp" element={<MobileApp />} />
                
                <Route path="/Support" element={<Support />} />
                
                <Route path="/DNSTest" element={<DNSTest />} />
                
                <Route path="/BackupRestore" element={<BackupRestore />} />
                
                <Route path="/Alerts" element={<Alerts />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}