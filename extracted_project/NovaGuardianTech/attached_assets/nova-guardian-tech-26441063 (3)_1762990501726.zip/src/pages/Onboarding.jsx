import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";
import { Progress } from "@/components/ui/progress";
import { Shield, Sparkles } from "lucide-react";
import WelcomeStep from "../components/onboarding/WelcomeStep";
import ProfileStep from "../components/onboarding/ProfileStep";
import BlocklistStep from "../components/onboarding/BlocklistStep";
import TourStep from "../components/onboarding/TourStep";
import CompleteStep from "../components/onboarding/CompleteStep";

export default function OnboardingPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [loading, setLoading] = useState(true);

  const steps = [
    { id: 0, title: "Bem-vindo", component: WelcomeStep },
    { id: 1, title: "Perfil", component: ProfileStep },
    { id: 2, title: "Proteção Inicial", component: BlocklistStep },
    { id: 3, title: "Tour Rápido", component: TourStep },
    { id: 4, title: "Completo", component: CompleteStep },
  ];

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      // Se já completou onboarding, redireciona para dashboard
      if (currentUser.onboarding_completed) {
        navigate(createPageUrl("Dashboard"));
        return;
      }
      
      // Continua do último step
      if (currentUser.onboarding_step) {
        setCurrentStep(currentUser.onboarding_step);
      }
    } catch (error) {
      console.error("Error loading user:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleNext = async () => {
    const nextStep = currentStep + 1;
    
    // Salva progresso
    await base44.auth.updateMe({
      onboarding_step: nextStep
    });
    
    if (nextStep < steps.length) {
      setCurrentStep(nextStep);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = async () => {
    await base44.auth.updateMe({
      onboarding_completed: true,
      onboarding_step: steps.length
    });
    
    navigate(createPageUrl("Dashboard"));
  };

  const progress = ((currentStep + 1) / steps.length) * 100;
  const CurrentStepComponent = steps[currentStep]?.component;

  if (loading) {
    return (
      <div className="min-h-screen bg-[#01081c] flex items-center justify-center">
        <div className="flex items-center gap-3 text-white">
          <Sparkles className="w-6 h-6 animate-spin" />
          <span>Preparando seu ambiente...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#01081c] relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[#1284e1] rounded-full opacity-10 blur-3xl animate-pulse" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-500 rounded-full opacity-10 blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-green-500 rounded-full opacity-5 blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      </div>

      {/* Header */}
      <div className="relative z-10 border-b border-[#1a2847] bg-[#01081c]/80 backdrop-blur-xl">
        <div className="max-w-5xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#1284e1] to-[#0d5fb8] rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/30">
                <Shield className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">NovaGuardian</h1>
                <p className="text-sm text-gray-400">Configuração Inicial</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-400">Passo {currentStep + 1} de {steps.length}</p>
              <p className="text-xs text-gray-500">{steps[currentStep]?.title}</p>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <Progress value={progress} className="h-2 bg-[#1a2847]" />
            <div className="flex justify-between">
              {steps.map((step, index) => (
                <div
                  key={step.id}
                  className={`flex items-center gap-2 ${
                    index <= currentStep ? 'text-[#1284e1]' : 'text-gray-600'
                  }`}
                >
                  <div className={`w-2 h-2 rounded-full ${
                    index <= currentStep ? 'bg-[#1284e1]' : 'bg-gray-600'
                  }`} />
                  <span className="text-xs hidden md:inline">{step.title}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 py-12">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            {CurrentStepComponent && (
              <CurrentStepComponent
                user={user}
                onNext={handleNext}
                onBack={handleBack}
                onComplete={handleComplete}
                isFirst={currentStep === 0}
                isLast={currentStep === steps.length - 1}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}