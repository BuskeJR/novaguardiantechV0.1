import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, CheckCircle, AlertCircle, Loader2, User, Lock, Mail } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

export default function AcceptInvitePage() {
  const navigate = useNavigate();
  const [invitation, setInvitation] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    full_name: "",
    password: "",
    confirmPassword: "",
  });

  useEffect(() => {
    validateToken();
  }, []);

  const validateToken = async () => {
    try {
      // Get token from URL
      const urlParams = new URLSearchParams(window.location.hash.split('?')[1]);
      const token = urlParams.get('token');

      if (!token) {
        setError("Token de convite não encontrado");
        setLoading(false);
        return;
      }

      // Find invitation by token
      const invitations = await base44.entities.Invitation.filter({ token });
      
      if (!invitations || invitations.length === 0) {
        setError("Convite não encontrado");
        setLoading(false);
        return;
      }

      const invite = invitations[0];

      // Check if expired
      if (new Date(invite.expiresAt) < new Date()) {
        setError("Este convite expirou");
        setLoading(false);
        return;
      }

      // Check if already accepted
      if (invite.status === 'accepted') {
        setError("Este convite já foi aceito");
        setLoading(false);
        return;
      }

      setInvitation(invite);
      setLoading(false);
    } catch (error) {
      console.error("Error validating token:", error);
      setError("Erro ao validar convite");
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (formData.password !== formData.confirmPassword) {
      toast.error("As senhas não coincidem");
      return;
    }

    if (formData.password.length < 6) {
      toast.error("A senha deve ter pelo menos 6 caracteres");
      return;
    }

    setSubmitting(true);

    try {
      // Note: In a real implementation, this would create a new user account
      // Since Base44 handles authentication, we'll simulate the user creation
      // and update the invitation status
      
      // Update invitation status
      await base44.entities.Invitation.update(invitation.id, {
        status: "accepted",
        acceptedAt: new Date().toISOString()
      });

      // Log the action
      await base44.entities.BlockLog.create({
        action: "user_created",
        userEmail: invitation.email,
        tenantId: invitation.tenantId,
        details: { 
          action: "invitation_accepted",
          role: invitation.role
        },
      });

      toast.success("✓ Convite aceito com sucesso!");
      
      // In a real scenario, the user would be automatically logged in
      // For now, redirect to login
      setTimeout(() => {
        window.location.href = "/"; // Redirect to login
      }, 2000);

    } catch (error) {
      console.error("Error accepting invite:", error);
      toast.error("✗ Erro ao aceitar convite");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#01081c] flex items-center justify-center">
        <div className="flex items-center gap-3 text-white">
          <Loader2 className="w-6 h-6 animate-spin" />
          <span>Validando convite...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-[#01081c] flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full"
        >
          <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-red-500/30">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-red-500/10 rounded-full flex items-center justify-center">
                <AlertCircle className="w-8 h-8 text-red-400" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">Convite Inválido</h2>
              <p className="text-gray-400 mb-6">{error}</p>
              <Button
                onClick={() => window.location.href = "/"}
                className="bg-gradient-to-r from-[#1284e1] to-[#0d5fb8] hover:from-[#0d5fb8] hover:to-[#1284e1] text-white"
              >
                Voltar para o Login
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#01081c] relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-500 rounded-full opacity-10 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-[#1284e1] rounded-full opacity-10 blur-3xl" />
      </div>

      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full"
        >
          {/* Logo */}
          <div className="text-center mb-8">
            <motion.div
              animate={{ 
                scale: [1, 1.1, 1],
                rotate: [0, 5, -5, 0]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                repeatDelay: 1
              }}
              className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-[#1284e1] to-[#0d5fb8] rounded-2xl flex items-center justify-center shadow-2xl shadow-blue-500/30"
            >
              <Shield className="w-8 h-8 text-white" />
            </motion.div>
            <h1 className="text-3xl font-bold text-white mb-2">Aceitar Convite</h1>
            <p className="text-gray-400">Complete seu registro no NovaGuardian</p>
          </div>

          <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] shadow-2xl">
            <CardHeader>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
                  <Mail className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <CardTitle className="text-white">Você foi convidado!</CardTitle>
                  <CardDescription className="text-gray-400 text-sm">
                    {invitation?.email}
                  </CardDescription>
                </div>
              </div>
              <Alert className="bg-blue-500/10 border-blue-500/30 mt-4">
                <CheckCircle className="h-4 w-4 text-blue-400" />
                <AlertDescription className="text-blue-400 text-sm">
                  Papel: <span className="font-semibold">
                    {invitation?.role === 'admin' ? 'Administrador' : 'Usuário'}
                  </span>
                </AlertDescription>
              </Alert>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="full_name" className="text-gray-300">Nome Completo *</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      id="full_name"
                      value={formData.full_name}
                      onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                      className="pl-10 bg-[#1a2847] border-[#1a2847] text-white focus:border-purple-500"
                      placeholder="Seu nome completo"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-gray-300">Senha *</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      id="password"
                      type="password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      className="pl-10 bg-[#1a2847] border-[#1a2847] text-white focus:border-purple-500"
                      placeholder="Mínimo 6 caracteres"
                      required
                      minLength={6}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword" className="text-gray-300">Confirmar Senha *</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      id="confirmPassword"
                      type="password"
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                      className="pl-10 bg-[#1a2847] border-[#1a2847] text-white focus:border-purple-500"
                      placeholder="Repita sua senha"
                      required
                      minLength={6}
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={submitting}
                  className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white shadow-lg shadow-purple-500/30"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Aceitando...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Aceitar Convite e Criar Conta
                    </>
                  )}
                </Button>
              </form>

              <p className="text-center text-gray-500 text-xs mt-6">
                Ao aceitar, você concorda com os termos de uso do NovaGuardian
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}