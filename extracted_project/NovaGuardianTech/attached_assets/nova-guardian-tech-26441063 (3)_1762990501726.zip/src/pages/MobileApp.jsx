import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Smartphone, Download, Apple, MonitorSmartphone, Shield, Zap, Bell, CheckCircle, QrCode, Star } from "lucide-react";
import { motion } from "framer-motion";

const features = [
  {
    icon: Shield,
    title: "Proteção em Tempo Real",
    description: "Bloqueio instantâneo de domínios maliciosos enquanto você navega"
  },
  {
    icon: Zap,
    title: "Sincronização Automática",
    description: "Suas configurações sincronizam automaticamente entre dispositivos"
  },
  {
    icon: Bell,
    title: "Notificações Push",
    description: "Receba alertas sobre tentativas de acesso a domínios bloqueados"
  },
  {
    icon: CheckCircle,
    title: "Gestão Offline",
    description: "Visualize e gerencie domínios mesmo sem conexão"
  },
  {
    icon: QrCode,
    title: "Setup Rápido",
    description: "Configure em segundos usando QR Code"
  },
  {
    icon: MonitorSmartphone,
    title: "Multi-Dispositivo",
    description: "Proteja todos seus dispositivos com uma única conta"
  },
];

const screenshots = [
  { title: "Dashboard", image: "https://images.unsplash.com/photo-1551650975-87deedd944c3?w=400&h=800&fit=crop" },
  { title: "Domínios", image: "https://images.unsplash.com/photo-1551434678-e076c223a692?w=400&h=800&fit=crop" },
  { title: "Estatísticas", image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=800&fit=crop" },
];

export default function MobileAppPage() {
  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Hero Section */}
      <div className="relative">
        {/* Background */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-500 rounded-full opacity-10 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-500 rounded-full opacity-10 blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-4 md:px-8 py-16 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 rounded-full px-4 py-2 mb-6">
              <Smartphone className="w-4 h-4 text-blue-400" />
              <span className="text-blue-400 text-sm font-medium">Disponível em breve</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
              NovaGuardian Mobile
            </h1>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-8">
              Leve a proteção DNS para o seu bolso. Gerencie domínios, visualize estatísticas e 
              mantenha sua rede segura de qualquer lugar.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                disabled
                size="lg"
                className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-xl relative overflow-hidden group"
              >
                <Apple className="w-5 h-5 mr-2" />
                App Store
                <Badge className="ml-2 bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                  Em breve
                </Badge>
              </Button>
              <Button
                disabled
                size="lg"
                variant="outline"
                className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847] relative overflow-hidden group"
              >
                <MonitorSmartphone className="w-5 h-5 mr-2" />
                Google Play
                <Badge className="ml-2 bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                  Em breve
                </Badge>
              </Button>
            </div>
          </motion.div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] h-full hover:border-blue-500/50 transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-blue-500/10 rounded-xl flex items-center justify-center mb-4">
                      <feature.icon className="w-6 h-6 text-blue-400" />
                    </div>
                    <h3 className="text-white font-semibold mb-2">{feature.title}</h3>
                    <p className="text-gray-400 text-sm">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Screenshots */}
          <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] mb-16">
            <CardHeader>
              <CardTitle className="text-white text-center text-2xl">Interface do App</CardTitle>
              <p className="text-gray-400 text-center">Design moderno e intuitivo</p>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-8">
                {screenshots.map((screenshot, index) => (
                  <motion.div
                    key={screenshot.title}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.5 + index * 0.1 }}
                    className="relative"
                  >
                    <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-[#1a2847] aspect-[9/19]">
                      <img
                        src={screenshot.image}
                        alt={screenshot.title}
                        className="w-full h-full object-cover opacity-70"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                      <div className="absolute bottom-0 left-0 right-0 p-6">
                        <h4 className="text-white font-semibold text-lg">{screenshot.title}</h4>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Stats */}
          <div className="grid md:grid-cols-4 gap-6 mb-16">
            {[
              { label: "Dispositivos Suportados", value: "iOS & Android" },
              { label: "Tempo de Setup", value: "< 2 min" },
              { label: "Avaliação", value: <div className="flex items-center gap-1"><Star className="w-4 h-4 fill-yellow-400 text-yellow-400" /><span>4.8/5.0</span></div> },
              { label: "Downloads", value: "Em breve" },
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 + index * 0.1 }}
              >
                <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] text-center">
                  <CardContent className="p-6">
                    <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                    <p className="text-gray-400 text-sm">{stat.label}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* CTA */}
          <Card className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border-blue-500/20">
            <CardContent className="p-12 text-center">
              <Bell className="w-16 h-16 text-blue-400 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-white mb-4">
                Seja notificado quando lançarmos
              </h2>
              <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
                Cadastre seu email para receber uma notificação assim que o app estiver disponível 
                nas lojas. Usuários early bird ganharão 3 meses de plano Pro grátis!
              </p>
              <div className="flex gap-3 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="seu@email.com"
                  className="flex-1 px-4 py-3 bg-[#1a2847] border border-[#1a2847] rounded-lg text-white placeholder:text-gray-500 focus:outline-none focus:border-blue-500"
                />
                <Button className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white">
                  Notificar-me
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}