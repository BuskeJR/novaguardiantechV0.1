import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CreditCard, Check, Zap, Building, Crown, ArrowRight, Calendar } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

const plans = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    currency: 'BRL',
    icon: Zap,
    color: 'blue',
    features: [
      '100 domínios bloqueados',
      '1.000 queries/dia',
      '1 usuário',
      'Suporte por email',
      'Retenção de logs: 7 dias',
    ],
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 49.90,
    currency: 'BRL',
    icon: Building,
    color: 'purple',
    popular: true,
    features: [
      '10.000 domínios bloqueados',
      'Queries ilimitadas',
      'Até 10 usuários',
      'Suporte prioritário',
      'Retenção de logs: 90 dias',
      'Agendamento de bloqueios',
      'Grupos de domínios',
      'Whitelist avançada',
    ],
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 199.90,
    currency: 'BRL',
    icon: Crown,
    color: 'gold',
    features: [
      'Domínios ilimitados',
      'Queries ilimitadas',
      'Usuários ilimitados',
      'Suporte 24/7',
      'Retenção de logs: 365 dias',
      'Todas as features do Pro',
      'API dedicada',
      'Gerente de conta',
      'SLA 99.9%',
    ],
  },
];

export default function BillingPage() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: subscription } = useQuery({
    queryKey: ['subscription', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return null;
      const subs = await base44.entities.Subscription.filter({ tenantId: user.tenantId });
      if (subs.length > 0) return subs[0];
      
      // Create default free subscription
      return await base44.entities.Subscription.create({
        tenantId: user.tenantId,
        plan: 'free',
        status: 'active',
        billingCycle: 'monthly',
        amount: 0,
        currency: 'BRL',
        startDate: new Date().toISOString(),
      });
    },
    enabled: !!user?.tenantId,
  });

  const changePlanMutation = useMutation({
    mutationFn: async (newPlan) => {
      if (!subscription?.id) return;
      
      const planData = plans.find(p => p.id === newPlan);
      
      await base44.entities.Subscription.update(subscription.id, {
        plan: newPlan,
        amount: planData.price,
        status: 'active',
        renewalDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      });

      await base44.entities.BlockLog.create({
        action: "settings_changed",
        userId: user.id,
        userEmail: user.email,
        tenantId: user.tenantId,
        details: { action: "plan_changed", new_plan: newPlan },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subscription'] });
      toast.success("✓ Plano atualizado com sucesso!");
    },
    onError: () => {
      toast.error("✗ Erro ao atualizar plano");
    },
  });

  const currentPlan = plans.find(p => p.id === subscription?.plan) || plans[0];

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-purple-500 rounded-full opacity-5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-yellow-500 rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20">
              <CreditCard className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Assinatura & Cobrança</h1>
              <p className="text-gray-400">Gerencie seu plano e pagamentos</p>
            </div>
          </div>
        </motion.div>

        {/* Current Plan */}
        <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] mb-8">
          <CardHeader>
            <CardTitle className="text-white">Seu Plano Atual</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className={`w-16 h-16 rounded-xl bg-gradient-to-br ${
                  currentPlan.color === 'blue' ? 'from-blue-500/20 to-blue-600/10' :
                  currentPlan.color === 'purple' ? 'from-purple-500/20 to-purple-600/10' :
                  'from-yellow-500/20 to-yellow-600/10'
                } flex items-center justify-center`}>
                  <currentPlan.icon className={`w-8 h-8 ${
                    currentPlan.color === 'blue' ? 'text-blue-400' :
                    currentPlan.color === 'purple' ? 'text-purple-400' :
                    'text-yellow-400'
                  }`} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">{currentPlan.name}</h3>
                  <p className="text-gray-400">
                    {currentPlan.price > 0 ? (
                      <>R$ {currentPlan.price.toFixed(2)}/mês</>
                    ) : (
                      'Plano Gratuito'
                    )}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <Badge className={`${
                  subscription?.status === 'active' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                  'bg-gray-500/20 text-gray-400 border-gray-500/30'
                } mb-2`}>
                  {subscription?.status === 'active' ? 'Ativo' : 'Inativo'}
                </Badge>
                {subscription?.renewalDate && (
                  <p className="text-sm text-gray-400 flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Renovação: {format(new Date(subscription.renewalDate), "dd/MM/yyyy", { locale: ptBR })}
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Plans */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-6">Planos Disponíveis</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {plans.map((plan, index) => (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className={`bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] h-full relative overflow-hidden ${
                  plan.popular ? 'ring-2 ring-purple-500' : ''
                }`}>
                  {plan.popular && (
                    <div className="absolute top-0 right-0 bg-purple-500 text-white text-xs px-3 py-1 rounded-bl-lg font-semibold">
                      POPULAR
                    </div>
                  )}
                  <CardHeader>
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${
                      plan.color === 'blue' ? 'from-blue-500/20 to-blue-600/10' :
                      plan.color === 'purple' ? 'from-purple-500/20 to-purple-600/10' :
                      'from-yellow-500/20 to-yellow-600/10'
                    } flex items-center justify-center mb-4`}>
                      <plan.icon className={`w-6 h-6 ${
                        plan.color === 'blue' ? 'text-blue-400' :
                        plan.color === 'purple' ? 'text-purple-400' :
                        'text-yellow-400'
                      }`} />
                    </div>
                    <CardTitle className="text-white text-2xl">{plan.name}</CardTitle>
                    <CardDescription>
                      <span className="text-3xl font-bold text-white">
                        {plan.price > 0 ? `R$ ${plan.price.toFixed(2)}` : 'Grátis'}
                      </span>
                      {plan.price > 0 && <span className="text-gray-400">/mês</span>}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3 mb-6">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2 text-gray-300">
                          <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Button
                      onClick={() => {
                        if (plan.id !== subscription?.plan) {
                          if (plan.price > 0) {
                            toast.info("💳 Integração de pagamento será implementada em breve");
                          }
                          changePlanMutation.mutate(plan.id);
                        }
                      }}
                      disabled={plan.id === subscription?.plan}
                      className={`w-full ${
                        plan.id === subscription?.plan
                          ? 'bg-gray-600 cursor-not-allowed'
                          : plan.popular
                          ? 'bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700'
                          : 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700'
                      }`}
                    >
                      {plan.id === subscription?.plan ? (
                        'Plano Atual'
                      ) : (
                        <>
                          {plan.price === 0 ? 'Mudar para Free' : 'Fazer Upgrade'}
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Payment Info */}
        <Alert className="bg-blue-500/10 border-blue-500/20">
          <CreditCard className="h-4 w-4 text-blue-400" />
          <AlertDescription className="text-blue-400">
            <strong>Pagamento Seguro:</strong> Todos os pagamentos são processados de forma segura. 
            Você pode cancelar sua assinatura a qualquer momento sem custos adicionais.
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}