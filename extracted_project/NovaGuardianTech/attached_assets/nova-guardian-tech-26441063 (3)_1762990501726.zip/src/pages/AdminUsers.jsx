
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, UserPlus, Shield, Ban } from "lucide-react";
import { toast } from "sonner";
import { Alert, AlertDescription } from "@/components/ui/alert";
import UserTable from "../components/admin/UserTable";
import EditUserDialog from "../components/admin/EditUserDialog";
import CreateUserDialog from "../components/admin/CreateUserDialog";

export default function AdminUsersPage() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedUser, setSelectedUser] = useState(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);

  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['users', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.User.filter({ tenantId: user.tenantId }, '-created_date');
    },
    enabled: !!user?.tenantId && user?.role === 'admin',
    initialData: [],
  });

  const createUserMutation = useMutation({
    mutationFn: async (data) => {
      // Generate temporary password
      const tempPassword = Math.random().toString(36).slice(-10) + Math.random().toString(36).slice(-10).toUpperCase() + '!@#';
      
      // Create user (normally would use a backend endpoint that handles auth user creation)
      const newUser = await base44.entities.User.create({
        email: data.email,
        full_name: data.full_name,
        company: data.company || "",
        phone: data.phone || "",
        role: data.role,
        tenantId: user.tenantId,
        status: "active",
        onboarding_completed: false,
        onboarding_step: 0,
      });

      // Send welcome email with credentials
      await base44.integrations.Core.SendEmail({
        from_name: "NovaGuardian",
        to: data.email,
        subject: `Bem-vindo ao NovaGuardian - ${user.company || 'Sua Organização'}`,
        body: `
Olá ${data.full_name}!

Você foi adicionado ao NovaGuardian por ${user.full_name} (${user.email}).

Suas credenciais de acesso:
Email: ${data.email}
Senha Temporária: ${tempPassword}

Papel: ${data.role === 'admin' ? 'Administrador' : 'Usuário'}

⚠️ IMPORTANTE: Você DEVE trocar sua senha no primeiro acesso por motivos de segurança.

Acesse o sistema em:
${window.location.origin}${window.location.pathname}

Atenciosamente,
Equipe NovaGuardian
        `.trim()
      });

      // Log the action
      await base44.entities.BlockLog.create({
        action: "user_created",
        userId: user.id,
        userEmail: user.email,
        tenantId: user.tenantId,
        details: { 
          new_user_email: data.email,
          new_user_role: data.role,
          method: "direct_creation"
        },
      });

      return newUser;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      toast.success("✓ Usuário criado! Email com credenciais enviado.");
      setShowCreateDialog(false);
    },
    onError: (error) => {
      console.error("Error creating user:", error);
      toast.error("✗ Erro ao criar usuário");
    },
  });

  const updateUserMutation = useMutation({
    mutationFn: async ({ userId, data }) => {
      await base44.entities.User.update(userId, data);
      
      await base44.entities.BlockLog.create({
        action: "user_updated",
        userId: user.id,
        userEmail: user.email,
        tenantId: user.tenantId,
        details: { 
          target_user_id: userId,
          changes: Object.keys(data)
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      queryClient.invalidateQueries({ queryKey: ['logs'] });
      toast.success("Usuário atualizado com sucesso!");
      setShowEditDialog(false);
      setSelectedUser(null);
    },
    onError: () => {
      toast.error("Erro ao atualizar usuário");
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId) => {
      await base44.entities.BlockLog.create({
        action: "user_deleted",
        userId: user.id,
        userEmail: user.email,
        tenantId: user.tenantId,
        details: { target_user_id: userId },
      });

      await base44.entities.User.delete(userId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      queryClient.invalidateQueries({ queryKey: ['logs'] });
      toast.success("Usuário removido com sucesso!");
    },
    onError: () => {
      toast.error("Erro ao remover usuário");
    },
  });

  const filteredUsers = users.filter(u => 
    u.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.company?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (user?.role !== 'admin') {
    return (
      <div className="p-4 md:p-8 min-h-screen">
        <div className="max-w-7xl mx-auto">
          <Alert className="bg-red-500/10 border-red-500/20">
            <Ban className="h-4 w-4 text-red-500" />
            <AlertDescription className="text-red-400">
              Você não tem permissão para acessar esta página. Apenas administradores podem gerenciar usuários.
            </AlertDescription>
          </Alert>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Gerenciar Usuários</h1>
            <p className="text-gray-400">Administre usuários e suas permissões</p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => setShowCreateDialog(true)}
              className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
            >
              <UserPlus className="w-4 h-4 mr-2" />
              Criar Usuário
            </Button>
          </div>
        </div>

        <Alert className="bg-blue-500/10 border-blue-500/20 mb-6">
          <Shield className="h-4 w-4 text-blue-400" />
          <AlertDescription className="text-blue-400 text-sm">
            <strong>Dica:</strong> Você pode criar usuários diretamente ou enviá-los via sistema de convites na página de Convites.
          </AlertDescription>
        </Alert>

        <Card className="bg-[#01081c] border-[#1a2847] mb-6">
          <CardHeader>
            <CardTitle className="text-white">Buscar Usuários</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Buscar por nome, email ou empresa..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-[#1a2847] border-[#1a2847] text-white"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#01081c] border-[#1a2847]">
          <CardContent className="p-0">
            <UserTable
              users={filteredUsers}
              currentUserId={user?.id}
              isLoading={isLoading}
              onEdit={(user) => {
                setSelectedUser(user);
                setShowEditDialog(true);
              }}
              onDelete={(userId) => deleteUserMutation.mutate(userId)}
            />
          </CardContent>
        </Card>

        {filteredUsers.length === 0 && !isLoading && (
          <div className="text-center py-16">
            <div className="w-20 h-20 mx-auto mb-4 bg-[#1a2847] rounded-full flex items-center justify-center">
              <Search className="w-10 h-10 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Nenhum usuário encontrado</h3>
            <p className="text-gray-400">Tente ajustar os filtros de busca</p>
          </div>
        )}

        {/* Dialogs */}
        <CreateUserDialog
          open={showCreateDialog}
          onClose={() => setShowCreateDialog(false)}
          onCreate={(data) => createUserMutation.mutate(data)}
          isLoading={createUserMutation.isPending}
        />

        {selectedUser && (
          <EditUserDialog
            open={showEditDialog}
            onClose={() => {
              setShowEditDialog(false);
              setSelectedUser(null);
            }}
            user={selectedUser}
            onSave={(data) => updateUserMutation.mutate({ userId: selectedUser.id, data })}
            isLoading={updateUserMutation.isPending}
          />
        )}
      </div>
    </div>
  );
}
