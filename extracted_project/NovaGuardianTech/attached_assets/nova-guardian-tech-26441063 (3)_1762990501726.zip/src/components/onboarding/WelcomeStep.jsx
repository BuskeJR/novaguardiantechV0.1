import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Zap, Globe, Lock, TrendingUp, Users, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

const features = [
  {
    icon: Shield,
    title: "Proteção DNS Avançada",
    description: "Bloqueie domínios maliciosos e indesejados em tempo real",
    color: "from-blue-500 to-blue-600"
  },
  {
    icon: Zap,
    title: "Alta Performance",
    description: "Sistema otimizado para máxima velocidade e eficiência",
    color: "from-yellow-500 to-orange-500"
  },
  {
    icon: Globe,
    title: "Gerenciamento Centralizado",
    description: "Controle completo de toda sua rede em um único lugar",
    color: "from-green-500 to-green-600"
  },
  {
    icon: Lock,
    title: "Segurança Empresarial",
    description: "Proteção contra malware, phishing e sites perigosos",
    color: "from-red-500 to-red-600"
  },
  {
    icon: TrendingUp,
    title: "Análises Detalhadas",
    description: "Insights e relatórios completos sobre sua rede",
    color: "from-purple-500 to-purple-600"
  },
  {
    icon: Users,
    title: "Multi-Usuário",
    description: "Gerencie equipes com controle de permissões",
    color: "from-indigo-500 to-indigo-600"
  }
];

export default function WelcomeStep({ user, onNext }) {
  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-12"
      >
        <motion.div
          animate={{ 
            scale: [1, 1.1, 1],
            rotate: [0, 5, -5, 0]
          }}
          transition={{ 
            duration: 3,
            repeat: Infinity,
            repeatDelay: 1
          }}
          className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-[#1284e1] to-[#0d5fb8] rounded-3xl flex items-center justify-center shadow-2xl shadow-blue-500/30"
        >
          <Shield className="w-12 h-12 text-white" />
        </motion.div>
        
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
          Bem-vindo ao <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#1284e1] to-[#0d5fb8]">NovaGuardian</span>
        </h1>
        <p className="text-xl text-gray-400 mb-2">
          Olá, <span className="text-white font-semibold">{user?.full_name || "Usuário"}</span>! 👋
        </p>
        <p className="text-lg text-gray-500 max-w-2xl mx-auto">
          Estamos animados em tê-lo conosco. Vamos configurar sua proteção DNS em apenas alguns passos simples.
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        {features.map((feature, index) => (
          <motion.div
            key={feature.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.05, y: -5 }}
          >
            <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] hover:border-[#1284e1]/50 transition-all duration-300 h-full">
              <CardContent className="p-6">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4 shadow-lg`}>
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-white font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-400 text-sm">{feature.description}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card className="bg-gradient-to-br from-[#1284e1]/10 to-[#0d5fb8]/5 border-[#1284e1]/30">
        <CardContent className="p-8 text-center">
          <div className="mb-6">
            <h3 className="text-2xl font-bold text-white mb-2">Pronto para começar?</h3>
            <p className="text-gray-400">
              Vamos configurar sua conta em menos de 5 minutos
            </p>
          </div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              onClick={onNext}
              size="lg"
              className="bg-gradient-to-r from-[#1284e1] to-[#0d5fb8] hover:from-[#0d5fb8] hover:to-[#1284e1] text-white shadow-xl shadow-blue-500/30 px-8"
            >
              Começar Configuração
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </motion.div>
        </CardContent>
      </Card>
    </div>
  );
}