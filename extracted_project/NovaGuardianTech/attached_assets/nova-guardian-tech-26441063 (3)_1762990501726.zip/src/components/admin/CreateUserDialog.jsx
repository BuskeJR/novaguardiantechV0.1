import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { UserPlus, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function CreateUserDialog({ open, onClose, onCreate, isLoading }) {
  const [formData, setFormData] = useState({
    email: "",
    full_name: "",
    company: "",
    phone: "",
    role: "user",
  });

  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.email || !formData.email.includes('@')) {
      newErrors.email = "Email válido é obrigatório";
    }
    
    if (!formData.full_name || formData.full_name.trim().length < 3) {
      newErrors.full_name = "Nome completo é obrigatório (mínimo 3 caracteres)";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      onCreate(formData);
      // Reset form
      setFormData({
        email: "",
        full_name: "",
        company: "",
        phone: "",
        role: "user",
      });
      setErrors({});
    }
  };

  const handleClose = () => {
    setFormData({
      email: "",
      full_name: "",
      company: "",
      phone: "",
      role: "user",
    });
    setErrors({});
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="bg-[#01081c] border-[#1a2847] text-white max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-green-400" />
            Criar Novo Usuário
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Adicione um novo usuário ao sistema. Uma senha temporária será gerada e enviada por email.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">
            <Alert className="bg-blue-500/10 border-blue-500/30">
              <AlertCircle className="h-4 w-4 text-blue-400" />
              <AlertDescription className="text-blue-400 text-sm">
                <strong>Dica:</strong> O usuário receberá um email com senha temporária e será solicitado a alterá-la no primeiro login.
              </AlertDescription>
            </Alert>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email">
                  Email <span className="text-red-400">*</span>
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className={`bg-[#1a2847] border-[#1a2847] text-white ${
                    errors.email ? 'border-red-500' : ''
                  }`}
                  placeholder="usuario@empresa.com"
                  required
                />
                {errors.email && (
                  <p className="text-xs text-red-400">{errors.email}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="full_name">
                  Nome Completo <span className="text-red-400">*</span>
                </Label>
                <Input
                  id="full_name"
                  value={formData.full_name}
                  onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                  className={`bg-[#1a2847] border-[#1a2847] text-white ${
                    errors.full_name ? 'border-red-500' : ''
                  }`}
                  placeholder="João Silva"
                  required
                />
                {errors.full_name && (
                  <p className="text-xs text-red-400">{errors.full_name}</p>
                )}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="company">Empresa</Label>
                <Input
                  id="company"
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  className="bg-[#1a2847] border-[#1a2847] text-white"
                  placeholder="Nome da Empresa"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Telefone</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="bg-[#1a2847] border-[#1a2847] text-white"
                  placeholder="(00) 00000-0000"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">
                Papel no Sistema <span className="text-red-400">*</span>
              </Label>
              <Select
                value={formData.role}
                onValueChange={(value) => setFormData({ ...formData, role: value })}
              >
                <SelectTrigger className="bg-[#1a2847] border-[#1a2847] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#01081c] border-[#1a2847] text-white">
                  <SelectItem value="user">
                    <div className="flex flex-col">
                      <span className="font-medium">Usuário</span>
                      <span className="text-xs text-gray-400">Acesso básico ao sistema</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="admin">
                    <div className="flex flex-col">
                      <span className="font-medium">Administrador</span>
                      <span className="text-xs text-gray-400">Acesso total, incluindo gerenciamento de usuários</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="bg-[#1a2847] p-4 rounded-lg space-y-2">
              <h4 className="text-white font-semibold text-sm">O que acontece ao criar:</h4>
              <ul className="space-y-1 text-xs text-gray-400">
                <li className="flex items-start gap-2">
                  <span className="text-green-400">✓</span>
                  <span>Usuário é criado imediatamente no sistema</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-400">✓</span>
                  <span>Senha temporária é gerada automaticamente</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-400">✓</span>
                  <span>Email com credenciais é enviado ao usuário</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-400">✓</span>
                  <span>Usuário deve trocar a senha no primeiro acesso</span>
                </li>
              </ul>
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
            >
              <UserPlus className="w-4 h-4 mr-2" />
              {isLoading ? "Criando..." : "Criar Usuário"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}