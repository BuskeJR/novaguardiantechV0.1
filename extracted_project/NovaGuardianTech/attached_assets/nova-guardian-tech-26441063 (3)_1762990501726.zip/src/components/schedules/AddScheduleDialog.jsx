import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Clock } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const weekDays = [
  { value: 0, label: "Domingo" },
  { value: 1, label: "Segunda" },
  { value: 2, label: "Terça" },
  { value: 3, label: "Quarta" },
  { value: 4, label: "Quinta" },
  { value: 5, label: "Sexta" },
  { value: 6, label: "Sábado" },
];

const categories = [
  { value: "social_media", label: "Redes Sociais" },
  { value: "streaming", label: "Streaming" },
  { value: "gaming", label: "Jogos" },
  { value: "adult", label: "Adulto" },
  { value: "gambling", label: "Apostas" },
  { value: "malware", label: "Malware" },
  { value: "ads", label: "Anúncios" },
  { value: "other", label: "Outros" },
];

export default function AddScheduleDialog({ open, onClose, schedule, domains, onSave, isLoading }) {
  const [formData, setFormData] = useState({
    name: "",
    startTime: "09:00",
    endTime: "18:00",
    daysOfWeek: [1, 2, 3, 4, 5], // Default: weekdays
    action: "block",
    isActive: true,
    domainIds: [],
    categories: [],
  });
  const [targetType, setTargetType] = useState("categories");

  useEffect(() => {
    if (schedule) {
      setFormData({
        name: schedule.name || "",
        startTime: schedule.startTime || "09:00",
        endTime: schedule.endTime || "18:00",
        daysOfWeek: schedule.daysOfWeek || [1, 2, 3, 4, 5],
        action: schedule.action || "block",
        isActive: schedule.isActive !== undefined ? schedule.isActive : true,
        domainIds: schedule.domainIds || [],
        categories: schedule.categories || [],
      });
      setTargetType(
        schedule.categories && schedule.categories.length > 0 ? "categories" : "domains"
      );
    } else {
      setFormData({
        name: "",
        startTime: "09:00",
        endTime: "18:00",
        daysOfWeek: [1, 2, 3, 4, 5],
        action: "block",
        isActive: true,
        domainIds: [],
        categories: [],
      });
      setTargetType("categories");
    }
  }, [schedule, open]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const dataToSave = { ...formData };
    
    // Clean up based on target type
    if (targetType === "categories") {
      dataToSave.domainIds = [];
    } else {
      dataToSave.categories = [];
    }
    
    onSave(dataToSave);
  };

  const toggleDay = (day) => {
    if (formData.daysOfWeek.includes(day)) {
      setFormData({
        ...formData,
        daysOfWeek: formData.daysOfWeek.filter(d => d !== day)
      });
    } else {
      setFormData({
        ...formData,
        daysOfWeek: [...formData.daysOfWeek, day].sort()
      });
    }
  };

  const toggleCategory = (cat) => {
    if (formData.categories.includes(cat)) {
      setFormData({
        ...formData,
        categories: formData.categories.filter(c => c !== cat)
      });
    } else {
      setFormData({
        ...formData,
        categories: [...formData.categories, cat]
      });
    }
  };

  const toggleDomain = (domainId) => {
    if (formData.domainIds.includes(domainId)) {
      setFormData({
        ...formData,
        domainIds: formData.domainIds.filter(id => id !== domainId)
      });
    } else {
      setFormData({
        ...formData,
        domainIds: [...formData.domainIds, domainId]
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] text-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-indigo-400" />
            {schedule ? "Editar Agendamento" : "Novo Agendamento"}
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Configure quando bloquear ou permitir domínios
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="space-y-6 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome do Agendamento *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="bg-[#1a2847] border-[#1a2847] text-white"
                placeholder="Ex: Bloquear redes sociais no horário comercial"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startTime">Horário Início</Label>
                <Input
                  id="startTime"
                  type="time"
                  value={formData.startTime}
                  onChange={(e) => setFormData({ ...formData, startTime: e.target.value })}
                  className="bg-[#1a2847] border-[#1a2847] text-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="endTime">Horário Término</Label>
                <Input
                  id="endTime"
                  type="time"
                  value={formData.endTime}
                  onChange={(e) => setFormData({ ...formData, endTime: e.target.value })}
                  className="bg-[#1a2847] border-[#1a2847] text-white"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Dias da Semana</Label>
              <div className="grid grid-cols-4 gap-2">
                {weekDays.map((day) => (
                  <div
                    key={day.value}
                    onClick={() => toggleDay(day.value)}
                    className={`p-3 rounded-lg border cursor-pointer transition-all ${
                      formData.daysOfWeek.includes(day.value)
                        ? "bg-indigo-500/20 border-indigo-500 text-indigo-400"
                        : "bg-[#1a2847] border-[#1a2847] text-gray-400 hover:border-indigo-500/50"
                    }`}
                  >
                    <div className="text-xs font-medium text-center">{day.label}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Ação</Label>
              <Select value={formData.action} onValueChange={(value) => setFormData({ ...formData, action: value })}>
                <SelectTrigger className="bg-[#1a2847] border-[#1a2847] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#01081c] border-[#1a2847] text-white">
                  <SelectItem value="block">Bloquear</SelectItem>
                  <SelectItem value="allow">Permitir</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Aplicar em</Label>
              <Tabs value={targetType} onValueChange={setTargetType}>
                <TabsList className="grid w-full grid-cols-2 bg-[#1a2847]">
                  <TabsTrigger value="categories">Categorias</TabsTrigger>
                  <TabsTrigger value="domains">Domínios Específicos</TabsTrigger>
                </TabsList>

                <TabsContent value="categories" className="space-y-2">
                  <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto p-2 bg-[#1a2847]/50 rounded-lg">
                    {categories.map((cat) => (
                      <div
                        key={cat.value}
                        className="flex items-center space-x-2 p-2 rounded hover:bg-[#1a2847] cursor-pointer"
                        onClick={() => toggleCategory(cat.value)}
                      >
                        <Checkbox
                          checked={formData.categories.includes(cat.value)}
                          className="border-gray-500"
                        />
                        <span className="text-sm">{cat.label}</span>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="domains" className="space-y-2">
                  <div className="max-h-48 overflow-y-auto p-2 bg-[#1a2847]/50 rounded-lg space-y-1">
                    {domains.length === 0 ? (
                      <p className="text-sm text-gray-400 text-center py-4">
                        Nenhum domínio disponível
                      </p>
                    ) : (
                      domains.map((domain) => (
                        <div
                          key={domain.id}
                          className="flex items-center space-x-2 p-2 rounded hover:bg-[#1a2847] cursor-pointer"
                          onClick={() => toggleDomain(domain.id)}
                        >
                          <Checkbox
                            checked={formData.domainIds.includes(domain.id)}
                            className="border-gray-500"
                          />
                          <span className="text-sm">{domain.domain}</span>
                        </div>
                      ))
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white shadow-lg shadow-indigo-500/20"
            >
              <Plus className="w-4 h-4 mr-2" />
              {isLoading ? "Salvando..." : schedule ? "Atualizar" : "Criar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}