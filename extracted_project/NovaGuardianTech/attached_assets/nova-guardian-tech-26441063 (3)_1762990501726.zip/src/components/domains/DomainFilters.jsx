import React from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function DomainFilters({ filters, setFilters }) {
  return (
    <div className="flex gap-3">
      <Select
        value={filters.category}
        onValueChange={(value) => setFilters({ ...filters, category: value })}
      >
        <SelectTrigger className="w-40 bg-[#01081c] border-[#1a2847] text-white">
          <SelectValue placeholder="Categoria" />
        </SelectTrigger>
        <SelectContent className="bg-[#01081c] border-[#1a2847] text-white">
          <SelectItem value="all">Todas</SelectItem>
          <SelectItem value="social_media">Redes Sociais</SelectItem>
          <SelectItem value="streaming">Streaming</SelectItem>
          <SelectItem value="gaming">Jogos</SelectItem>
          <SelectItem value="adult">Adulto</SelectItem>
          <SelectItem value="gambling">Apostas</SelectItem>
          <SelectItem value="malware">Malware</SelectItem>
          <SelectItem value="phishing">Phishing</SelectItem>
          <SelectItem value="ads">Anúncios</SelectItem>
          <SelectItem value="tracking">Rastreamento</SelectItem>
          <SelectItem value="other">Outro</SelectItem>
        </SelectContent>
      </Select>

      <Select
        value={filters.status}
        onValueChange={(value) => setFilters({ ...filters, status: value })}
      >
        <SelectTrigger className="w-32 bg-[#01081c] border-[#1a2847] text-white">
          <SelectValue placeholder="Status" />
        </SelectTrigger>
        <SelectContent className="bg-[#01081c] border-[#1a2847] text-white">
          <SelectItem value="all">Todos</SelectItem>
          <SelectItem value="active">Ativos</SelectItem>
          <SelectItem value="inactive">Inativos</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}