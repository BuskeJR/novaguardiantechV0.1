import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tag, X, Plus } from "lucide-react";

export default function BulkTagsDialog({ open, onClose, onApply, selectedCount }) {
  const [tags, setTags] = useState([]);
  const [inputValue, setInputValue] = useState("");

  const handleAddTag = () => {
    if (inputValue.trim() && !tags.includes(inputValue.trim())) {
      setTags([...tags, inputValue.trim()]);
      setInputValue("");
    }
  };

  const handleRemoveTag = (tagToRemove) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleSubmit = () => {
    onApply(tags);
    setTags([]);
    setInputValue("");
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddTag();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#01081c] border-[#1a2847] text-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Tag className="w-5 h-5 text-purple-400" />
            Adicionar Tags em Massa
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Adicione tags aos {selectedCount} domínios selecionados
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Nova Tag</Label>
            <div className="flex gap-2">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Digite uma tag..."
                className="bg-[#1a2847] border-[#1a2847] text-white"
              />
              <Button
                onClick={handleAddTag}
                disabled={!inputValue.trim()}
                className="bg-[#1284e1] hover:bg-[#0d5fb8]"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {tags.length > 0 && (
            <div className="space-y-2">
              <Label>Tags a adicionar:</Label>
              <div className="flex flex-wrap gap-2 p-3 bg-[#1a2847] rounded-lg">
                {tags.map((tag) => (
                  <Badge
                    key={tag}
                    className="bg-purple-500/20 text-purple-400 border-purple-500/30 flex items-center gap-1 px-3 py-1"
                  >
                    {tag}
                    <button
                      onClick={() => handleRemoveTag(tag)}
                      className="ml-1 hover:text-purple-200"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <p className="text-xs text-gray-500">
            Pressione Enter para adicionar múltiplas tags
          </p>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={onClose}
            className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
          >
            Cancelar
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={tags.length === 0}
            className="bg-purple-500 hover:bg-purple-600"
          >
            <Tag className="w-4 h-4 mr-2" />
            Aplicar Tags
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}