import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Activity, TrendingUp, Zap } from "lucide-react";
import { motion } from "framer-motion";

export default function StatsOverview({ domains, logs }) {
  const totalBlocks = domains.reduce((sum, d) => sum + (d.blockCount || 0), 0);
  const activeDomains = domains.filter(d => d.isActive).length;
  const logsInPeriod = logs.length;
  const avgBlocksPerDay = logs.filter(l => l.action === 'domain_blocked').length;

  const stats = [
    {
      title: "Domínios Ativos",
      value: activeDomains,
      icon: Shield,
      color: "from-blue-500 to-blue-600"
    },
    {
      title: "Total de Bloqueios",
      value: totalBlocks,
      icon: Activity,
      color: "from-red-500 to-red-600"
    },
    {
      title: "Atividades no Período",
      value: logsInPeriod,
      icon: TrendingUp,
      color: "from-green-500 to-green-600"
    },
    {
      title: "Bloqueios no Período",
      value: avgBlocksPerDay,
      icon: Zap,
      color: "from-purple-500 to-purple-600"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] hover:border-[#1284e1]/50 transition-all">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-lg`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <p className="text-gray-400 text-sm mb-1">{stat.title}</p>
              <p className="text-3xl font-bold text-white">{stat.value.toLocaleString()}</p>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}