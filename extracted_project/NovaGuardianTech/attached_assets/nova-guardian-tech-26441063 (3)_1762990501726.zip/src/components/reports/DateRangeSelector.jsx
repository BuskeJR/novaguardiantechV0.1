import React from "react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Calendar as CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function DateRangeSelector({ dateRange, setDateRange }) {
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className="bg-[#01081c] border-[#1a2847] text-white hover:bg-[#1a2847]"
        >
          <CalendarIcon className="w-4 h-4 mr-2" />
          {format(dateRange.from, "dd/MM/yyyy", { locale: ptBR })} - {format(dateRange.to, "dd/MM/yyyy", { locale: ptBR })}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0 bg-[#01081c] border-[#1a2847]" align="end">
        <div className="p-4 space-y-4">
          <div>
            <p className="text-sm text-gray-400 mb-2">Data Inicial</p>
            <Calendar
              mode="single"
              selected={dateRange.from}
              onSelect={(date) => date && setDateRange({ ...dateRange, from: date })}
              className="rounded-md border-[#1a2847]"
            />
          </div>
          <div>
            <p className="text-sm text-gray-400 mb-2">Data Final</p>
            <Calendar
              mode="single"
              selected={dateRange.to}
              onSelect={(date) => date && setDateRange({ ...dateRange, to: date })}
              className="rounded-md border-[#1a2847]"
            />
          </div>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => setDateRange({
                from: new Date(new Date().setDate(new Date().getDate() - 7)),
                to: new Date()
              })}
              className="flex-1 bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
            >
              7 dias
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setDateRange({
                from: new Date(new Date().setDate(new Date().getDate() - 30)),
                to: new Date()
              })}
              className="flex-1 bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
            >
              30 dias
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setDateRange({
                from: new Date(new Date().setDate(new Date().getDate() - 90)),
                to: new Date()
              })}
              className="flex-1 bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
            >
              90 dias
            </Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}