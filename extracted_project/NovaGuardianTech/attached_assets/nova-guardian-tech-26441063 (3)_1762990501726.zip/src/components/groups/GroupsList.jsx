import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Layers, Edit, Trash2, Folder } from "lucide-react";
import { motion } from "framer-motion";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function GroupsList({ groups, domains, isLoading, onEdit, onToggle, onDelete }) {
  const getDomainCount = (domainIds) => {
    if (!domainIds) return 0;
    return domainIds.length;
  };

  if (isLoading) {
    return (
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <Card key={i} className="bg-[#01081c] border-[#1a2847] animate-pulse">
            <CardContent className="p-6">
              <div className="h-6 bg-[#1a2847] rounded w-2/3 mb-4" />
              <div className="h-4 bg-[#1a2847] rounded w-full" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (groups.length === 0) {
    return (
      <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
        <CardContent className="p-12 text-center">
          <div className="w-20 h-20 mx-auto mb-6 bg-amber-500/10 rounded-2xl flex items-center justify-center">
            <Folder className="w-10 h-10 text-amber-400" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">Nenhum grupo criado</h3>
          <p className="text-gray-400 max-w-md mx-auto">
            Crie grupos para organizar seus domínios bloqueados de forma eficiente
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
      {groups.map((group, index) => (
        <motion.div
          key={group.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          whileHover={{ scale: 1.02, y: -5 }}
        >
          <Card 
            className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] hover:border-amber-500/50 transition-all duration-300 h-full"
            style={{ borderColor: group.color ? `${group.color}40` : undefined }}
          >
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div 
                  className="w-14 h-14 rounded-xl flex items-center justify-center shadow-lg"
                  style={{ 
                    backgroundColor: group.color ? `${group.color}20` : '#f59e0b20',
                    color: group.color || '#f59e0b'
                  }}
                >
                  <Layers className="w-7 h-7" />
                </div>
                <Switch
                  checked={group.isActive}
                  onCheckedChange={(checked) => onToggle(group.id, checked)}
                  className="data-[state=checked]:bg-amber-500"
                />
              </div>

              <h3 className="text-xl font-bold text-white mb-2">{group.name}</h3>
              {group.description && (
                <p className="text-gray-400 text-sm mb-4">{group.description}</p>
              )}

              <div className="flex items-center gap-2 mb-4">
                <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/30">
                  {getDomainCount(group.domainIds)} domínios
                </Badge>
              </div>

              <div className="flex items-center gap-2 pt-4 border-t border-[#1a2847]">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onEdit(group)}
                  className="flex-1 text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Editar
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="flex-1 text-red-400 hover:text-red-300 hover:bg-red-500/10"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Excluir
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="bg-[#01081c] border-[#1a2847]">
                    <AlertDialogHeader>
                      <AlertDialogTitle className="text-white">Excluir Grupo</AlertDialogTitle>
                      <AlertDialogDescription className="text-gray-400">
                        Tem certeza que deseja excluir o grupo "{group.name}"? Os domínios não serão excluídos.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]">
                        Cancelar
                      </AlertDialogCancel>
                      <AlertDialogAction
                        onClick={() => onDelete(group.id)}
                        className="bg-red-500 hover:bg-red-600 text-white"
                      >
                        Excluir
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}