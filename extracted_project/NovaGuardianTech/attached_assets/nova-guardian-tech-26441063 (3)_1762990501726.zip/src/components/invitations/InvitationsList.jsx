import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Mail, RefreshCw, XCircle, Clock, CheckCircle, AlertCircle, Shield, User } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const statusConfig = {
  pending: {
    color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/30",
    icon: Clock,
    label: "Pendente"
  },
  accepted: {
    color: "bg-green-500/10 text-green-400 border-green-500/30",
    icon: CheckCircle,
    label: "Aceito"
  },
  expired: {
    color: "bg-red-500/10 text-red-400 border-red-500/30",
    icon: AlertCircle,
    label: "Expirado"
  }
};

export default function InvitationsList({ invitations, isLoading, onResend, onCancel }) {
  const isExpired = (expiresAt) => {
    return new Date(expiresAt) < new Date();
  };

  if (isLoading) {
    return (
      <Card className="bg-[#01081c] border-[#1a2847]">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-[#1a2847] hover:bg-transparent">
                <TableHead className="text-gray-400">Email</TableHead>
                <TableHead className="text-gray-400">Papel</TableHead>
                <TableHead className="text-gray-400">Status</TableHead>
                <TableHead className="text-gray-400">Enviado por</TableHead>
                <TableHead className="text-gray-400">Expira em</TableHead>
                <TableHead className="text-gray-400">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(3)].map((_, i) => (
                <TableRow key={i} className="border-[#1a2847]">
                  <TableCell><Skeleton className="h-4 w-48 bg-[#1a2847]" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-20 bg-[#1a2847]" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-24 bg-[#1a2847]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-32 bg-[#1a2847]" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24 bg-[#1a2847]" /></TableCell>
                  <TableCell><Skeleton className="h-8 w-24 bg-[#1a2847]" /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    );
  }

  if (invitations.length === 0) {
    return (
      <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
        <CardContent className="p-12 text-center">
          <div className="w-20 h-20 mx-auto mb-6 bg-purple-500/10 rounded-2xl flex items-center justify-center">
            <Mail className="w-10 h-10 text-purple-400" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">Nenhum convite enviado</h3>
          <p className="text-gray-400 max-w-md mx-auto">
            Comece convidando membros para sua organização usando o botão "Convidar Usuário"
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-[#01081c] border-[#1a2847]">
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow className="border-[#1a2847] hover:bg-transparent">
              <TableHead className="text-gray-400">Email</TableHead>
              <TableHead className="text-gray-400">Papel</TableHead>
              <TableHead className="text-gray-400">Status</TableHead>
              <TableHead className="text-gray-400">Enviado por</TableHead>
              <TableHead className="text-gray-400">Expira em</TableHead>
              <TableHead className="text-gray-400">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {invitations.map((invitation) => {
              const config = statusConfig[invitation.status] || statusConfig.pending;
              const StatusIcon = config.icon;
              const expired = isExpired(invitation.expiresAt);
              const actualStatus = expired && invitation.status === 'pending' ? 'expired' : invitation.status;
              const actualConfig = statusConfig[actualStatus];
              const ActualIcon = actualConfig.icon;

              return (
                <TableRow key={invitation.id} className="border-[#1a2847] hover:bg-[#1a2847]">
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-gray-400" />
                      <span className="text-white font-medium">{invitation.email}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="outline" 
                      className={invitation.role === 'admin' 
                        ? "bg-purple-500/10 text-purple-400 border-purple-500/30" 
                        : "bg-blue-500/10 text-blue-400 border-blue-500/30"
                      }
                    >
                      {invitation.role === 'admin' ? (
                        <><Shield className="w-3 h-3 mr-1" /> Admin</>
                      ) : (
                        <><User className="w-3 h-3 mr-1" /> Usuário</>
                      )}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={actualConfig.color}>
                      <ActualIcon className="w-3 h-3 mr-1" />
                      {actualConfig.label}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-gray-300">{invitation.invitedBy}</TableCell>
                  <TableCell className="text-gray-400">
                    {expired ? (
                      <span className="text-red-400">Expirado</span>
                    ) : (
                      format(new Date(invitation.expiresAt), "dd/MM/yyyy", { locale: ptBR })
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {invitation.status === 'pending' && (
                        <>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onResend(invitation)}
                            className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                            title="Reenviar convite"
                          >
                            <RefreshCw className="w-4 h-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                                title="Cancelar convite"
                              >
                                <XCircle className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent className="bg-[#01081c] border-[#1a2847]">
                              <AlertDialogHeader>
                                <AlertDialogTitle className="text-white">Cancelar Convite</AlertDialogTitle>
                                <AlertDialogDescription className="text-gray-400">
                                  Tem certeza que deseja cancelar o convite para{" "}
                                  <span className="font-semibold text-white">{invitation.email}</span>?
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]">
                                  Voltar
                                </AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => onCancel(invitation.id)}
                                  className="bg-red-500 hover:bg-red-600 text-white"
                                >
                                  Cancelar Convite
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </>
                      )}
                      {invitation.status === 'accepted' && (
                        <span className="text-xs text-gray-500">
                          Aceito em {format(new Date(invitation.acceptedAt), "dd/MM/yyyy", { locale: ptBR })}
                        </span>
                      )}
                      {invitation.status === 'expired' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onResend(invitation)}
                          className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                        >
                          <RefreshCw className="w-4 h-4 mr-1" />
                          Reenviar
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}