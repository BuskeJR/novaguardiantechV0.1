import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, Plus, Edit, Trash2, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function AlertsPage() {
  const [user, setUser] = useState(null);
  const [showDialog, setShowDialog] = useState(false);
  const [editingAlert, setEditingAlert] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: alerts = [] } = useQuery({
    queryKey: ['alerts', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.Alert.filter({ tenantId: user.tenantId });
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const createAlertMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.Alert.create({
        ...data,
        tenantId: user.tenantId,
        createdBy: user.email,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['alerts'] });
      toast.success("✓ Alerta criado!");
      setShowDialog(false);
      setEditingAlert(null);
    },
  });

  const updateAlertMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.Alert.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['alerts'] });
      toast.success("✓ Alerta atualizado!");
    },
  });

  const deleteAlertMutation = useMutation({
    mutationFn: async (id) => {
      return await base44.entities.Alert.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['alerts'] });
      toast.success("✓ Alerta removido!");
    },
  });

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-yellow-500 rounded-full opacity-5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-orange-500 rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-between items-center mb-8"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg shadow-yellow-500/20">
              <Bell className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Alertas Configuráveis</h1>
              <p className="text-gray-400">Seja notificado quando eventos importantes acontecerem</p>
            </div>
          </div>
          <Button
            onClick={() => {
              setEditingAlert(null);
              setShowDialog(true);
            }}
            className="bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Novo Alerta
          </Button>
        </motion.div>

        {alerts.length === 0 ? (
          <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
            <CardContent className="p-12 text-center">
              <Bell className="w-16 h-16 mx-auto mb-4 text-gray-400" />
              <h3 className="text-xl font-semibold text-white mb-2">Nenhum alerta configurado</h3>
              <p className="text-gray-400 mb-6">Crie seu primeiro alerta para ser notificado sobre eventos importantes</p>
              <Button
                onClick={() => setShowDialog(true)}
                className="bg-gradient-to-r from-yellow-500 to-orange-600"
              >
                <Plus className="w-4 h-4 mr-2" />
                Criar Primeiro Alerta
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {alerts.map((alert, index) => (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] hover:border-yellow-500/50 transition-all">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-white flex items-center gap-2 mb-2">
                          {alert.name}
                          {alert.isActive ? (
                            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                              Ativo
                            </Badge>
                          ) : (
                            <Badge className="bg-gray-500/20 text-gray-400 border-gray-500/30">
                              Inativo
                            </Badge>
                          )}
                        </CardTitle>
                        <p className="text-sm text-gray-400 capitalize">
                          {alert.type.replace(/_/g, ' ')}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            setEditingAlert(alert);
                            setShowDialog(true);
                          }}
                          className="text-blue-400 hover:text-blue-300"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => deleteAlertMutation.mutate(alert.id)}
                          className="text-red-400 hover:text-red-300"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {alert.threshold && (
                      <div className="flex items-center justify-between p-3 bg-[#1a2847] rounded">
                        <span className="text-gray-400 text-sm">Limite</span>
                        <span className="text-white font-semibold">{alert.threshold}</span>
                      </div>
                    )}
                    <div className="flex items-center justify-between p-3 bg-[#1a2847] rounded">
                      <span className="text-gray-400 text-sm">Período</span>
                      <span className="text-white capitalize">{alert.period}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400 text-sm">Notificar Email</span>
                      <Switch
                        checked={alert.notifyEmail}
                        onCheckedChange={(checked) =>
                          updateAlertMutation.mutate({
                            id: alert.id,
                            data: { notifyEmail: checked }
                          })
                        }
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-400 text-sm">Notificar no App</span>
                      <Switch
                        checked={alert.notifyInApp}
                        onCheckedChange={(checked) =>
                          updateAlertMutation.mutate({
                            id: alert.id,
                            data: { notifyInApp: checked }
                          })
                        }
                      />
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}

        <AlertDialog
          open={showDialog}
          onClose={() => {
            setShowDialog(false);
            setEditingAlert(null);
          }}
          alert={editingAlert}
          onSave={createAlertMutation.mutate}
          isLoading={createAlertMutation.isPending}
        />
      </div>
    </div>
  );
}

function AlertDialog({ open, onClose, alert, onSave, isLoading }) {
  const [formData, setFormData] = useState({
    name: "",
    type: "blocks_threshold",
    threshold: 100,
    period: "day",
    notifyEmail: true,
    notifyInApp: true,
    isActive: true,
  });

  useEffect(() => {
    if (alert) {
      setFormData(alert);
    }
  }, [alert]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#01081c] border-[#1a2847] text-white">
        <DialogHeader>
          <DialogTitle>{alert ? "Editar Alerta" : "Novo Alerta"}</DialogTitle>
          <DialogDescription className="text-gray-400">
            Configure quando e como você quer ser notificado
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Nome do Alerta</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-[#1a2847] border-[#1a2847] text-white"
                placeholder="Ex: Muitos bloqueios hoje"
                required
              />
            </div>

            <div className="space-y-2">
              <Label>Tipo de Alerta</Label>
              <Select
                value={formData.type}
                onValueChange={(value) => setFormData({ ...formData, type: value })}
              >
                <SelectTrigger className="bg-[#1a2847] border-[#1a2847] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#01081c] border-[#1a2847] text-white">
                  <SelectItem value="blocks_threshold">Limite de Bloqueios</SelectItem>
                  <SelectItem value="domain_added">Domínio Adicionado</SelectItem>
                  <SelectItem value="user_activity">Atividade de Usuário</SelectItem>
                  <SelectItem value="system_health">Saúde do Sistema</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.type === "blocks_threshold" && (
              <div className="space-y-2">
                <Label>Limite de Bloqueios</Label>
                <Input
                  type="number"
                  value={formData.threshold}
                  onChange={(e) => setFormData({ ...formData, threshold: parseInt(e.target.value) })}
                  className="bg-[#1a2847] border-[#1a2847] text-white"
                  min="1"
                  required
                />
              </div>
            )}

            <div className="space-y-2">
              <Label>Período de Análise</Label>
              <Select
                value={formData.period}
                onValueChange={(value) => setFormData({ ...formData, period: value })}
              >
                <SelectTrigger className="bg-[#1a2847] border-[#1a2847] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#01081c] border-[#1a2847] text-white">
                  <SelectItem value="hour">Por Hora</SelectItem>
                  <SelectItem value="day">Por Dia</SelectItem>
                  <SelectItem value="week">Por Semana</SelectItem>
                  <SelectItem value="month">Por Mês</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between p-3 bg-[#1a2847] rounded">
              <Label>Notificar por Email</Label>
              <Switch
                checked={formData.notifyEmail}
                onCheckedChange={(checked) => setFormData({ ...formData, notifyEmail: checked })}
              />
            </div>

            <div className="flex items-center justify-between p-3 bg-[#1a2847] rounded">
              <Label>Notificar no App</Label>
              <Switch
                checked={formData.notifyInApp}
                onCheckedChange={(checked) => setFormData({ ...formData, notifyInApp: checked })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="bg-[#1284e1] hover:bg-[#0d5fb8]"
            >
              {isLoading ? "Salvando..." : "Salvar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}