import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Layers, Plus, Search } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import GroupsList from "../components/groups/GroupsList";
import AddGroupDialog from "../components/groups/AddGroupDialog";

export default function GroupsPage() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingGroup, setEditingGroup] = useState(null);

  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: groups = [], isLoading: groupsLoading } = useQuery({
    queryKey: ['groups', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.DomainGroup.filter({ tenantId: user.tenantId }, '-created_date');
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const { data: domains = [] } = useQuery({
    queryKey: ['domains', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.Domain.filter({ tenantId: user.tenantId });
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const createGroupMutation = useMutation({
    mutationFn: async (data) => {
      return await base44.entities.DomainGroup.create({
        ...data,
        tenantId: user.tenantId,
        createdBy: user.email,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      toast.success("✓ Grupo criado!");
      setShowAddDialog(false);
      setEditingGroup(null);
    },
    onError: () => {
      toast.error("✗ Erro ao criar grupo");
    },
  });

  const updateGroupMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.DomainGroup.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      toast.success("✓ Grupo atualizado!");
      setShowAddDialog(false);
      setEditingGroup(null);
    },
  });

  const toggleGroupMutation = useMutation({
    mutationFn: async ({ id, isActive }) => {
      return await base44.entities.DomainGroup.update(id, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      toast.success("✓ Status atualizado!");
    },
  });

  const deleteGroupMutation = useMutation({
    mutationFn: async (id) => {
      await base44.entities.DomainGroup.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['groups'] });
      toast.success("✓ Grupo removido!");
    },
  });

  const filteredGroups = groups.filter(group =>
    group.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-amber-500 rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-amber-600 rounded-xl flex items-center justify-center shadow-lg shadow-amber-500/20">
              <Layers className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Grupos de Domínios</h1>
              <p className="text-gray-400">Organize domínios em grupos personalizados</p>
            </div>
          </div>
          <Button
            onClick={() => {
              setEditingGroup(null);
              setShowAddDialog(true);
            }}
            className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white shadow-lg shadow-amber-500/30"
          >
            <Plus className="w-4 h-4 mr-2" />
            Novo Grupo
          </Button>
        </motion.div>

        <Card className="bg-[#01081c] border-[#1a2847] mb-6">
          <CardHeader>
            <CardTitle className="text-white">Buscar</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Buscar grupo..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-[#1a2847] border-[#1a2847] text-white"
              />
            </div>
          </CardContent>
        </Card>

        <GroupsList
          groups={filteredGroups}
          domains={domains}
          isLoading={groupsLoading}
          onEdit={(group) => {
            setEditingGroup(group);
            setShowAddDialog(true);
          }}
          onToggle={(id, isActive) => toggleGroupMutation.mutate({ id, isActive })}
          onDelete={(id) => deleteGroupMutation.mutate(id)}
        />

        <AddGroupDialog
          open={showAddDialog}
          onClose={() => {
            setShowAddDialog(false);
            setEditingGroup(null);
          }}
          group={editingGroup}
          domains={domains}
          onSave={(data) => {
            if (editingGroup) {
              updateGroupMutation.mutate({ id: editingGroup.id, data });
            } else {
              createGroupMutation.mutate(data);
            }
          }}
          isLoading={createGroupMutation.isPending || updateGroupMutation.isPending}
        />
      </div>
    </div>
  );
}