import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CheckCircle, XCircle, Loader2, Activity, Globe } from "lucide-react";
import { motion } from "framer-motion";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function DNSTestPage() {
  const [testing, setTesting] = useState(false);
  const [results, setResults] = useState(null);
  const [testDomain, setTestDomain] = useState("facebook.com");

  const dnsServers = {
    primary: "10.0.0.1",
    secondary: "10.0.0.2"
  };

  const runDNSTest = async () => {
    setTesting(true);
    setResults(null);

    // Simulate DNS test
    await new Promise(resolve => setTimeout(resolve, 2000));

    const mockResults = {
      dnsConfigured: Math.random() > 0.3,
      primaryReachable: Math.random() > 0.2,
      secondaryReachable: Math.random() > 0.2,
      blockingWorks: Math.random() > 0.3,
      latency: Math.floor(Math.random() * 50) + 10,
      testedDomain: testDomain,
    };

    setResults(mockResults);
    setTesting(false);
  };

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-green-500 rounded-full opacity-5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-blue-500 rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg shadow-green-500/20">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Teste de Conexão DNS</h1>
              <p className="text-gray-400">Verifique se o DNS está configurado corretamente</p>
            </div>
          </div>
        </motion.div>

        <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] mb-6">
          <CardHeader>
            <CardTitle className="text-white">Configuração DNS Atual</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4 mb-6">
              <div className="p-4 bg-[#1a2847] rounded-lg">
                <p className="text-gray-400 text-sm mb-1">DNS Primário</p>
                <code className="text-xl font-bold text-white">{dnsServers.primary}</code>
              </div>
              <div className="p-4 bg-[#1a2847] rounded-lg">
                <p className="text-gray-400 text-sm mb-1">DNS Secundário</p>
                <code className="text-xl font-bold text-white">{dnsServers.secondary}</code>
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-gray-300">Testar com Domínio</Label>
                <Input
                  value={testDomain}
                  onChange={(e) => setTestDomain(e.target.value)}
                  placeholder="exemplo.com"
                  className="bg-[#1a2847] border-[#1a2847] text-white"
                />
                <p className="text-xs text-gray-500">
                  Digite um domínio que você bloqueou para testar
                </p>
              </div>

              <Button
                onClick={runDNSTest}
                disabled={testing || !testDomain}
                className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
              >
                {testing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Testando Conexão...
                  </>
                ) : (
                  <>
                    <Activity className="w-4 h-4 mr-2" />
                    Iniciar Teste
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {results && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  {results.dnsConfigured && results.primaryReachable ? (
                    <>
                      <CheckCircle className="w-5 h-5 text-green-400" />
                      Teste Concluído com Sucesso
                    </>
                  ) : (
                    <>
                      <XCircle className="w-5 h-5 text-red-400" />
                      Problemas Detectados
                    </>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <TestResult
                  label="DNS Configurado"
                  passed={results.dnsConfigured}
                  message={results.dnsConfigured ? 
                    "Seu dispositivo está usando os servidores DNS do NovaGuardian" :
                    "Seu dispositivo não está usando os servidores DNS configurados"
                  }
                />

                <TestResult
                  label="Servidor Primário"
                  passed={results.primaryReachable}
                  message={results.primaryReachable ?
                    `Servidor primário (${dnsServers.primary}) está acessível` :
                    `Não foi possível acessar o servidor primário (${dnsServers.primary})`
                  }
                />

                <TestResult
                  label="Servidor Secundário"
                  passed={results.secondaryReachable}
                  message={results.secondaryReachable ?
                    `Servidor secundário (${dnsServers.secondary}) está acessível` :
                    `Não foi possível acessar o servidor secundário (${dnsServers.secondary})`
                  }
                />

                <TestResult
                  label="Bloqueio Funcionando"
                  passed={results.blockingWorks}
                  message={results.blockingWorks ?
                    `O domínio ${results.testedDomain} está sendo bloqueado corretamente` :
                    `O domínio ${results.testedDomain} não está sendo bloqueado`
                  }
                />

                <div className="p-4 bg-[#1a2847] rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Latência Média</span>
                    <span className={`font-bold ${
                      results.latency < 30 ? 'text-green-400' :
                      results.latency < 50 ? 'text-yellow-400' :
                      'text-red-400'
                    }`}>
                      {results.latency}ms
                    </span>
                  </div>
                </div>

                {!results.dnsConfigured && (
                  <Alert className="bg-yellow-500/10 border-yellow-500/30">
                    <AlertDescription className="text-yellow-400">
                      <strong>Ação necessária:</strong> Configure os servidores DNS nas configurações de rede do seu dispositivo.
                      Consulte o Guia DNS para instruções detalhadas.
                    </AlertDescription>
                  </Alert>
                )}

                {results.dnsConfigured && !results.blockingWorks && (
                  <Alert className="bg-blue-500/10 border-blue-500/30">
                    <AlertDescription className="text-blue-400">
                      <strong>Dica:</strong> Pode levar alguns minutos para as configurações DNS serem aplicadas.
                      Tente limpar o cache DNS do seu dispositivo.
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}

        <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] mt-6">
          <CardHeader>
            <CardTitle className="text-white">Comandos Úteis</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-gray-400 text-sm mb-2">Limpar cache DNS (Windows):</p>
              <code className="block p-3 bg-[#1a2847] rounded text-green-400 text-sm">
                ipconfig /flushdns
              </code>
            </div>
            <div>
              <p className="text-gray-400 text-sm mb-2">Limpar cache DNS (macOS/Linux):</p>
              <code className="block p-3 bg-[#1a2847] rounded text-green-400 text-sm">
                sudo dscacheutil -flushcache; sudo killall -HUP mDNSResponder
              </code>
            </div>
            <div>
              <p className="text-gray-400 text-sm mb-2">Ver DNS atual (Windows):</p>
              <code className="block p-3 bg-[#1a2847] rounded text-green-400 text-sm">
                nslookup google.com
              </code>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function TestResult({ label, passed, message }) {
  return (
    <div className="flex items-start gap-3 p-4 bg-[#1a2847]/50 rounded-lg">
      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
        passed ? 'bg-green-500/20' : 'bg-red-500/20'
      }`}>
        {passed ? (
          <CheckCircle className="w-5 h-5 text-green-400" />
        ) : (
          <XCircle className="w-5 h-5 text-red-400" />
        )}
      </div>
      <div className="flex-1">
        <h4 className="text-white font-semibold mb-1">{label}</h4>
        <p className="text-gray-400 text-sm">{message}</p>
      </div>
    </div>
  );
}