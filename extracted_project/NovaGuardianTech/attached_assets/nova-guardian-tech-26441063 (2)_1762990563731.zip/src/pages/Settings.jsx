import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { User, Building, Phone, Save, Key } from "lucide-react";

export default function SettingsPage() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    full_name: "",
    company: "",
    phone: "",
  });

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      setFormData({
        full_name: currentUser.full_name || "",
        company: currentUser.company || "",
        phone: currentUser.phone || "",
      });
    } catch (error) {
      console.error("Error loading user:", error);
    } finally {
      setLoading(false);
    }
  };

  const updateProfileMutation = useMutation({
    mutationFn: async (data) => {
      await base44.auth.updateMe(data);
      
      await base44.entities.BlockLog.create({
        action: "settings_changed",
        userId: user.id,
        userEmail: user.email,
        tenantId: user.tenantId,
        details: { fields_updated: Object.keys(data) },
      });
    },
    onSuccess: () => {
      toast.success("Perfil atualizado com sucesso!");
      loadUser();
    },
    onError: () => {
      toast.error("Erro ao atualizar perfil");
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    updateProfileMutation.mutate(formData);
  };

  if (loading) {
    return (
      <div className="p-4 md:p-8 min-h-screen flex items-center justify-center">
        <div className="text-white">Carregando...</div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Configurações</h1>
          <p className="text-gray-400">Gerencie suas informações pessoais e preferências</p>
        </div>

        <div className="space-y-6">
          <Card className="bg-[#01081c] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <User className="w-5 h-5" />
                Informações da Conta
              </CardTitle>
              <CardDescription className="text-gray-400">
                Seus dados pessoais e de contato
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-gray-300">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={user?.email || ""}
                    disabled
                    className="bg-[#1a2847] border-[#1a2847] text-gray-400"
                  />
                  <p className="text-xs text-gray-500">O email não pode ser alterado</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="full_name" className="text-gray-300">Nome Completo</Label>
                  <Input
                    id="full_name"
                    value={formData.full_name}
                    onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                    className="bg-[#1a2847] border-[#1a2847] text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="company" className="text-gray-300">Empresa</Label>
                  <div className="relative">
                    <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      id="company"
                      value={formData.company}
                      onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                      className="pl-10 bg-[#1a2847] border-[#1a2847] text-white"
                      placeholder="Nome da sua empresa"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-gray-300">Telefone</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="pl-10 bg-[#1a2847] border-[#1a2847] text-white"
                      placeholder="(00) 00000-0000"
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={updateProfileMutation.isPending}
                  className="bg-[#1284e1] hover:bg-[#0d5fb8] text-white"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Salvar Alterações
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card className="bg-[#01081c] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Key className="w-5 h-5" />
                Informações da Conta
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-white font-medium">Nível de Acesso</p>
                  <p className="text-sm text-gray-400">Seu papel no sistema</p>
                </div>
                <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                  user?.role === 'admin' 
                    ? 'bg-purple-500/20 text-purple-400' 
                    : 'bg-blue-500/20 text-blue-400'
                }`}>
                  {user?.role === 'admin' ? 'Administrador' : 'Usuário'}
                </div>
              </div>

              <Separator className="bg-[#1a2847]" />

              <div className="flex justify-between items-center">
                <div>
                  <p className="text-white font-medium">ID do Tenant</p>
                  <p className="text-sm text-gray-400">Identificador único da organização</p>
                </div>
                <code className="px-3 py-1 bg-[#1a2847] rounded text-sm text-gray-300 font-mono">
                  {user?.tenantId || "N/A"}
                </code>
              </div>

              <Separator className="bg-[#1a2847]" />

              <div className="flex justify-between items-center">
                <div>
                  <p className="text-white font-medium">Conta Criada</p>
                  <p className="text-sm text-gray-400">Data de registro</p>
                </div>
                <p className="text-gray-300">
                  {new Date(user?.created_date).toLocaleDateString('pt-BR')}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}