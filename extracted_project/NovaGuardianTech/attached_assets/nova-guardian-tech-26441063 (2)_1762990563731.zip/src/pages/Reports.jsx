import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart, Download, TrendingUp, Calendar, FileText } from "lucide-react";
import { motion } from "framer-motion";
import { 
  LineChart, 
  Line, 
  BarChart as RechartsBarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from "recharts";
import { format, subDays, startOfDay, endOfDay } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";
import DateRangeSelector from "../components/reports/DateRangeSelector";
import StatsOverview from "../components/reports/StatsOverview";

const COLORS = ['#1284e1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export default function ReportsPage() {
  const [user, setUser] = useState(null);
  const [dateRange, setDateRange] = useState({
    from: subDays(new Date(), 30),
    to: new Date()
  });

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: domains = [] } = useQuery({
    queryKey: ['domains', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.Domain.filter({ tenantId: user.tenantId });
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const { data: logs = [] } = useQuery({
    queryKey: ['logs', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.BlockLog.filter({ tenantId: user.tenantId }, '-created_date', 1000);
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  // Filter logs by date range
  const filteredLogs = logs.filter(log => {
    const logDate = new Date(log.created_date);
    return logDate >= startOfDay(dateRange.from) && logDate <= endOfDay(dateRange.to);
  });

  // Generate timeline data
  const generateTimelineData = () => {
    const days = [];
    let currentDate = new Date(dateRange.from);
    
    while (currentDate <= dateRange.to) {
      const dayLogs = filteredLogs.filter(log => {
        const logDate = new Date(log.created_date);
        return format(logDate, 'yyyy-MM-dd') === format(currentDate, 'yyyy-MM-dd');
      });

      days.push({
        date: format(currentDate, 'dd/MM'),
        bloqueios: dayLogs.filter(l => l.action === 'domain_blocked').length,
        adicionados: dayLogs.filter(l => l.action === 'domain_added').length,
        removidos: dayLogs.filter(l => l.action === 'domain_removed').length,
      });

      currentDate = new Date(currentDate.setDate(currentDate.getDate() + 1));
    }

    return days;
  };

  // Category distribution
  const categoryData = domains.reduce((acc, domain) => {
    const cat = domain.category || 'other';
    const existing = acc.find(item => item.name === cat);
    if (existing) {
      existing.value += 1;
      existing.blocks += domain.blockCount || 0;
    } else {
      acc.push({ 
        name: cat.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
        value: 1,
        blocks: domain.blockCount || 0
      });
    }
    return acc;
  }, []);

  // Top blocked domains
  const topBlocked = [...domains]
    .sort((a, b) => (b.blockCount || 0) - (a.blockCount || 0))
    .slice(0, 10)
    .map(d => ({
      domain: d.domain,
      blocks: d.blockCount || 0
    }));

  // Activity by action type
  const activityByType = filteredLogs.reduce((acc, log) => {
    const existing = acc.find(item => item.name === log.action);
    if (existing) {
      existing.count += 1;
    } else {
      acc.push({ name: log.action, count: 1 });
    }
    return acc;
  }, []);

  const exportToPDF = () => {
    toast.info("Exportação em PDF será implementada em breve");
  };

  const timelineData = generateTimelineData();

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-[#1284e1] rounded-full opacity-5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-green-500 rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg shadow-green-500/20">
              <BarChart className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Relatórios & Analytics</h1>
              <p className="text-gray-400">Análise detalhada da sua proteção DNS</p>
            </div>
          </div>
          <div className="flex gap-3">
            <DateRangeSelector dateRange={dateRange} setDateRange={setDateRange} />
            <Button
              onClick={exportToPDF}
              variant="outline"
              className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
            >
              <Download className="w-4 h-4 mr-2" />
              Exportar PDF
            </Button>
          </div>
        </motion.div>

        <StatsOverview domains={domains} logs={filteredLogs} />

        {/* Timeline Chart */}
        <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] mb-6">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              Linha do Tempo de Atividades
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={timelineData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a2847" />
                <XAxis dataKey="date" stroke="#9ca3af" />
                <YAxis stroke="#9ca3af" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#01081c', 
                    border: '1px solid #1a2847',
                    borderRadius: '8px',
                    color: '#fff'
                  }}
                />
                <Legend />
                <Line type="monotone" dataKey="bloqueios" stroke="#ef4444" strokeWidth={2} name="Bloqueios" />
                <Line type="monotone" dataKey="adicionados" stroke="#10b981" strokeWidth={2} name="Adicionados" />
                <Line type="monotone" dataKey="removidos" stroke="#f59e0b" strokeWidth={2} name="Removidos" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-2 gap-6 mb-6">
          {/* Category Distribution */}
          <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white">Distribuição por Categoria</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#01081c', 
                      border: '1px solid #1a2847',
                      borderRadius: '8px',
                      color: '#fff'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Top Blocked Domains */}
          <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white">Top 10 Domínios Bloqueados</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <RechartsBarChart data={topBlocked} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#1a2847" />
                  <XAxis type="number" stroke="#9ca3af" />
                  <YAxis type="category" dataKey="domain" stroke="#9ca3af" width={120} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#01081c', 
                      border: '1px solid #1a2847',
                      borderRadius: '8px',
                      color: '#fff'
                    }}
                  />
                  <Bar dataKey="blocks" fill="#ef4444" radius={[0, 8, 8, 0]} />
                </RechartsBarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Activity Summary */}
        <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-400" />
              Resumo de Atividades no Período
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {activityByType.map((activity, index) => (
                <div key={activity.name} className="p-4 bg-[#1a2847] rounded-lg">
                  <p className="text-gray-400 text-sm mb-1 capitalize">
                    {activity.name.replace(/_/g, ' ')}
                  </p>
                  <p className="text-2xl font-bold text-white">{activity.count}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}