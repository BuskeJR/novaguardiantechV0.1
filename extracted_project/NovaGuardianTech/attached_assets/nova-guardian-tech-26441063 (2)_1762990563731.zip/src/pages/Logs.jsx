
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Download, Filter } from "lucide-react";
import { toast } from "sonner";
import LogTable from "../components/logs/LogTable.jsx";
import LogFilters from "../components/logs/LogFilters.jsx";

export default function LogsPage() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({
    action: "all",
    dateRange: "all",
  });

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: logs = [], isLoading } = useQuery({
    queryKey: ['logs', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.BlockLog.filter({ tenantId: user.tenantId }, '-created_date', 100);
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const filteredLogs = logs.filter(log => {
    const matchesSearch = 
      log.domain?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.userEmail?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.action?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesAction = filters.action === "all" || log.action === filters.action;
    
    let matchesDate = true;
    if (filters.dateRange !== "all") {
      const logDate = new Date(log.created_date);
      const now = new Date();
      
      if (filters.dateRange === "today") {
        matchesDate = logDate.toDateString() === now.toDateString();
      } else if (filters.dateRange === "week") {
        const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        matchesDate = logDate >= weekAgo;
      } else if (filters.dateRange === "month") {
        const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        matchesDate = logDate >= monthAgo;
      }
    }
    
    return matchesSearch && matchesAction && matchesDate;
  });

  const exportToCsv = () => {
    const headers = ["Data/Hora", "Ação", "Domínio", "Usuário", "IP"];
    const rows = filteredLogs.map(log => [
      new Date(log.created_date).toLocaleString('pt-BR'),
      log.action,
      log.domain || "-",
      log.userEmail || "-",
      log.ipAddress || "-"
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `logs_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    toast.success("Logs exportados com sucesso!");
  };

  return (
    <div className="p-4 md:p-8 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Logs de Atividade</h1>
            <p className="text-gray-400">Histórico completo de todas as ações</p>
          </div>
          <Button
            onClick={exportToCsv}
            disabled={filteredLogs.length === 0}
            className="bg-[#1284e1] hover:bg-[#0d5fb8] text-white"
          >
            <Download className="w-4 h-4 mr-2" />
            Exportar CSV
          </Button>
        </div>

        <Card className="bg-[#01081c] border-[#1a2847] mb-6">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Filtros
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Buscar por domínio, usuário ou ação..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-[#1a2847] border-[#1a2847] text-white"
                />
              </div>
              <LogFilters filters={filters} setFilters={setFilters} />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#01081c] border-[#1a2847]">
          <CardContent className="p-0">
            <LogTable logs={filteredLogs} isLoading={isLoading} />
          </CardContent>
        </Card>

        {filteredLogs.length === 0 && !isLoading && (
          <div className="text-center py-16">
            <div className="w-20 h-20 mx-auto mb-4 bg-[#1a2847] rounded-full flex items-center justify-center">
              <Search className="w-10 h-10 text-gray-400" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Nenhum log encontrado</h3>
            <p className="text-gray-400">Tente ajustar os filtros de busca</p>
          </div>
        )}
      </div>
    </div>
  );
}
