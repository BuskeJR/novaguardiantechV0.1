import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Settings2, Save, Shield, Ban, Palette, Bell } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function SystemConfigPage() {
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: config, isLoading } = useQuery({
    queryKey: ['system-config', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return null;
      const configs = await base44.entities.SystemConfig.filter({ tenantId: user.tenantId });
      if (configs.length > 0) return configs[0];
      
      // Create default config
      return await base44.entities.SystemConfig.create({
        tenantId: user.tenantId,
        logRetentionDays: 90,
        requirePasswordChange: false,
        passwordChangeDays: 90,
        invitationExpiryDays: 7,
        theme: "dark",
        allowUserRegistration: false,
        maintenanceMode: false,
        emailNotifications: true,
        maxDomainsPerTenant: 10000,
        enableAdvancedAnalytics: true,
      });
    },
    enabled: !!user?.tenantId && user?.role === 'admin',
  });

  const updateConfigMutation = useMutation({
    mutationFn: async (data) => {
      if (!config?.id) return;
      return await base44.entities.SystemConfig.update(config.id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['system-config'] });
      toast.success("✓ Configurações salvas!");
    },
    onError: () => {
      toast.error("✗ Erro ao salvar configurações");
    },
  });

  const handleSave = (field, value) => {
    updateConfigMutation.mutate({ [field]: value });
  };

  if (user?.role !== 'admin') {
    return (
      <div className="p-4 md:p-8 min-h-screen">
        <Alert className="bg-red-500/10 border-red-500/20 max-w-7xl mx-auto">
          <Ban className="h-4 w-4 text-red-500" />
          <AlertDescription className="text-red-400">
            Apenas administradores podem acessar as configurações do sistema.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  if (isLoading || !config) {
    return (
      <div className="p-4 md:p-8 min-h-screen flex items-center justify-center">
        <div className="text-white">Carregando configurações...</div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-purple-500 rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Settings2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Configurações do Sistema</h1>
              <p className="text-gray-400">Gerencie políticas e preferências globais</p>
            </div>
          </div>
        </motion.div>

        <div className="space-y-6">
          {/* Security Settings */}
          <Card className="bg-[#01081c] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Shield className="w-5 h-5 text-blue-400" />
                Segurança
              </CardTitle>
              <CardDescription className="text-gray-400">
                Políticas de segurança e autenticação
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-white">Exigir Troca de Senha Periódica</Label>
                  <p className="text-sm text-gray-400">Usuários devem trocar senha periodicamente</p>
                </div>
                <Switch
                  checked={config.requirePasswordChange}
                  onCheckedChange={(checked) => handleSave('requirePasswordChange', checked)}
                  className="data-[state=checked]:bg-blue-500"
                />
              </div>

              {config.requirePasswordChange && (
                <div className="space-y-2">
                  <Label>Dias para Expiração de Senha</Label>
                  <Input
                    type="number"
                    value={config.passwordChangeDays}
                    onChange={(e) => handleSave('passwordChangeDays', parseInt(e.target.value))}
                    className="bg-[#1a2847] border-[#1a2847] text-white"
                    min="30"
                    max="365"
                  />
                </div>
              )}

              <Separator className="bg-[#1a2847]" />

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-white">Permitir Auto-Registro</Label>
                  <p className="text-sm text-gray-400">Novos usuários podem se registrar sem convite</p>
                </div>
                <Switch
                  checked={config.allowUserRegistration}
                  onCheckedChange={(checked) => handleSave('allowUserRegistration', checked)}
                  className="data-[state=checked]:bg-blue-500"
                />
              </div>

              <Separator className="bg-[#1a2847]" />

              <div className="space-y-2">
                <Label>Validade dos Convites (dias)</Label>
                <Input
                  type="number"
                  value={config.invitationExpiryDays}
                  onChange={(e) => handleSave('invitationExpiryDays', parseInt(e.target.value))}
                  className="bg-[#1a2847] border-[#1a2847] text-white"
                  min="1"
                  max="30"
                />
                <p className="text-xs text-gray-500">Tempo que um convite permanece válido</p>
              </div>
            </CardContent>
          </Card>

          {/* Data Management */}
          <Card className="bg-[#01081c] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Settings2 className="w-5 h-5 text-green-400" />
                Gerenciamento de Dados
              </CardTitle>
              <CardDescription className="text-gray-400">
                Retenção e limites de dados
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Retenção de Logs (dias)</Label>
                <Input
                  type="number"
                  value={config.logRetentionDays}
                  onChange={(e) => handleSave('logRetentionDays', parseInt(e.target.value))}
                  className="bg-[#1a2847] border-[#1a2847] text-white"
                  min="7"
                  max="365"
                />
                <p className="text-xs text-gray-500">Logs mais antigos serão automaticamente excluídos</p>
              </div>

              <Separator className="bg-[#1a2847]" />

              <div className="space-y-2">
                <Label>Máximo de Domínios por Tenant</Label>
                <Input
                  type="number"
                  value={config.maxDomainsPerTenant}
                  onChange={(e) => handleSave('maxDomainsPerTenant', parseInt(e.target.value))}
                  className="bg-[#1a2847] border-[#1a2847] text-white"
                  min="100"
                  max="100000"
                />
                <p className="text-xs text-gray-500">Limite de domínios que podem ser bloqueados</p>
              </div>
            </CardContent>
          </Card>

          {/* Appearance */}
          <Card className="bg-[#01081c] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Palette className="w-5 h-5 text-purple-400" />
                Aparência
              </CardTitle>
              <CardDescription className="text-gray-400">
                Personalização visual do sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label>Tema do Sistema</Label>
                <Select
                  value={config.theme}
                  onValueChange={(value) => handleSave('theme', value)}
                >
                  <SelectTrigger className="bg-[#1a2847] border-[#1a2847] text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#01081c] border-[#1a2847] text-white">
                    <SelectItem value="dark">Escuro</SelectItem>
                    <SelectItem value="light">Claro</SelectItem>
                    <SelectItem value="auto">Automático</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500">Tema visual da interface</p>
              </div>
            </CardContent>
          </Card>

          {/* Notifications */}
          <Card className="bg-[#01081c] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Bell className="w-5 h-5 text-yellow-400" />
                Notificações
              </CardTitle>
              <CardDescription className="text-gray-400">
                Preferências de notificações
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-white">Notificações por Email</Label>
                  <p className="text-sm text-gray-400">Enviar notificações importantes por email</p>
                </div>
                <Switch
                  checked={config.emailNotifications}
                  onCheckedChange={(checked) => handleSave('emailNotifications', checked)}
                  className="data-[state=checked]:bg-yellow-500"
                />
              </div>

              <Separator className="bg-[#1a2847]" />

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-white">Analytics Avançado</Label>
                  <p className="text-sm text-gray-400">Habilitar análises detalhadas de uso</p>
                </div>
                <Switch
                  checked={config.enableAdvancedAnalytics}
                  onCheckedChange={(checked) => handleSave('enableAdvancedAnalytics', checked)}
                  className="data-[state=checked]:bg-yellow-500"
                />
              </div>
            </CardContent>
          </Card>

          {/* Maintenance */}
          <Card className="bg-[#01081c] border-[#1a2847]">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Settings2 className="w-5 h-5 text-red-400" />
                Manutenção
              </CardTitle>
              <CardDescription className="text-gray-400">
                Modo de manutenção do sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-white">Modo Manutenção</Label>
                  <p className="text-sm text-gray-400">Desabilitar acesso temporariamente</p>
                </div>
                <Switch
                  checked={config.maintenanceMode}
                  onCheckedChange={(checked) => handleSave('maintenanceMode', checked)}
                  className="data-[state=checked]:bg-red-500"
                />
              </div>
              {config.maintenanceMode && (
                <Alert className="mt-4 bg-red-500/10 border-red-500/20">
                  <Ban className="h-4 w-4 text-red-500" />
                  <AlertDescription className="text-red-400 text-sm">
                    <strong>Atenção:</strong> O sistema está em modo manutenção. Apenas administradores têm acesso.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}