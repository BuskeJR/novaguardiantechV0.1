
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Download, Grid3x3, List, Shield, Upload } from "lucide-react";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import DomainCard from "../components/domains/DomainCard";
import DomainTable from "../components/domains/DomainTable";
import AddDomainDialog from "../components/domains/AddDomainDialog";
import DomainFilters from "../components/domains/DomainFilters";
import ImportDomainsDialog from "../components/domains/ImportDomainsDialog";
import BulkActionsBar from "../components/domains/BulkActionsBar";
import BulkTagsDialog from "../components/domains/BulkTagsDialog";

export default function DomainsPage() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [showBulkTagsDialog, setShowBulkTagsDialog] = useState(false);
  const [viewMode, setViewMode] = useState("grid");
  const [selectedDomains, setSelectedDomains] = useState([]);
  const [filters, setFilters] = useState({
    category: "all",
    status: "all",
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: domains = [], isLoading } = useQuery({
    queryKey: ['domains', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.Domain.filter({ tenantId: user.tenantId }, '-created_date');
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const addDomainMutation = useMutation({
    mutationFn: async (domainData) => {
      const variations = generateVariations(domainData.domain);
      
      const domain = await base44.entities.Domain.create({
        ...domainData,
        tenantId: user.tenantId,
        addedBy: user.email,
        variations,
      });

      await base44.entities.BlockLog.create({
        action: "domain_added",
        domain: domainData.domain,
        userId: user.id,
        userEmail: user.email,
        tenantId: user.tenantId,
        details: { category: domainData.category },
      });

      return domain;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['domains'] });
      queryClient.invalidateQueries({ queryKey: ['logs'] });
      toast.success("✓ Domínio adicionado com sucesso!");
      setShowAddDialog(false);
    },
    onError: () => {
      toast.error("✗ Erro ao adicionar domínio");
    },
  });

  const toggleDomainMutation = useMutation({
    mutationFn: async ({ domain, newStatus }) => {
      const updated = await base44.entities.Domain.update(domain.id, {
        isActive: newStatus,
      });

      await base44.entities.BlockLog.create({
        action: newStatus ? "domain_activated" : "domain_deactivated",
        domain: domain.domain,
        userId: user.id,
        userEmail: user.email,
        tenantId: user.tenantId,
      });

      return updated;
    },
    onSuccess: (_, { newStatus }) => {
      queryClient.invalidateQueries({ queryKey: ['domains'] });
      queryClient.invalidateQueries({ queryKey: ['logs'] });
      toast.success(newStatus ? "✓ Domínio ativado" : "✓ Domínio desativado");
    },
  });

  const deleteDomainMutation = useMutation({
    mutationFn: async (domain) => {
      await base44.entities.BlockLog.create({
        action: "domain_removed",
        domain: domain.domain,
        userId: user.id,
        userEmail: user.email,
        tenantId: user.tenantId,
      });

      await base44.entities.Domain.delete(domain.id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['domains'] });
      queryClient.invalidateQueries({ queryKey: ['logs'] });
      toast.success("✓ Domínio removido com sucesso!");
    },
    onError: () => {
      toast.error("✗ Erro ao remover domínio");
    },
  });

  const importDomainsMutation = useMutation({
    mutationFn: async ({ domains, category }) => {
      if (!user?.tenantId || !user?.email || !user?.id) {
        throw new Error("User information is missing for import.");
      }

      const results = [];
      for (const domain of domains) {
        try {
          const variations = generateVariations(domain);
          const created = await base44.entities.Domain.create({
            domain,
            category,
            tenantId: user.tenantId,
            addedBy: user.email,
            variations,
            isActive: true,
          });
          results.push(created);

          await base44.entities.BlockLog.create({
            action: "domain_imported",
            domain: domain,
            userId: user.id,
            userEmail: user.email,
            tenantId: user.tenantId,
            details: { category: category },
          });

        } catch (error) {
          console.error(`Error importing ${domain}:`, error);
          // Optionally log failed imports or add to a separate 'failed' array
        }
      }
      return results;
    },
    onSuccess: (results) => {
      queryClient.invalidateQueries({ queryKey: ['domains'] });
      queryClient.invalidateQueries({ queryKey: ['logs'] }); // Invalidate logs to show import actions
      if (results.length > 0) {
        toast.success(`✓ ${results.length} domínios importados com sucesso!`);
      } else {
        toast.info("Nenhum domínio foi importado com sucesso. Verifique o console para erros.");
      }
      setShowImportDialog(false);
    },
    onError: (error) => {
      console.error("Import mutation error:", error);
      toast.error("✗ Erro ao importar domínios. " + (error.message || "Tente novamente."));
    },
  });

  const bulkUpdateMutation = useMutation({
    mutationFn: async ({ domainIds, updates }) => {
      const promises = domainIds.map(id => 
        base44.entities.Domain.update(id, updates)
      );
      return await Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['domains'] });
      setSelectedDomains([]);
      toast.success("✓ Domínios atualizados com sucesso!");
    },
    onError: () => {
      toast.error("✗ Erro ao atualizar domínios em massa.");
    },
  });

  const bulkDeleteMutation = useMutation({
    mutationFn: async (domainIds) => {
      const promises = domainIds.map(id => base44.entities.Domain.delete(id));
      return await Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['domains'] });
      setSelectedDomains([]);
      toast.success("✓ Domínios removidos com sucesso!");
    },
    onError: () => {
      toast.error("✗ Erro ao remover domínios em massa.");
    },
  });

  const bulkAddTagsMutation = useMutation({
    mutationFn: async ({ domainIds, tags }) => {
      const promises = domainIds.map(async (id) => {
        const domain = domains.find(d => d.id === id);
        const currentTags = domain?.tags || [];
        const newTags = [...new Set([...currentTags, ...tags])]; // Merge and remove duplicates
        return await base44.entities.Domain.update(id, { tags: newTags });
      });
      return await Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['domains'] });
      setSelectedDomains([]);
      toast.success("✓ Tags adicionadas com sucesso!");
      setShowBulkTagsDialog(false);
    },
    onError: () => {
      toast.error("✗ Erro ao adicionar tags em massa.");
    },
  });

  const handleSelectDomain = (domainId) => {
    setSelectedDomains(prev => 
      prev.includes(domainId) 
        ? prev.filter(id => id !== domainId)
        : [...prev, domainId]
    );
  };

  const handleSelectAll = () => {
    if (selectedDomains.length === filteredDomains.length) {
      setSelectedDomains([]);
    } else {
      setSelectedDomains(filteredDomains.map(d => d.id));
    }
  };

  const handleBulkActivate = () => {
    bulkUpdateMutation.mutate({ domainIds: selectedDomains, updates: { isActive: true } });
  };

  const handleBulkDeactivate = () => {
    bulkUpdateMutation.mutate({ domainIds: selectedDomains, updates: { isActive: false } });
  };

  const handleBulkChangeCategory = (category) => {
    bulkUpdateMutation.mutate({ domainIds: selectedDomains, updates: { category } });
  };

  const handleBulkDelete = () => {
    if (confirm(`Tem certeza que deseja remover ${selectedDomains.length} domínios? Esta ação é irreversível.`)) {
      bulkDeleteMutation.mutate(selectedDomains);
    }
  };

  const handleBulkAddTags = (tags) => {
    bulkAddTagsMutation.mutate({ domainIds: selectedDomains, tags });
  };

  const generateVariations = (domain) => {
    const base = domain.replace(/^(www\.|cdn\.|api\.)/, '');
    return [
      base,
      `www.${base}`,
      `cdn.${base}`,
      `api.${base}`,
      `m.${base}`,
    ];
  };

  const filteredDomains = domains.filter(domain => {
    const matchesSearch = domain.domain.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filters.category === "all" || domain.category === filters.category;
    const matchesStatus = filters.status === "all" || 
      (filters.status === "active" && domain.isActive) ||
      (filters.status === "inactive" && !domain.isActive);
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const exportToTxt = () => {
    const content = filteredDomains.map(d => d.domain).join('\n');
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'domains.txt';
    a.click();
    toast.success("✓ Exportado com sucesso para TXT!");
  };

  const exportToJson = () => {
    const content = JSON.stringify(filteredDomains, null, 2);
    const blob = new Blob([content], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'domains.json';
    a.click();
    toast.success("✓ Exportado com sucesso para JSON!");
  };

  const exportToPDF = async () => {
    const content = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Relatório de Domínios - NovaGuardian</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 40px; color: #333; }
    h1 { color: #1284e1; font-size: 28px; margin-bottom: 10px; }
    h2 { color: #1284e1; font-size: 22px; margin-top: 30px; margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 5px; }
    p { margin-bottom: 5px; line-height: 1.5; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; table-layout: fixed; }
    th, td { border: 1px solid #ddd; padding: 12px; text-align: left; word-wrap: break-word; }
    th { background-color: #1284e1; color: white; font-weight: bold; }
    tr:nth-child(even) { background-color: #f9f9f9; }
    .stats { margin: 20px 0; padding: 15px; background: #eef7ff; border-radius: 8px; border: 1px solid #d0e7ff; }
    .stats h3 { color: #0d5fb8; margin-top: 0; margin-bottom: 10px; }
    .status-active { color: #28a745; font-weight: bold; }
    .status-inactive { color: #dc3545; font-weight: bold; }
    .block-count { font-weight: bold; color: #666; }
    .tag { display: inline-block; background-color: #f0f0f0; border-radius: 3px; padding: 3px 6px; margin-right: 4px; margin-bottom: 4px; font-size: 0.85em; color: #555; }
  </style>
</head>
<body>
  <h1>📊 Relatório de Domínios Bloqueados</h1>
  <p>Gerado em: ${new Date().toLocaleString('pt-BR')}</p>
  
  <div class="stats">
    <h3>Estatísticas</h3>
    <p><strong>Total de Domínios Listados:</strong> ${filteredDomains.length}</p>
    <p><strong>Domínios Ativos:</strong> ${filteredDomains.filter(d => d.isActive).length}</p>
    <p><strong>Total de Bloqueios Registrados:</strong> ${filteredDomains.reduce((sum, d) => sum + (d.blockCount || 0), 0)}</p>
  </div>

  <h2>Lista de Domínios</h2>
  <table>
    <thead>
      <tr>
        <th style="width: 30%;">Domínio</th>
        <th style="width: 20%;">Categoria</th>
        <th style="width: 15%;">Status</th>
        <th style="width: 10%;">Bloqueios</th>
        <th style="width: 25%;">Tags</th>
      </tr>
    </thead>
    <tbody>
      ${filteredDomains.map(d => `
        <tr>
          <td>${d.domain}</td>
          <td>${(d.category ? d.category.replace(/_/g, ' ') : 'N/A')}</td>
          <td class="${d.isActive ? 'status-active' : 'status-inactive'}">${d.isActive ? '✓ Ativo' : '✗ Inativo'}</td>
          <td class="block-count">${d.blockCount || 0}</td>
          <td>${(d.tags && d.tags.length > 0 ? d.tags.map(tag => `<span class="tag">${tag}</span>`).join('') : '-')}</td>
        </tr>
      `).join('')}
    </tbody>
  </table>
</body>
</html>
    `;

    const blob = new Blob([content], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `relatorio_dominios_${new Date().toISOString().split('T')[0]}.html`;
    a.click();
    URL.revokeObjectURL(url); // Clean up the URL object
    toast.success("✓ Relatório exportado! Abra o arquivo HTML no navegador e use 'Imprimir como PDF' para salvar.");
  };

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-[400px] h-[400px] bg-[#1284e1] rounded-full opacity-5 blur-3xl" />
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-purple-500 rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-[#1284e1] to-[#0d5fb8] rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Domínios Bloqueados</h1>
              <p className="text-gray-400">Gerencie os domínios protegidos pelo DNS</p>
            </div>
          </div>
          <div className="flex gap-3 flex-wrap">
            <Button
              variant="outline"
              onClick={exportToTxt}
              className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847] hover:border-[#1284e1]/50 transition-all"
            >
              <Download className="w-4 h-4 mr-2" />
              TXT
            </Button>
            <Button
              variant="outline"
              onClick={exportToJson}
              className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847] hover:border-[#1284e1]/50 transition-all"
            >
              <Download className="w-4 h-4 mr-2" />
              JSON
            </Button>
            <Button
              variant="outline"
              onClick={exportToPDF}
              className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847] hover:border-[#1284e1]/50 transition-all"
            >
              <Download className="w-4 h-4 mr-2" />
              PDF
            </Button>
            <Button
              variant="outline"
              onClick={() => setShowImportDialog(true)}
              className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847] hover:border-[#1284e1]/50 transition-all"
            >
              <Upload className="w-4 h-4 mr-2" />
              Importar
            </Button>
            {selectedDomains.length === 0 && (
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  onClick={() => setShowAddDialog(true)}
                  className="bg-gradient-to-r from-[#1284e1] to-[#0d5fb8] hover:from-[#0d5fb8] hover:to-[#1284e1] text-white shadow-lg shadow-blue-500/30"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar Domínio
                </Button>
              </motion.div>
            )}
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex flex-col md:flex-row gap-4 mb-6"
        >
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Buscar domínio..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-[#01081c] border-[#1a2847] text-white focus:border-[#1284e1] transition-all"
            />
          </div>
          <DomainFilters filters={filters} setFilters={setFilters} />
          <div className="flex gap-2 border border-[#1a2847] rounded-lg p-1 bg-[#01081c]">
            <Button
              variant={viewMode === "grid" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("grid")}
              className={viewMode === "grid" ? "bg-[#1284e1]" : ""}
            >
              <Grid3x3 className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("list")}
              className={viewMode === "list" ? "bg-[#1284e1]" : ""}
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </motion.div>

        {/* Domain Cards/Table with selection */}
        <AnimatePresence mode="wait">
          {viewMode === "grid" ? (
            <motion.div
              key="grid"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {filteredDomains.map((domain, index) => (
                <motion.div
                  key={domain.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="relative"
                >
                  <input
                    type="checkbox"
                    checked={selectedDomains.includes(domain.id)}
                    onChange={() => handleSelectDomain(domain.id)}
                    className="absolute top-4 left-4 z-10 w-5 h-5 rounded border-2 border-[#1284e1] bg-[#01081c] checked:bg-[#1284e1] appearance-none cursor-pointer focus:ring-2 focus:ring-[#1284e1] focus:ring-offset-2 focus:ring-offset-[#01081c]"
                  />
                  <DomainCard
                    domain={domain}
                    onToggle={(newStatus) => toggleDomainMutation.mutate({ domain, newStatus })}
                    onDelete={() => deleteDomainMutation.mutate(domain)}
                  />
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <motion.div
              key="list"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <DomainTable
                domains={filteredDomains}
                selectedDomains={selectedDomains}
                onSelect={handleSelectDomain}
                onSelectAll={handleSelectAll}
                onToggle={(domain, newStatus) => toggleDomainMutation.mutate({ domain, newStatus })}
                onDelete={(domain) => deleteDomainMutation.mutate(domain)}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {filteredDomains.length === 0 && !isLoading && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-20"
          >
            <motion.div
              animate={{ 
                scale: [1, 1.1, 1],
                rotate: [0, 5, -5, 0]
              }}
              transition={{ 
                duration: 2,
                repeat: Infinity,
                repeatDelay: 1
              }}
              className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-[#1a2847] to-[#0a1128] rounded-2xl flex items-center justify-center shadow-xl"
            >
              <Shield className="w-12 h-12 text-gray-400" />
            </motion.div>
            <h3 className="text-2xl font-bold text-white mb-3">Nenhum domínio encontrado</h3>
            <p className="text-gray-400 mb-8 max-w-md mx-auto">
              Adicione seu primeiro domínio para começar a proteger sua rede
            </p>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                onClick={() => setShowAddDialog(true)}
                size="lg"
                className="bg-gradient-to-r from-[#1284e1] to-[#0d5fb8] hover:from-[#0d5fb8] hover:to-[#1284e1] text-white shadow-lg shadow-blue-500/30"
              >
                <Plus className="w-5 h-5 mr-2" />
                Adicionar Primeiro Domínio
              </Button>
            </motion.div>
          </motion.div>
        )}

        <AddDomainDialog
          open={showAddDialog}
          onClose={() => setShowAddDialog(false)}
          onAdd={(data) => addDomainMutation.mutate(data)}
          isLoading={addDomainMutation.isPending}
        />

        <ImportDomainsDialog
          open={showImportDialog}
          onClose={() => setShowImportDialog(false)}
          onImport={(domains, category) => importDomainsMutation.mutate({ domains, category })}
          isLoading={importDomainsMutation.isPending}
        />

        <BulkTagsDialog
          open={showBulkTagsDialog}
          onClose={() => setShowBulkTagsDialog(false)}
          onApply={handleBulkAddTags}
          selectedCount={selectedDomains.length}
        />

        <BulkActionsBar
          selectedCount={selectedDomains.length}
          onActivateAll={handleBulkActivate}
          onDeactivateAll={handleBulkDeactivate}
          onDeleteAll={handleBulkDelete}
          onChangeCategory={handleBulkChangeCategory}
          onAddTags={() => setShowBulkTagsDialog(true)}
          onClearSelection={() => setSelectedDomains([])}
        />
      </div>
    </div>
  );
}
