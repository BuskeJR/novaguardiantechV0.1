import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Code, Copy, CheckCircle, Book, Key, Zap } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

const apiEndpoints = [
  {
    method: 'GET',
    path: '/api/v1/domains',
    description: 'Listar todos os domínios',
    auth: true,
    params: [
      { name: 'tenantId', type: 'string', required: true, description: 'ID do tenant' },
      { name: 'limit', type: 'integer', required: false, description: 'Limite de resultados' },
    ],
    response: `{
  "data": [
    {
      "id": "domain_123",
      "domain": "facebook.com",
      "category": "social_media",
      "isActive": true,
      "blockCount": 42,
      "created_date": "2025-01-01T00:00:00Z"
    }
  ],
  "total": 1
}`,
  },
  {
    method: 'POST',
    path: '/api/v1/domains',
    description: 'Adicionar novo domínio',
    auth: true,
    body: `{
  "domain": "example.com",
  "category": "other",
  "isActive": true,
  "tenantId": "tenant_123"
}`,
    response: `{
  "id": "domain_456",
  "domain": "example.com",
  "category": "other",
  "isActive": true,
  "created_date": "2025-01-01T00:00:00Z"
}`,
  },
  {
    method: 'GET',
    path: '/api/v1/logs',
    description: 'Buscar logs de atividade',
    auth: true,
    params: [
      { name: 'tenantId', type: 'string', required: true, description: 'ID do tenant' },
      { name: 'action', type: 'string', required: false, description: 'Filtrar por tipo de ação' },
      { name: 'limit', type: 'integer', required: false, description: 'Limite de resultados' },
    ],
    response: `{
  "data": [
    {
      "id": "log_789",
      "action": "domain_blocked",
      "domain": "facebook.com",
      "userEmail": "user@example.com",
      "created_date": "2025-01-01T12:00:00Z"
    }
  ],
  "total": 1
}`,
  },
  {
    method: 'PUT',
    path: '/api/v1/domains/:id',
    description: 'Atualizar domínio',
    auth: true,
    body: `{
  "isActive": false,
  "description": "Bloqueado temporariamente"
}`,
    response: `{
  "id": "domain_123",
  "domain": "facebook.com",
  "isActive": false,
  "updated_date": "2025-01-01T12:00:00Z"
}`,
  },
  {
    method: 'DELETE',
    path: '/api/v1/domains/:id',
    description: 'Remover domínio',
    auth: true,
    response: `{
  "success": true,
  "message": "Domínio removido com sucesso"
}`,
  },
];

export default function ApiDocsPage() {
  const [copiedCode, setCopiedCode] = useState(null);

  const copyCode = (code, id) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(id);
    toast.success("Código copiado!");
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-green-500 rounded-full opacity-5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-blue-500 rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg shadow-green-500/20">
              <Book className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Documentação da API</h1>
              <p className="text-gray-400">Integre o NovaGuardian com suas aplicações</p>
            </div>
          </div>
        </motion.div>

        <Tabs defaultValue="getting-started" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-[#1a2847]">
            <TabsTrigger value="getting-started">Começando</TabsTrigger>
            <TabsTrigger value="authentication">Autenticação</TabsTrigger>
            <TabsTrigger value="endpoints">Endpoints</TabsTrigger>
          </TabsList>

          {/* Getting Started */}
          <TabsContent value="getting-started">
            <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Zap className="w-5 h-5 text-yellow-400" />
                  Introdução
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">Base URL</h3>
                  <div className="bg-[#1a2847] p-4 rounded-lg font-mono text-green-400">
                    https://api.novaguardian.com/v1
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">Formato de Resposta</h3>
                  <p className="text-gray-400 mb-3">
                    Todas as respostas da API são retornadas no formato JSON.
                  </p>
                  <CodeBlock
                    code={`{
  "success": true,
  "data": { ... },
  "message": "Operação realizada com sucesso"
}`}
                    language="json"
                    onCopy={() => copyCode('{"success": true}', 'format')}
                    copied={copiedCode === 'format'}
                  />
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">Códigos de Status HTTP</h3>
                  <div className="space-y-2">
                    <StatusCode code="200" description="Requisição bem-sucedida" color="green" />
                    <StatusCode code="201" description="Recurso criado com sucesso" color="green" />
                    <StatusCode code="400" description="Erro na requisição" color="yellow" />
                    <StatusCode code="401" description="Não autenticado" color="red" />
                    <StatusCode code="403" description="Sem permissão" color="red" />
                    <StatusCode code="404" description="Recurso não encontrado" color="red" />
                    <StatusCode code="500" description="Erro interno do servidor" color="red" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Authentication */}
          <TabsContent value="authentication">
            <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Key className="w-5 h-5 text-blue-400" />
                  Autenticação
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">API Key</h3>
                  <p className="text-gray-400 mb-4">
                    Todas as requisições à API requerem uma chave de API válida. Inclua sua chave no header de autorização:
                  </p>
                  <CodeBlock
                    code={`Authorization: Bearer YOUR_API_KEY`}
                    language="http"
                    onCopy={() => copyCode('Authorization: Bearer YOUR_API_KEY', 'auth')}
                    copied={copiedCode === 'auth'}
                  />
                </div>

                <div>
                  <h3 className="text-xl font-semibold text-white mb-3">Exemplo de Requisição</h3>
                  <CodeBlock
                    code={`fetch('https://api.novaguardian.com/v1/domains', {
  method: 'GET',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  }
})
.then(response => response.json())
.then(data => console.log(data));`}
                    language="javascript"
                    onCopy={() => copyCode('fetch example', 'example')}
                    copied={copiedCode === 'example'}
                  />
                </div>

                <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4">
                  <p className="text-yellow-400 text-sm">
                    <strong>Importante:</strong> Nunca compartilhe sua API key publicamente. Mantenha-a segura e regenere-a se houver suspeita de comprometimento.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Endpoints */}
          <TabsContent value="endpoints">
            <div className="space-y-6">
              {apiEndpoints.map((endpoint, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
                    <CardHeader>
                      <div className="flex items-center gap-3 flex-wrap">
                        <Badge className={`${
                          endpoint.method === 'GET' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                          endpoint.method === 'POST' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                          endpoint.method === 'PUT' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' :
                          'bg-red-500/20 text-red-400 border-red-500/30'
                        } font-mono`}>
                          {endpoint.method}
                        </Badge>
                        <code className="text-white font-mono text-sm">{endpoint.path}</code>
                        {endpoint.auth && (
                          <Badge variant="outline" className="bg-purple-500/10 text-purple-400 border-purple-500/30">
                            <Key className="w-3 h-3 mr-1" />
                            Auth Required
                          </Badge>
                        )}
                      </div>
                      <p className="text-gray-400 mt-2">{endpoint.description}</p>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {endpoint.params && (
                        <div>
                          <h4 className="text-white font-semibold mb-2">Parâmetros</h4>
                          <div className="space-y-2">
                            {endpoint.params.map((param, i) => (
                              <div key={i} className="bg-[#1a2847] p-3 rounded-lg">
                                <div className="flex items-center gap-2 mb-1">
                                  <code className="text-blue-400">{param.name}</code>
                                  <Badge variant="outline" className="text-xs">{param.type}</Badge>
                                  {param.required && (
                                    <Badge className="bg-red-500/20 text-red-400 border-red-500/30 text-xs">
                                      required
                                    </Badge>
                                  )}
                                </div>
                                <p className="text-gray-400 text-sm">{param.description}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {endpoint.body && (
                        <div>
                          <h4 className="text-white font-semibold mb-2">Request Body</h4>
                          <CodeBlock
                            code={endpoint.body}
                            language="json"
                            onCopy={() => copyCode(endpoint.body, `body-${index}`)}
                            copied={copiedCode === `body-${index}`}
                          />
                        </div>
                      )}

                      <div>
                        <h4 className="text-white font-semibold mb-2">Response</h4>
                        <CodeBlock
                          code={endpoint.response}
                          language="json"
                          onCopy={() => copyCode(endpoint.response, `response-${index}`)}
                          copied={copiedCode === `response-${index}`}
                        />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function CodeBlock({ code, language, onCopy, copied }) {
  return (
    <div className="relative group">
      <pre className="bg-[#1a2847] p-4 rounded-lg overflow-x-auto">
        <code className="text-sm text-gray-300 font-mono">{code}</code>
      </pre>
      <Button
        size="icon"
        variant="ghost"
        onClick={onCopy}
        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-[#0a1128] hover:bg-[#1a2847]"
      >
        {copied ? (
          <CheckCircle className="w-4 h-4 text-green-400" />
        ) : (
          <Copy className="w-4 h-4 text-gray-400" />
        )}
      </Button>
    </div>
  );
}

function StatusCode({ code, description, color }) {
  const colors = {
    green: 'bg-green-500/10 text-green-400 border-green-500/30',
    yellow: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30',
    red: 'bg-red-500/10 text-red-400 border-red-500/30',
  };

  return (
    <div className="flex items-center gap-3 bg-[#1a2847] p-3 rounded-lg">
      <Badge className={`${colors[color]} font-mono`}>{code}</Badge>
      <span className="text-gray-400 text-sm">{description}</span>
    </div>
  );
}