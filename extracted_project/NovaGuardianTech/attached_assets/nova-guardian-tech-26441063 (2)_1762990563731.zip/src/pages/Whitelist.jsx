import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CheckCircle, Plus, Search, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import AddWhitelistDialog from "../components/whitelist/AddWhitelistDialog";

export default function WhitelistPage() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);

  const queryClient = useQueryClient();

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: whitelist = [], isLoading } = useQuery({
    queryKey: ['whitelist', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.Whitelist.filter({ tenantId: user.tenantId }, '-created_date');
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const addWhitelistMutation = useMutation({
    mutationFn: async (data) => {
      const entry = await base44.entities.Whitelist.create({
        ...data,
        tenantId: user.tenantId,
        addedBy: user.email,
      });

      await base44.entities.BlockLog.create({
        action: "settings_changed",
        domain: data.domain,
        userId: user.id,
        userEmail: user.email,
        tenantId: user.tenantId,
        details: { action: "whitelist_added" },
      });

      return entry;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['whitelist'] });
      toast.success("✓ Domínio adicionado à lista branca!");
      setShowAddDialog(false);
    },
    onError: () => {
      toast.error("✗ Erro ao adicionar domínio");
    },
  });

  const toggleWhitelistMutation = useMutation({
    mutationFn: async ({ id, isActive }) => {
      return await base44.entities.Whitelist.update(id, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['whitelist'] });
      toast.success("✓ Status atualizado");
    },
  });

  const deleteWhitelistMutation = useMutation({
    mutationFn: async (id) => {
      await base44.entities.Whitelist.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['whitelist'] });
      toast.success("✓ Removido da lista branca");
    },
  });

  const filteredWhitelist = whitelist.filter(item =>
    item.domain?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-[400px] h-[400px] bg-green-500 rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg shadow-green-500/20">
              <CheckCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Lista Branca</h1>
              <p className="text-gray-400">Domínios sempre permitidos</p>
            </div>
          </div>
          <Button
            onClick={() => setShowAddDialog(true)}
            className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white shadow-lg shadow-green-500/30"
          >
            <Plus className="w-4 h-4 mr-2" />
            Adicionar Domínio
          </Button>
        </motion.div>

        <Card className="bg-[#01081c] border-[#1a2847] mb-6">
          <CardHeader>
            <CardTitle className="text-white">Buscar</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Buscar domínio..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-[#1a2847] border-[#1a2847] text-white"
              />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#01081c] border-[#1a2847]">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="border-[#1a2847] hover:bg-transparent">
                  <TableHead className="text-gray-400">Domínio</TableHead>
                  <TableHead className="text-gray-400">Descrição</TableHead>
                  <TableHead className="text-gray-400">Adicionado por</TableHead>
                  <TableHead className="text-gray-400">Status</TableHead>
                  <TableHead className="text-gray-400">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredWhitelist.map((item) => (
                  <TableRow key={item.id} className="border-[#1a2847] hover:bg-[#1a2847]">
                    <TableCell className="text-white font-medium">{item.domain}</TableCell>
                    <TableCell className="text-gray-400">{item.description || "-"}</TableCell>
                    <TableCell className="text-gray-400">{item.addedBy}</TableCell>
                    <TableCell>
                      <Switch
                        checked={item.isActive}
                        onCheckedChange={(checked) => 
                          toggleWhitelistMutation.mutate({ id: item.id, isActive: checked })
                        }
                        className="data-[state=checked]:bg-green-500"
                      />
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteWhitelistMutation.mutate(item.id)}
                        className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <AddWhitelistDialog
          open={showAddDialog}
          onClose={() => setShowAddDialog(false)}
          onAdd={(data) => addWhitelistMutation.mutate(data)}
          isLoading={addWhitelistMutation.isPending}
        />
      </div>
    </div>
  );
}