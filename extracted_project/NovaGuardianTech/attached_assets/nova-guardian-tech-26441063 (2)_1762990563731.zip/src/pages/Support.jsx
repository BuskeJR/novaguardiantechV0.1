import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  MessageCircle, 
  Mail, 
  Book, 
  FileQuestion, 
  Send,
  CheckCircle,
  Search,
  ExternalLink
} from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "Como adicionar um novo domínio para bloqueio?",
    answer: "Acesse a página 'Domínios', clique em 'Adicionar Domínio', digite o domínio desejado (ex: facebook.com), selecione a categoria e clique em salvar. O bloqueio será ativado automaticamente."
  },
  {
    question: "Como configurar o DNS nos meus dispositivos?",
    answer: "Acesse a página 'Guia DNS' no menu lateral. Lá você encontrará instruções detalhadas para Windows, macOS, Linux, iOS e Android. Você também pode usar o QR Code para configuração rápida em dispositivos móveis."
  },
  {
    question: "Posso agendar bloqueios para horários específicos?",
    answer: "Sim! Acesse 'Agendamentos' no menu. Você pode criar regras para bloquear ou permitir domínios/categorias em horários e dias específicos da semana."
  },
  {
    question: "Como adicionar domínios à whitelist?",
    answer: "Vá para 'Lista Branca' e adicione os domínios que você deseja permitir sempre, mesmo que estejam em categorias bloqueadas. Isso é útil para sites de trabalho ou ferramentas essenciais."
  },
  {
    question: "Como convidar novos usuários para minha organização?",
    answer: "Apenas administradores podem convidar usuários. Acesse 'Convites' no menu de administração, clique em 'Convidar Usuário', digite o email e selecione a função (admin ou user)."
  },
  {
    question: "Como exportar meus logs e relatórios?",
    answer: "Na página de 'Logs', você pode exportar para CSV. Na página de 'Relatórios', você pode exportar análises em PDF. Ambas opções ficam no canto superior direito das respectivas páginas."
  },
  {
    question: "O que são grupos de domínios?",
    answer: "Grupos permitem organizar domínios em categorias personalizadas. Por exemplo, você pode criar um grupo 'Redes Sociais Empresariais' com LinkedIn e Slack, facilitando o gerenciamento."
  },
  {
    question: "Como mudar meu plano de assinatura?",
    answer: "Acesse 'Assinatura' no menu de administração. Lá você verá os planos disponíveis (Free, Pro, Enterprise) e pode fazer upgrade ou downgrade a qualquer momento."
  },
];

const resources = [
  {
    title: "Documentação da API",
    description: "Integre o NovaGuardian com seus sistemas",
    icon: Book,
    link: "/api-docs"
  },
  {
    title: "Guia de Configuração DNS",
    description: "Passo a passo para todos os dispositivos",
    icon: FileQuestion,
    link: "/dns-guide"
  },
  {
    title: "Central de Ajuda",
    description: "Artigos e tutoriais completos",
    icon: ExternalLink,
    external: "https://help.novaguardian.com"
  },
];

export default function SupportPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const [searchTerm, setSearchTerm] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    toast.success("✓ Mensagem enviada! Responderemos em breve.");
    setFormData({ name: "", email: "", subject: "", message: "" });
  };

  const filteredFaqs = faqs.filter(faq =>
    faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-blue-500 rounded-full opacity-5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-green-500 rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8 text-center"
        >
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-blue-500/20">
            <MessageCircle className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-3">Central de Suporte</h1>
          <p className="text-gray-400 text-lg">Como podemos ajudar você hoje?</p>
        </motion.div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {resources.map((resource, index) => (
            <motion.div
              key={resource.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] hover:border-blue-500/50 transition-all cursor-pointer h-full">
                <CardContent className="p-6">
                  <resource.icon className="w-10 h-10 text-blue-400 mb-4" />
                  <h3 className="text-white font-semibold mb-2">{resource.title}</h3>
                  <p className="text-gray-400 text-sm mb-4">{resource.description}</p>
                  <Button
                    variant="ghost"
                    className="text-blue-400 hover:text-blue-300 p-0"
                    onClick={() => {
                      if (resource.external) {
                        window.open(resource.external, '_blank');
                      } else {
                        window.location.hash = resource.link;
                      }
                    }}
                  >
                    Acessar <ExternalLink className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* FAQ Section */}
        <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] mb-8">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <FileQuestion className="w-5 h-5 text-green-400" />
              Perguntas Frequentes
            </CardTitle>
            <div className="relative mt-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Buscar nas perguntas..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-[#1a2847] border-[#1a2847] text-white"
              />
            </div>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="space-y-2">
              {filteredFaqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="bg-[#1a2847] border-[#1a2847] rounded-lg px-4"
                >
                  <AccordionTrigger className="text-white hover:text-blue-400 text-left">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-400">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
            {filteredFaqs.length === 0 && (
              <div className="text-center py-8">
                <Search className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-400">Nenhuma pergunta encontrada</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Contact Form */}
        <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Mail className="w-5 h-5 text-blue-400" />
              Entre em Contato
            </CardTitle>
            <p className="text-gray-400">Não encontrou o que procurava? Envie-nos uma mensagem!</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-gray-300">Nome *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="bg-[#1a2847] border-[#1a2847] text-white"
                    placeholder="Seu nome completo"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-gray-300">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                    className="bg-[#1a2847] border-[#1a2847] text-white"
                    placeholder="seu@email.com"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject" className="text-gray-300">Assunto *</Label>
                <Input
                  id="subject"
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  required
                  className="bg-[#1a2847] border-[#1a2847] text-white"
                  placeholder="Como podemos ajudar?"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message" className="text-gray-300">Mensagem *</Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  required
                  className="bg-[#1a2847] border-[#1a2847] text-white min-h-[150px]"
                  placeholder="Descreva sua dúvida ou problema em detalhes..."
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white"
              >
                <Send className="w-4 h-4 mr-2" />
                Enviar Mensagem
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Response Time */}
        <Card className="bg-green-500/10 border-green-500/20 mt-6">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-green-400" />
              <div>
                <p className="text-green-400 font-semibold">Tempo Médio de Resposta: 2-4 horas</p>
                <p className="text-gray-400 text-sm">Nossa equipe está disponível de segunda a sexta, das 9h às 18h</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}