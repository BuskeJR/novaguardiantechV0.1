import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Activity, Clock, TrendingUp, Zap, Globe } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { motion } from "framer-motion";
import StatsCard from "../components/dashboard/StatsCard";
import RecentActivity from "../components/dashboard/RecentActivity";
import TopDomains from "../components/dashboard/TopDomains";

const COLORS = ['#1284e1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export default function Dashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading user:", error);
    }
  };

  const { data: domains = [], isLoading: domainsLoading } = useQuery({
    queryKey: ['domains', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.Domain.filter({ tenantId: user.tenantId });
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const { data: logs = [], isLoading: logsLoading } = useQuery({
    queryKey: ['logs', user?.tenantId],
    queryFn: async () => {
      if (!user?.tenantId) return [];
      return await base44.entities.BlockLog.filter({ tenantId: user.tenantId }, '-created_date', 10);
    },
    enabled: !!user?.tenantId,
    initialData: [],
  });

  const activeDomains = domains.filter(d => d.isActive).length;
  const totalBlocks = domains.reduce((sum, d) => sum + (d.blockCount || 0), 0);
  const recentBlocks = logs.filter(l => l.action === 'domain_blocked').length;

  const topDomains = [...domains]
    .sort((a, b) => (b.blockCount || 0) - (a.blockCount || 0))
    .slice(0, 5);

  const categoryData = domains.reduce((acc, domain) => {
    const cat = domain.category || 'other';
    const catLabel = cat.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    const existing = acc.find(item => item.name === catLabel);
    if (existing) {
      existing.count += 1;
      existing.value += 1;
    } else {
      acc.push({ name: catLabel, count: 1, value: 1 });
    }
    return acc;
  }, []);

  const isLoading = domainsLoading || logsLoading;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring",
        stiffness: 100
      }
    }
  };

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#1284e1] rounded-full opacity-5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-purple-500 rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-gradient-to-br from-[#1284e1] to-[#0d5fb8] rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Dashboard</h1>
              <p className="text-gray-400">Bem-vindo de volta! Aqui está sua visão geral</p>
            </div>
          </div>
        </motion.div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
        >
          <motion.div variants={itemVariants}>
            <StatsCard
              title="Domínios Ativos"
              value={activeDomains}
              icon={Shield}
              color="blue"
              isLoading={isLoading}
              trend="+12%"
            />
          </motion.div>
          <motion.div variants={itemVariants}>
            <StatsCard
              title="Total de Bloqueios"
              value={totalBlocks}
              icon={Activity}
              color="red"
              isLoading={isLoading}
              trend="+24%"
            />
          </motion.div>
          <motion.div variants={itemVariants}>
            <StatsCard
              title="Bloqueios Hoje"
              value={recentBlocks}
              icon={Clock}
              color="green"
              isLoading={isLoading}
              trend="+8%"
            />
          </motion.div>
          <motion.div variants={itemVariants}>
            <StatsCard
              title="Categorias"
              value={categoryData.length}
              icon={Globe}
              color="purple"
              isLoading={isLoading}
              trend="5 tipos"
            />
          </motion.div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6 mb-8">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="lg:col-span-2"
          >
            <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] shadow-xl backdrop-blur-xl">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-[#1284e1]" />
                  Análise por Categoria
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  {categoryData.length > 0 ? (
                    <>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={categoryData}>
                          <defs>
                            <linearGradient id="colorBar" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#1284e1" stopOpacity={0.8}/>
                              <stop offset="95%" stopColor="#1284e1" stopOpacity={0.3}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#1a2847" />
                          <XAxis dataKey="name" stroke="#9ca3af" fontSize={12} />
                          <YAxis stroke="#9ca3af" />
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: '#01081c', 
                              border: '1px solid #1a2847',
                              borderRadius: '12px',
                              color: '#fff',
                              boxShadow: '0 10px 30px rgba(0,0,0,0.3)'
                            }}
                          />
                          <Bar dataKey="count" fill="url(#colorBar)" radius={[8, 8, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                      <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                          <Pie
                            data={categoryData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                            outerRadius={100}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {categoryData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip 
                            contentStyle={{ 
                              backgroundColor: '#01081c', 
                              border: '1px solid #1a2847',
                              borderRadius: '12px',
                              color: '#fff'
                            }}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    </>
                  ) : (
                    <div className="col-span-2 h-[300px] flex items-center justify-center text-gray-400">
                      <div className="text-center">
                        <Globe className="w-16 h-16 mx-auto mb-4 opacity-20" />
                        <p>Nenhum dado disponível</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
          >
            <TopDomains domains={topDomains} isLoading={isLoading} />
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <RecentActivity logs={logs} isLoading={isLoading} />
        </motion.div>
      </div>
    </div>
  );
}