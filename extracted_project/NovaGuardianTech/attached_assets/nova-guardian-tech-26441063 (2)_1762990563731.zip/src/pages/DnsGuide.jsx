import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Wifi, 
  Smartphone, 
  Monitor, 
  Router, 
  Copy, 
  CheckCircle,
  Info,
  AlertCircle
} from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function DnsGuidePage() {
  const [copiedDns, setCopiedDns] = useState(false);

  const dnsServers = {
    primary: "10.0.0.1",
    secondary: "10.0.0.2"
  };

  const copyDns = (dns) => {
    navigator.clipboard.writeText(dns);
    setCopiedDns(true);
    toast.success("DNS copiado!");
    setTimeout(() => setCopiedDns(false), 2000);
  };

  return (
    <div className="p-4 md:p-8 min-h-screen relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-cyan-500 rounded-full opacity-5 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-[#1284e1] rounded-full opacity-5 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Wifi className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Guia de Configuração DNS</h1>
              <p className="text-gray-400">Configure seus dispositivos para usar o NovaGuardian</p>
            </div>
          </div>

          <Alert className="bg-blue-500/10 border-blue-500/30 mb-6">
            <Info className="h-4 w-4 text-blue-400" />
            <AlertDescription className="text-blue-400">
              Configure estes servidores DNS nos seus dispositivos para ativar a proteção do NovaGuardian
            </AlertDescription>
          </Alert>

          {/* DNS Servers Display */}
          <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] mb-8">
            <CardHeader>
              <CardTitle className="text-white">Seus Servidores DNS</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-6 bg-[#1a2847] rounded-lg border border-[#1284e1]/30">
                  <p className="text-gray-400 text-sm mb-2">DNS Primário</p>
                  <div className="flex items-center justify-between">
                    <code className="text-2xl font-bold text-white">{dnsServers.primary}</code>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => copyDns(dnsServers.primary)}
                      className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                    >
                      {copiedDns ? <CheckCircle className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                    </Button>
                  </div>
                </div>
                <div className="p-6 bg-[#1a2847] rounded-lg border border-[#1284e1]/30">
                  <p className="text-gray-400 text-sm mb-2">DNS Secundário</p>
                  <div className="flex items-center justify-between">
                    <code className="text-2xl font-bold text-white">{dnsServers.secondary}</code>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => copyDns(dnsServers.secondary)}
                      className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                    >
                      {copiedDns ? <CheckCircle className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Configuration Guides */}
        <Tabs defaultValue="router" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4 bg-[#1a2847]">
            <TabsTrigger value="router" className="data-[state=active]:bg-[#1284e1]">
              <Router className="w-4 h-4 mr-2" />
              Roteador
            </TabsTrigger>
            <TabsTrigger value="windows" className="data-[state=active]:bg-[#1284e1]">
              <Monitor className="w-4 h-4 mr-2" />
              Windows
            </TabsTrigger>
            <TabsTrigger value="android" className="data-[state=active]:bg-[#1284e1]">
              <Smartphone className="w-4 h-4 mr-2" />
              Android
            </TabsTrigger>
            <TabsTrigger value="ios" className="data-[state=active]:bg-[#1284e1]">
              <Smartphone className="w-4 h-4 mr-2" />
              iOS
            </TabsTrigger>
          </TabsList>

          {/* Router Guide */}
          <TabsContent value="router">
            <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Router className="w-5 h-5 text-cyan-400" />
                  Configurar Roteador (Recomendado)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <Alert className="bg-green-500/10 border-green-500/30">
                  <CheckCircle className="h-4 w-4 text-green-400" />
                  <AlertDescription className="text-green-400">
                    <strong>Recomendado:</strong> Configurando no roteador, todos os dispositivos da rede ficam protegidos automaticamente
                  </AlertDescription>
                </Alert>

                <div className="space-y-4">
                  <StepItem
                    number={1}
                    title="Acesse o painel do roteador"
                    description="Digite o IP do seu roteador no navegador (geralmente 192.168.0.1 ou 192.168.1.1)"
                  />
                  <StepItem
                    number={2}
                    title="Faça login"
                    description="Use as credenciais de administrador do roteador"
                  />
                  <StepItem
                    number={3}
                    title="Localize as configurações DNS"
                    description="Geralmente em 'Internet', 'WAN' ou 'Configurações Avançadas'"
                  />
                  <StepItem
                    number={4}
                    title="Altere os servidores DNS"
                    description={
                      <div className="space-y-2 mt-2">
                        <p>DNS Primário: <code className="bg-[#1a2847] px-2 py-1 rounded text-blue-400">{dnsServers.primary}</code></p>
                        <p>DNS Secundário: <code className="bg-[#1a2847] px-2 py-1 rounded text-blue-400">{dnsServers.secondary}</code></p>
                      </div>
                    }
                  />
                  <StepItem
                    number={5}
                    title="Salve e reinicie"
                    description="Salve as configurações e reinicie o roteador se necessário"
                  />
                </div>

                <Alert className="bg-yellow-500/10 border-yellow-500/30">
                  <AlertCircle className="h-4 w-4 text-yellow-400" />
                  <AlertDescription className="text-yellow-400 text-sm">
                    <strong>Dica:</strong> Cada marca de roteador tem uma interface diferente. Consulte o manual se tiver dúvidas.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Windows Guide */}
          <TabsContent value="windows">
            <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Monitor className="w-5 h-5 text-blue-400" />
                  Configurar Windows
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <StepItem
                  number={1}
                  title="Abra as Configurações"
                  description="Pressione Windows + I ou vá em Configurações → Rede e Internet"
                />
                <StepItem
                  number={2}
                  title="Acesse as propriedades da rede"
                  description="Clique em 'Wi-Fi' ou 'Ethernet' → Clique na rede conectada"
                />
                <StepItem
                  number={3}
                  title="Edite configurações de IP"
                  description="Role até 'Configurações de IP' e clique em 'Editar'"
                />
                <StepItem
                  number={4}
                  title="Configure DNS manualmente"
                  description={
                    <div className="space-y-2 mt-2">
                      <p>• Mude de 'Automático' para 'Manual'</p>
                      <p>• Ative IPv4</p>
                      <p>• DNS preferencial: <code className="bg-[#1a2847] px-2 py-1 rounded text-blue-400">{dnsServers.primary}</code></p>
                      <p>• DNS alternativo: <code className="bg-[#1a2847] px-2 py-1 rounded text-blue-400">{dnsServers.secondary}</code></p>
                    </div>
                  }
                />
                <StepItem
                  number={5}
                  title="Salve as alterações"
                  description="Clique em 'Salvar' e aguarde a reconexão"
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Android Guide */}
          <TabsContent value="android">
            <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-green-400" />
                  Configurar Android
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <StepItem
                  number={1}
                  title="Abra as Configurações"
                  description="Vá em Configurações → Rede e Internet"
                />
                <StepItem
                  number={2}
                  title="Acesse o Wi-Fi"
                  description="Toque em 'Wi-Fi' e mantenha pressionada a rede conectada"
                />
                <StepItem
                  number={3}
                  title="Modificar rede"
                  description="Selecione 'Modificar rede' ou 'Gerenciar configurações de rede'"
                />
                <StepItem
                  number={4}
                  title="Mostrar opções avançadas"
                  description="Ative 'Opções avançadas' e em 'Configurações de IP', selecione 'Estático'"
                />
                <StepItem
                  number={5}
                  title="Configure os DNS"
                  description={
                    <div className="space-y-2 mt-2">
                      <p>DNS 1: <code className="bg-[#1a2847] px-2 py-1 rounded text-green-400">{dnsServers.primary}</code></p>
                      <p>DNS 2: <code className="bg-[#1a2847] px-2 py-1 rounded text-green-400">{dnsServers.secondary}</code></p>
                    </div>
                  }
                />
                <StepItem
                  number={6}
                  title="Salve"
                  description="Toque em 'Salvar' e reconecte ao Wi-Fi"
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* iOS Guide */}
          <TabsContent value="ios">
            <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-purple-400" />
                  Configurar iOS / iPhone
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <StepItem
                  number={1}
                  title="Abra os Ajustes"
                  description="Vá em Ajustes → Wi-Fi"
                />
                <StepItem
                  number={2}
                  title="Selecione a rede"
                  description="Toque no ícone (i) ao lado da rede conectada"
                />
                <StepItem
                  number={3}
                  title="Configure DNS"
                  description="Role até 'Configurar DNS' e toque em 'Manual'"
                />
                <StepItem
                  number={4}
                  title="Remova servidores antigos"
                  description="Toque em '-' para remover os servidores DNS existentes"
                />
                <StepItem
                  number={5}
                  title="Adicione novos servidores"
                  description={
                    <div className="space-y-2 mt-2">
                      <p>• Toque em 'Adicionar Servidor'</p>
                      <p>• Adicione: <code className="bg-[#1a2847] px-2 py-1 rounded text-purple-400">{dnsServers.primary}</code></p>
                      <p>• Adicione: <code className="bg-[#1a2847] px-2 py-1 rounded text-purple-400">{dnsServers.secondary}</code></p>
                    </div>
                  }
                />
                <StepItem
                  number={6}
                  title="Salve"
                  description="Toque em 'Salvar' no canto superior direito"
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Test Connection */}
        <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] mt-8">
          <CardHeader>
            <CardTitle className="text-white">Teste sua Conexão</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-gray-400">
                Após configurar o DNS, você pode testar se está funcionando:
              </p>
              <ol className="space-y-2 text-gray-300">
                <li className="flex items-start gap-2">
                  <span className="text-blue-400 font-bold">1.</span>
                  <span>Tente acessar um domínio que você bloqueou no NovaGuardian</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-400 font-bold">2.</span>
                  <span>Se não carregar, está funcionando! 🎉</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-400 font-bold">3.</span>
                  <span>Volte ao dashboard e veja os bloqueios em tempo real</span>
                </li>
              </ol>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StepItem({ number, title, description }) {
  return (
    <div className="flex gap-4">
      <div className="w-8 h-8 rounded-full bg-[#1284e1] flex items-center justify-center text-white font-bold flex-shrink-0">
        {number}
      </div>
      <div className="flex-1">
        <h4 className="text-white font-semibold mb-1">{title}</h4>
        <div className="text-gray-400 text-sm">{description}</div>
      </div>
    </div>
  );
}