import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, Rocket, Shield, Zap } from "lucide-react";
import { motion } from "framer-motion";

export default function CompleteStep({ user, onComplete }) {
  return (
    <div className="max-w-3xl mx-auto">
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 200, damping: 20 }}
        className="text-center mb-12"
      >
        <motion.div
          animate={{ 
            scale: [1, 1.2, 1],
            rotate: [0, 360]
          }}
          transition={{ 
            duration: 1,
            times: [0, 0.5, 1]
          }}
          className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center shadow-2xl shadow-green-500/50"
        >
          <CheckCircle className="w-12 h-12 text-white" />
        </motion.div>
        
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
          🎉 Tudo Pronto!
        </h1>
        <p className="text-xl text-gray-400 mb-2">
          Parabéns, <span className="text-white font-semibold">{user?.full_name}</span>!
        </p>
        <p className="text-lg text-gray-500 max-w-2xl mx-auto">
          Sua configuração foi concluída com sucesso. Você já está protegido e pronto para começar.
        </p>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-4 mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="bg-gradient-to-br from-green-500/10 to-green-600/5 border-green-500/30 text-center h-full">
            <CardContent className="p-6">
              <div className="w-14 h-14 mx-auto mb-4 bg-green-500/20 rounded-xl flex items-center justify-center">
                <Shield className="w-7 h-7 text-green-400" />
              </div>
              <h3 className="text-white font-semibold mb-2">Proteção Ativa</h3>
              <p className="text-gray-400 text-sm">
                Seus domínios já estão sendo monitorados
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/5 border-blue-500/30 text-center h-full">
            <CardContent className="p-6">
              <div className="w-14 h-14 mx-auto mb-4 bg-blue-500/20 rounded-xl flex items-center justify-center">
                <Zap className="w-7 h-7 text-blue-400" />
              </div>
              <h3 className="text-white font-semibold mb-2">Sistema Pronto</h3>
              <p className="text-gray-400 text-sm">
                Dashboard e ferramentas disponíveis
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/5 border-purple-500/30 text-center h-full">
            <CardContent className="p-6">
              <div className="w-14 h-14 mx-auto mb-4 bg-purple-500/20 rounded-xl flex items-center justify-center">
                <Rocket className="w-7 h-7 text-purple-400" />
              </div>
              <h3 className="text-white font-semibold mb-2">Pronto para Usar</h3>
              <p className="text-gray-400 text-sm">
                Explore todas as funcionalidades
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <Card className="bg-gradient-to-br from-[#1284e1]/10 to-[#0d5fb8]/5 border-[#1284e1]/30 mb-6">
        <CardContent className="p-8">
          <h3 className="text-white font-bold text-xl mb-4 text-center">Próximos Passos</h3>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-[#1a2847]/50 rounded-lg">
              <div className="w-6 h-6 rounded-full bg-[#1284e1] flex items-center justify-center flex-shrink-0 text-white text-xs font-bold">
                1
              </div>
              <div>
                <p className="text-white font-medium">Explore o Dashboard</p>
                <p className="text-gray-400 text-sm">Veja suas estatísticas e domínios bloqueados em tempo real</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-[#1a2847]/50 rounded-lg">
              <div className="w-6 h-6 rounded-full bg-[#1284e1] flex items-center justify-center flex-shrink-0 text-white text-xs font-bold">
                2
              </div>
              <div>
                <p className="text-white font-medium">Adicione Mais Domínios</p>
                <p className="text-gray-400 text-sm">Personalize sua proteção adicionando domínios específicos</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-[#1a2847]/50 rounded-lg">
              <div className="w-6 h-6 rounded-full bg-[#1284e1] flex items-center justify-center flex-shrink-0 text-white text-xs font-bold">
                3
              </div>
              <div>
                <p className="text-white font-medium">Convide sua Equipe</p>
                <p className="text-gray-400 text-sm">Compartilhe o acesso com outros membros da organização</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <motion.div 
        className="text-center"
        whileHover={{ scale: 1.05 }} 
        whileTap={{ scale: 0.95 }}
      >
        <Button
          onClick={onComplete}
          size="lg"
          className="bg-gradient-to-r from-[#1284e1] to-[#0d5fb8] hover:from-[#0d5fb8] hover:to-[#1284e1] text-white shadow-2xl shadow-blue-500/40 px-12"
        >
          <Rocket className="w-5 h-5 mr-2" />
          Ir para o Dashboard
        </Button>
      </motion.div>

      <p className="text-center text-gray-500 text-sm mt-6">
        Precisa de ajuda? Acesse a documentação ou entre em contato com o suporte
      </p>
    </div>
  );
}