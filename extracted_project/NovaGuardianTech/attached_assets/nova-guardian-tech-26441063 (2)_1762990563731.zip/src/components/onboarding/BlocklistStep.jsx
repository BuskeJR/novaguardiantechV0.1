import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { base44 } from "@/api/base44Client";
import { Shield, ArrowRight, ArrowLeft, Check, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";

const defaultBlocklists = [
  {
    id: "social_media",
    name: "Redes Sociais",
    description: "Facebook, Instagram, Twitter, TikTok e outras redes sociais",
    icon: "👥",
    color: "from-blue-500 to-blue-600",
    domains: ["facebook.com", "instagram.com", "twitter.com", "x.com", "tiktok.com", "linkedin.com", "snapchat.com"],
    recommended: true
  },
  {
    id: "streaming",
    name: "Streaming",
    description: "YouTube, Netflix, Twitch e plataformas de vídeo",
    icon: "🎬",
    color: "from-purple-500 to-purple-600",
    domains: ["youtube.com", "netflix.com", "twitch.tv", "hulu.com", "disneyplus.com", "primevideo.com"],
    recommended: false
  },
  {
    id: "ads_tracking",
    name: "Anúncios e Rastreamento",
    description: "Bloqueie rastreadores e redes de anúncios",
    icon: "🚫",
    color: "from-yellow-500 to-orange-500",
    domains: ["doubleclick.net", "google-analytics.com", "facebook.com/tr", "googlesyndication.com", "adservice.google.com"],
    recommended: true
  },
  {
    id: "gambling",
    name: "Apostas e Jogos de Azar",
    description: "Sites de apostas e cassinos online",
    icon: "🎰",
    color: "from-red-500 to-red-600",
    domains: ["bet365.com", "betano.com", "betfair.com", "1xbet.com", "pokerstars.com"],
    recommended: true
  },
  {
    id: "malware",
    name: "Malware e Phishing",
    description: "Proteção contra sites maliciosos conhecidos",
    icon: "🛡️",
    color: "from-red-700 to-red-800",
    domains: ["malware-example.com", "phishing-test.com"],
    recommended: true
  },
  {
    id: "adult",
    name: "Conteúdo Adulto",
    description: "Bloqueie sites de conteúdo adulto",
    icon: "🔞",
    color: "from-pink-500 to-pink-600",
    domains: [],
    recommended: false
  }
];

export default function BlocklistStep({ user, onNext, onBack }) {
  const [selectedLists, setSelectedLists] = useState(
    defaultBlocklists.filter(list => list.recommended).map(list => list.id)
  );
  const [loading, setLoading] = useState(false);

  const handleToggleList = (listId) => {
    if (selectedLists.includes(listId)) {
      setSelectedLists(selectedLists.filter(id => id !== listId));
    } else {
      setSelectedLists([...selectedLists, listId]);
    }
  };

  const handleSubmit = async () => {
    setLoading(true);
    
    try {
      const tenantId = user.tenantId || `tenant_${Date.now()}`;
      
      // Import selected blocklists
      for (const listId of selectedLists) {
        const list = defaultBlocklists.find(l => l.id === listId);
        if (!list || list.domains.length === 0) continue;
        
        for (const domain of list.domains) {
          const variations = [
            domain,
            `www.${domain}`,
            `cdn.${domain}`,
            `api.${domain}`,
            `m.${domain}`,
          ];
          
          try {
            await base44.entities.Domain.create({
              domain,
              category: listId,
              description: `Importado da lista: ${list.name}`,
              isActive: true,
              blockCount: 0,
              tenantId,
              addedBy: user.email,
              variations,
            });
          } catch (error) {
            console.error(`Error adding domain ${domain}:`, error);
          }
        }
      }
      
      // Log the action
      await base44.entities.BlockLog.create({
        action: "settings_changed",
        userId: user.id,
        userEmail: user.email,
        tenantId,
        details: { 
          action: "onboarding_blocklists_imported",
          lists: selectedLists
        },
      });
      
      toast.success(`✓ ${selectedLists.length} listas importadas com sucesso!`);
      onNext();
    } catch (error) {
      console.error("Error importing blocklists:", error);
      toast.error("✗ Erro ao importar listas");
    } finally {
      setLoading(false);
    }
  };

  const totalDomains = defaultBlocklists
    .filter(list => selectedLists.includes(list.id))
    .reduce((sum, list) => sum + list.domains.length, 0);

  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-green-500/20 to-green-600/10 rounded-2xl flex items-center justify-center">
          <Shield className="w-8 h-8 text-green-400" />
        </div>
        <h2 className="text-3xl font-bold text-white mb-2">Configure a Proteção Inicial</h2>
        <p className="text-gray-400">
          Escolha as categorias de sites que deseja bloquear automaticamente
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-4 mb-8">
        {defaultBlocklists.map((list, index) => {
          const isSelected = selectedLists.includes(list.id);
          
          return (
            <motion.div
              key={list.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
            >
              <Card 
                className={`cursor-pointer transition-all duration-300 ${
                  isSelected 
                    ? 'bg-gradient-to-br from-[#1284e1]/20 to-[#0d5fb8]/10 border-[#1284e1] shadow-lg shadow-blue-500/20' 
                    : 'bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] hover:border-[#1a2847]/50'
                }`}
                onClick={() => handleToggleList(list.id)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${list.color} flex items-center justify-center text-2xl shadow-lg`}>
                        {list.icon}
                      </div>
                      <div>
                        <CardTitle className="text-white text-lg flex items-center gap-2">
                          {list.name}
                          {list.recommended && (
                            <Badge variant="outline" className="bg-green-500/10 text-green-400 border-green-500/30 text-xs">
                              Recomendado
                            </Badge>
                          )}
                        </CardTitle>
                        <CardDescription className="text-gray-400 text-sm mt-1">
                          {list.domains.length} domínios
                        </CardDescription>
                      </div>
                    </div>
                    <Checkbox
                      checked={isSelected}
                      className={isSelected ? "border-[#1284e1]" : ""}
                    />
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400 text-sm">{list.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      <Card className="bg-gradient-to-br from-blue-500/10 to-purple-500/5 border-blue-500/30 mb-6">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="w-5 h-5 text-blue-400" />
            </div>
            <div className="flex-1">
              <h4 className="text-white font-semibold mb-1">
                {selectedLists.length} listas selecionadas • {totalDomains} domínios
              </h4>
              <p className="text-gray-400 text-sm">
                Você poderá adicionar ou remover domínios individuais a qualquer momento. 
                As listas podem ser desativadas sem perder suas configurações personalizadas.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3">
        <Button
          onClick={onBack}
          variant="outline"
          className="flex-1 bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar
        </Button>
        <motion.div className="flex-1" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
          <Button
            onClick={handleSubmit}
            disabled={loading}
            className="w-full bg-gradient-to-r from-[#1284e1] to-[#0d5fb8] hover:from-[#0d5fb8] hover:to-[#1284e1] text-white shadow-lg shadow-blue-500/30"
          >
            {loading ? "Importando..." : `Continuar ${selectedLists.length > 0 ? `(${totalDomains} domínios)` : ''}`}
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </motion.div>
      </div>
    </div>
  );
}