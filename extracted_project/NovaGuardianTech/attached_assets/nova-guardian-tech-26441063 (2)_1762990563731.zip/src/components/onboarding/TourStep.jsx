import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, Shield, ScrollText, Settings, ArrowRight, ArrowLeft } from "lucide-react";
import { motion } from "framer-motion";

const features = [
  {
    icon: LayoutDashboard,
    title: "Dashboard",
    description: "Visualize estatísticas em tempo real, domínios mais bloqueados e atividades recentes",
    color: "from-blue-500 to-blue-600",
    tips: ["Gráficos interativos", "Top 5 domínios bloqueados", "Métricas por categoria"]
  },
  {
    icon: Shield,
    title: "Gerenciar Domínios",
    description: "Adicione, edite ou remova domínios bloqueados. Ative/desative bloqueios com um clique",
    color: "from-green-500 to-green-600",
    tips: ["Busca rápida", "Filtros por categoria", "Exportação TXT/JSON"]
  },
  {
    icon: ScrollText,
    title: "Logs de Atividade",
    description: "Monitore todas as ações realizadas no sistema com histórico completo",
    color: "from-purple-500 to-purple-600",
    tips: ["Filtros avançados", "Exportação CSV", "Auditoria completa"]
  },
  {
    icon: Settings,
    title: "Configurações",
    description: "Personalize seu perfil e ajuste as preferências do sistema",
    color: "from-orange-500 to-orange-600",
    tips: ["Dados pessoais", "Preferências", "Segurança"]
  }
];

export default function TourStep({ onNext, onBack }) {
  return (
    <div className="max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-indigo-500/20 to-indigo-600/10 rounded-2xl flex items-center justify-center">
          <LayoutDashboard className="w-8 h-8 text-indigo-400" />
        </div>
        <h2 className="text-3xl font-bold text-white mb-2">Tour Rápido</h2>
        <p className="text-gray-400">
          Conheça as principais funcionalidades do NovaGuardian
        </p>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {features.map((feature, index) => (
          <motion.div
            key={feature.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.03, y: -5 }}
          >
            <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] hover:border-[#1284e1]/50 transition-all duration-300 h-full">
              <CardContent className="p-6">
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4 shadow-lg`}>
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-white font-bold text-lg mb-2">{feature.title}</h3>
                <p className="text-gray-400 text-sm mb-4">{feature.description}</p>
                <div className="space-y-2">
                  {feature.tips.map((tip, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#1284e1]" />
                      <span className="text-gray-500 text-xs">{tip}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <Card className="bg-gradient-to-br from-indigo-500/10 to-purple-500/5 border-indigo-500/30 mb-6">
        <CardContent className="p-6">
          <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
            <span className="text-2xl">💡</span>
            Dicas Úteis
          </h4>
          <ul className="space-y-2 text-gray-400 text-sm">
            <li className="flex items-start gap-2">
              <span className="text-green-400 mt-1">✓</span>
              <span>Use a busca para encontrar domínios rapidamente</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-400 mt-1">✓</span>
              <span>Exporte seus dados a qualquer momento em TXT, JSON ou CSV</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-400 mt-1">✓</span>
              <span>Monitore logs para auditoria e conformidade</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-400 mt-1">✓</span>
              <span>Administradores podem gerenciar usuários e permissões</span>
            </li>
          </ul>
        </CardContent>
      </Card>

      <div className="flex gap-3">
        <Button
          onClick={onBack}
          variant="outline"
          className="flex-1 bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar
        </Button>
        <motion.div className="flex-1" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
          <Button
            onClick={onNext}
            className="w-full bg-gradient-to-r from-[#1284e1] to-[#0d5fb8] hover:from-[#0d5fb8] hover:to-[#1284e1] text-white shadow-lg shadow-blue-500/30"
          >
            Entendi, Continuar
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </motion.div>
      </div>
    </div>
  );
}