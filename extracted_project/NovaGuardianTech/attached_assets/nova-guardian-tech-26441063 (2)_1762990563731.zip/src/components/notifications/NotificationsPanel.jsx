import React, { useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X, Check, Info, AlertCircle, CheckCircle, AlertTriangle } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion, AnimatePresence } from "framer-motion";
import { ScrollArea } from "@/components/ui/scroll-area";

const typeConfig = {
  info: {
    color: "bg-blue-500/10 text-blue-400 border-blue-500/30",
    icon: Info
  },
  success: {
    color: "bg-green-500/10 text-green-400 border-green-500/30",
    icon: CheckCircle
  },
  warning: {
    color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/30",
    icon: AlertTriangle
  },
  error: {
    color: "bg-red-500/10 text-red-400 border-red-500/30",
    icon: AlertCircle
  }
};

export default function NotificationsPanel({ user, onClose, onUpdateCount }) {
  const queryClient = useQueryClient();

  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      return await base44.entities.Notification.filter({ userId: user.id }, '-created_date', 50);
    },
    enabled: !!user?.id,
    initialData: [],
  });

  useEffect(() => {
    const unreadCount = notifications.filter(n => !n.isRead).length;
    onUpdateCount(unreadCount);
  }, [notifications]);

  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId) => {
      await base44.entities.Notification.update(notificationId, { isRead: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const unread = notifications.filter(n => !n.isRead);
      for (const notification of unread) {
        await base44.entities.Notification.update(notification.id, { isRead: true });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const unreadNotifications = notifications.filter(n => !n.isRead);
  const readNotifications = notifications.filter(n => n.isRead);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-start justify-end p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ x: 400, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: 400, opacity: 0 }}
        transition={{ type: "spring", damping: 25 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md"
      >
        <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] shadow-2xl">
          <CardHeader className="border-b border-[#1a2847]">
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center gap-2">
                Notificações
                {unreadNotifications.length > 0 && (
                  <Badge className="bg-red-500 text-white">
                    {unreadNotifications.length}
                  </Badge>
                )}
              </CardTitle>
              <div className="flex items-center gap-2">
                {unreadNotifications.length > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => markAllAsReadMutation.mutate()}
                    className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                  >
                    <Check className="w-4 h-4 mr-1" />
                    Marcar todas
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="text-gray-400 hover:text-white hover:bg-[#1a2847]"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[calc(100vh-200px)]">
              <div className="p-4 space-y-3">
                <AnimatePresence>
                  {notifications.length === 0 ? (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-center py-12"
                    >
                      <div className="w-16 h-16 mx-auto mb-4 bg-[#1a2847] rounded-full flex items-center justify-center">
                        <Info className="w-8 h-8 text-gray-400" />
                      </div>
                      <p className="text-gray-400">Nenhuma notificação</p>
                    </motion.div>
                  ) : (
                    <>
                      {unreadNotifications.length > 0 && (
                        <div>
                          <p className="text-xs text-gray-400 uppercase tracking-wider mb-2 px-2">Não lidas</p>
                          {unreadNotifications.map((notification, index) => (
                            <NotificationItem
                              key={notification.id}
                              notification={notification}
                              index={index}
                              onMarkAsRead={() => markAsReadMutation.mutate(notification.id)}
                            />
                          ))}
                        </div>
                      )}
                      
                      {readNotifications.length > 0 && (
                        <div className="mt-6">
                          <p className="text-xs text-gray-400 uppercase tracking-wider mb-2 px-2">Anteriores</p>
                          {readNotifications.map((notification, index) => (
                            <NotificationItem
                              key={notification.id}
                              notification={notification}
                              index={index}
                              isRead
                            />
                          ))}
                        </div>
                      )}
                    </>
                  )}
                </AnimatePresence>
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}

function NotificationItem({ notification, index, onMarkAsRead, isRead }) {
  const config = typeConfig[notification.type] || typeConfig.info;
  const Icon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className={`p-4 rounded-lg border transition-all cursor-pointer ${
        isRead 
          ? 'bg-[#1a2847]/30 border-[#1a2847] opacity-60' 
          : 'bg-[#1a2847]/50 border-[#1a2847] hover:border-[#1284e1]/50'
      }`}
      onClick={onMarkAsRead}
    >
      <div className="flex items-start gap-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center border ${config.color}`}>
          <Icon className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-1">
            <h4 className="text-white font-semibold text-sm">{notification.title}</h4>
            {!isRead && (
              <div className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0 mt-1" />
            )}
          </div>
          <p className="text-gray-400 text-sm mb-2">{notification.message}</p>
          <p className="text-xs text-gray-500">
            {format(new Date(notification.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
          </p>
        </div>
      </div>
    </motion.div>
  );
}