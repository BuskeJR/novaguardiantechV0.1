import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search } from "lucide-react";

export default function LogFilters({ filters, onFilterChange }) {
  return (
    <div className="grid md:grid-cols-4 gap-4">
      <div className="space-y-2">
        <Label className="text-gray-300">Buscar</Label>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Buscar nos logs..."
            value={filters.search || ""}
            onChange={(e) => onFilterChange({ ...filters, search: e.target.value })}
            className="pl-10 bg-[#1a2847] border-[#1a2847] text-white"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label className="text-gray-300">Tipo de Ação</Label>
        <Select
          value={filters.action || "all"}
          onValueChange={(value) => onFilterChange({ ...filters, action: value })}
        >
          <SelectTrigger className="bg-[#1a2847] border-[#1a2847] text-white">
            <SelectValue placeholder="Todas as ações" />
          </SelectTrigger>
          <SelectContent className="bg-[#01081c] border-[#1a2847] text-white">
            <SelectItem value="all">Todas as ações</SelectItem>
            <SelectItem value="domain_blocked">Domínio Bloqueado</SelectItem>
            <SelectItem value="domain_allowed">Domínio Permitido</SelectItem>
            <SelectItem value="domain_added">Domínio Adicionado</SelectItem>
            <SelectItem value="domain_removed">Domínio Removido</SelectItem>
            <SelectItem value="user_invited">Usuário Convidado</SelectItem>
            <SelectItem value="settings_changed">Configurações Alteradas</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label className="text-gray-300">Período</Label>
        <Select
          value={filters.dateRange || "all"}
          onValueChange={(value) => onFilterChange({ ...filters, dateRange: value })}
        >
          <SelectTrigger className="bg-[#1a2847] border-[#1a2847] text-white">
            <SelectValue placeholder="Todos os períodos" />
          </SelectTrigger>
          <SelectContent className="bg-[#01081c] border-[#1a2847] text-white">
            <SelectItem value="all">Todos</SelectItem>
            <SelectItem value="today">Hoje</SelectItem>
            <SelectItem value="week">Última Semana</SelectItem>
            <SelectItem value="month">Último Mês</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label className="text-gray-300">Usuário</Label>
        <Input
          placeholder="Email do usuário..."
          value={filters.userEmail || ""}
          onChange={(e) => onFilterChange({ ...filters, userEmail: e.target.value })}
          className="bg-[#1a2847] border-[#1a2847] text-white"
        />
      </div>
    </div>
  );
}