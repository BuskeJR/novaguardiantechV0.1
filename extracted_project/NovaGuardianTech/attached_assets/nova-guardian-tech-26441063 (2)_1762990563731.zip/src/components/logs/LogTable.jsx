import React from "react";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Shield, CheckCircle, Settings, UserPlus, Trash2, AlertCircle } from "lucide-react";

const actionIcons = {
  domain_blocked: Shield,
  domain_allowed: CheckCircle,
  domain_added: Settings,
  domain_removed: Trash2,
  user_invited: UserPlus,
  settings_changed: Settings,
};

const actionColors = {
  domain_blocked: "bg-red-500/20 text-red-400 border-red-500/30",
  domain_allowed: "bg-green-500/20 text-green-400 border-green-500/30",
  domain_added: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  domain_removed: "bg-orange-500/20 text-orange-400 border-orange-500/30",
  user_invited: "bg-purple-500/20 text-purple-400 border-purple-500/30",
  settings_changed: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
};

export default function LogTable({ logs, isLoading }) {
  if (isLoading) {
    return (
      <div className="space-y-3">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="bg-[#1a2847] rounded-lg p-4 animate-pulse">
            <div className="h-4 bg-[#0a1128] rounded w-1/3 mb-2" />
            <div className="h-3 bg-[#0a1128] rounded w-1/2" />
          </div>
        ))}
      </div>
    );
  }

  if (logs.length === 0) {
    return (
      <div className="bg-[#1a2847] rounded-lg p-12 text-center">
        <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-400">Nenhum log encontrado</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {logs.map((log) => {
        const Icon = actionIcons[log.action] || Shield;
        const colorClass = actionColors[log.action] || "bg-gray-500/20 text-gray-400 border-gray-500/30";

        return (
          <div
            key={log.id}
            className="bg-[#1a2847] rounded-lg p-4 hover:bg-[#1a2847]/70 transition-colors"
          >
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 mt-1">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${colorClass}`}>
                  <Icon className="w-5 h-5" />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-4 mb-2">
                  <div className="flex-1">
                    <h4 className="text-white font-medium mb-1">
                      {log.action.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </h4>
                    <p className="text-gray-400 text-sm">
                      {log.domain && <span className="font-mono">{log.domain}</span>}
                      {log.userEmail && (
                        <span className="ml-2">
                          por <span className="text-blue-400">{log.userEmail}</span>
                        </span>
                      )}
                    </p>
                  </div>
                  <span className="text-gray-500 text-xs whitespace-nowrap">
                    {format(new Date(log.created_date), "dd/MM/yyyy HH:mm", { locale: ptBR })}
                  </span>
                </div>
                {log.details && (
                  <div className="text-xs text-gray-500 font-mono bg-[#0a1128] rounded p-2">
                    {JSON.stringify(log.details)}
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}