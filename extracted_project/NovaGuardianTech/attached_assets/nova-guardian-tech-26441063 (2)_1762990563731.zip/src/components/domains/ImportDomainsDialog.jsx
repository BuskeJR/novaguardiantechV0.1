import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Upload, FileText, CheckCircle, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function ImportDomainsDialog({ open, onClose, onImport, isLoading }) {
  const [importMethod, setImportMethod] = useState("text");
  const [textInput, setTextInput] = useState("");
  const [category, setCategory] = useState("other");
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState([]);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target.result;
        const domains = parseDomains(content);
        setPreview(domains.slice(0, 10));
      };
      reader.readAsText(selectedFile);
    }
  };

  const parseDomains = (text) => {
    return text
      .split(/[\n,;]/)
      .map(d => d.trim())
      .filter(d => d && d.includes('.'))
      .map(d => d.replace(/^(https?:\/\/)?(www\.)?/, ''));
  };

  const handleTextInput = (text) => {
    setTextInput(text);
    const domains = parseDomains(text);
    setPreview(domains.slice(0, 10));
  };

  const handleSubmit = () => {
    let domains = [];
    
    if (importMethod === "text") {
      domains = parseDomains(textInput);
    } else if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        domains = parseDomains(event.target.result);
        onImport(domains, category);
      };
      reader.readAsText(file);
      return;
    }

    if (domains.length > 0) {
      onImport(domains, category);
    }
  };

  const isValid = importMethod === "text" ? textInput.trim().length > 0 : file !== null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#01081c] border-[#1a2847] text-white max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-blue-400" />
            Importar Domínios em Massa
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Adicione múltiplos domínios de uma vez usando texto ou arquivo
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Método de Importação</Label>
            <Select value={importMethod} onValueChange={setImportMethod}>
              <SelectTrigger className="bg-[#1a2847] border-[#1a2847] text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#01081c] border-[#1a2847] text-white">
                <SelectItem value="text">Colar Texto</SelectItem>
                <SelectItem value="file">Upload de Arquivo</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {importMethod === "text" ? (
            <div className="space-y-2">
              <Label>Domínios (um por linha)</Label>
              <Textarea
                value={textInput}
                onChange={(e) => handleTextInput(e.target.value)}
                placeholder="facebook.com&#10;twitter.com&#10;instagram.com"
                className="bg-[#1a2847] border-[#1a2847] text-white min-h-[200px] font-mono text-sm"
              />
              <p className="text-xs text-gray-500">
                Separe por linha, vírgula ou ponto e vírgula
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              <Label>Arquivo (.txt, .csv)</Label>
              <div className="flex items-center gap-3">
                <label className="flex-1 flex items-center gap-3 p-4 bg-[#1a2847] border-2 border-dashed border-[#1284e1]/30 rounded-lg hover:border-[#1284e1]/60 cursor-pointer transition-colors">
                  <FileText className="w-8 h-8 text-blue-400" />
                  <div className="flex-1">
                    <p className="text-white font-medium">
                      {file ? file.name : "Clique para selecionar arquivo"}
                    </p>
                    <p className="text-xs text-gray-400">
                      {file ? `${(file.size / 1024).toFixed(2)} KB` : "TXT ou CSV"}
                    </p>
                  </div>
                  <input
                    type="file"
                    accept=".txt,.csv"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label>Categoria Padrão</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="bg-[#1a2847] border-[#1a2847] text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#01081c] border-[#1a2847] text-white">
                <SelectItem value="social_media">Redes Sociais</SelectItem>
                <SelectItem value="streaming">Streaming</SelectItem>
                <SelectItem value="gaming">Gaming</SelectItem>
                <SelectItem value="adult">Adulto</SelectItem>
                <SelectItem value="gambling">Apostas</SelectItem>
                <SelectItem value="malware">Malware</SelectItem>
                <SelectItem value="phishing">Phishing</SelectItem>
                <SelectItem value="ads">Anúncios</SelectItem>
                <SelectItem value="tracking">Rastreamento</SelectItem>
                <SelectItem value="other">Outros</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {preview.length > 0 && (
            <Alert className="bg-blue-500/10 border-blue-500/30">
              <CheckCircle className="h-4 w-4 text-blue-400" />
              <AlertDescription className="text-blue-400">
                <strong>Pré-visualização:</strong> {preview.length} domínios detectados
                <div className="mt-2 space-y-1">
                  {preview.map((domain, i) => (
                    <div key={i} className="text-xs font-mono bg-[#1a2847] px-2 py-1 rounded">
                      {domain}
                    </div>
                  ))}
                  {preview.length < parseDomains(textInput || "").length && (
                    <p className="text-xs pt-1">
                      + {parseDomains(textInput || "").length - preview.length} mais...
                    </p>
                  )}
                </div>
              </AlertDescription>
            </Alert>
          )}

          {preview.length === 0 && textInput && (
            <Alert className="bg-yellow-500/10 border-yellow-500/30">
              <AlertCircle className="h-4 w-4 text-yellow-400" />
              <AlertDescription className="text-yellow-400">
                Nenhum domínio válido detectado. Verifique o formato.
              </AlertDescription>
            </Alert>
          )}
        </div>

        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
          >
            Cancelar
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!isValid || isLoading || preview.length === 0}
            className="bg-[#1284e1] hover:bg-[#0d5fb8]"
          >
            <Upload className="w-4 h-4 mr-2" />
            {isLoading ? "Importando..." : `Importar ${preview.length} Domínios`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}