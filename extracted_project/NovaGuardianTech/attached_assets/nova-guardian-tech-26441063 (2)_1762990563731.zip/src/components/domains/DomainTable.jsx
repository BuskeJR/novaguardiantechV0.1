import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Trash2, Star } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";

const categoryColors = {
  social_media: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  streaming: "bg-purple-500/10 text-purple-500 border-purple-500/20",
  gaming: "bg-green-500/10 text-green-500 border-green-500/20",
  adult: "bg-red-500/10 text-red-500 border-red-500/20",
  gambling: "bg-orange-500/10 text-orange-500 border-orange-500/20",
  malware: "bg-red-700/10 text-red-700 border-red-700/20",
  phishing: "bg-red-600/10 text-red-600 border-red-600/20",
  ads: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
  tracking: "bg-indigo-500/10 text-indigo-500 border-indigo-500/20",
  other: "bg-gray-500/10 text-gray-500 border-gray-500/20",
};

export default function DomainTable({ domains, selectedDomains = [], onSelect, onSelectAll, onToggle, onDelete }) {
  const allSelected = selectedDomains?.length === domains.length && domains.length > 0;

  return (
    <Card className="bg-[#01081c] border-[#1a2847]">
      <Table>
        <TableHeader>
          <TableRow className="border-[#1a2847] hover:bg-transparent">
            <TableHead className="w-12">
              <Checkbox
                checked={allSelected}
                onCheckedChange={onSelectAll}
                className="border-gray-500"
              />
            </TableHead>
            <TableHead className="text-gray-400">Domínio</TableHead>
            <TableHead className="text-gray-400">Categoria</TableHead>
            <TableHead className="text-gray-400">Tags</TableHead>
            <TableHead className="text-gray-400">Bloqueios</TableHead>
            <TableHead className="text-gray-400">Status</TableHead>
            <TableHead className="text-gray-400">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {domains.map((domain) => (
            <TableRow key={domain.id} className="border-[#1a2847] hover:bg-[#1a2847]">
              <TableCell>
                <Checkbox
                  checked={selectedDomains?.includes(domain.id)}
                  onCheckedChange={() => onSelect(domain.id)}
                  className="border-gray-500"
                />
              </TableCell>
              <TableCell className="text-white font-medium flex items-center gap-2">
                {domain.isFavorite && <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />}
                {domain.domain}
              </TableCell>
              <TableCell>
                <Badge variant="outline" className={categoryColors[domain.category] || categoryColors.other}>
                  {domain.category?.replace(/_/g, ' ')}
                </Badge>
              </TableCell>
              <TableCell>
                <div className="flex flex-wrap gap-1">
                  {(domain.tags || []).map((tag, idx) => (
                    <Badge key={idx} className="bg-purple-500/20 text-purple-400 border-purple-500/30 text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </TableCell>
              <TableCell className="text-gray-400">{domain.blockCount || 0}</TableCell>
              <TableCell>
                <Switch
                  checked={domain.isActive}
                  onCheckedChange={(checked) => onToggle(domain, checked)}
                  className="data-[state=checked]:bg-green-500"
                />
              </TableCell>
              <TableCell>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onDelete(domain)}
                  className="text-red-500 hover:text-red-400 hover:bg-red-500/10"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Card>
  );
}