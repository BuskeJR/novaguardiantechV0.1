import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, Trash2, Tag, FolderInput, X } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

export default function BulkActionsBar({ selectedCount, onActivateAll, onDeactivateAll, onDeleteAll, onChangeCategory, onAddTags, onMoveToGroup, onClearSelection }) {
  if (selectedCount === 0) return null;

  return (
    <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50">
      <div className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border border-[#1284e1] rounded-2xl shadow-2xl shadow-blue-500/30 px-6 py-4 flex items-center gap-4 backdrop-blur-xl">
        <Badge className="bg-[#1284e1] text-white px-3 py-1 text-sm">
          {selectedCount} selecionado{selectedCount > 1 ? 's' : ''}
        </Badge>
        
        <div className="h-6 w-px bg-[#1a2847]" />
        
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            onClick={onActivateAll}
            className="bg-green-500/20 text-green-400 hover:bg-green-500/30 border border-green-500/30"
          >
            <CheckCircle className="w-4 h-4 mr-2" />
            Ativar Todos
          </Button>

          <Button
            size="sm"
            onClick={onDeactivateAll}
            className="bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30 border border-yellow-500/30"
          >
            <XCircle className="w-4 h-4 mr-2" />
            Desativar Todos
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                size="sm"
                className="bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 border border-blue-500/30"
              >
                <FolderInput className="w-4 h-4 mr-2" />
                Mover Categoria
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-[#01081c] border-[#1a2847] text-white">
              <DropdownMenuItem onClick={() => onChangeCategory("social_media")}>
                Redes Sociais
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onChangeCategory("streaming")}>
                Streaming
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onChangeCategory("gaming")}>
                Gaming
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onChangeCategory("adult")}>
                Adulto
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onChangeCategory("gambling")}>
                Apostas
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onChangeCategory("malware")}>
                Malware
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onChangeCategory("phishing")}>
                Phishing
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onChangeCategory("ads")}>
                Anúncios
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onChangeCategory("tracking")}>
                Rastreamento
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onChangeCategory("other")}>
                Outros
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button
            size="sm"
            onClick={onAddTags}
            className="bg-purple-500/20 text-purple-400 hover:bg-purple-500/30 border border-purple-500/30"
          >
            <Tag className="w-4 h-4 mr-2" />
            Adicionar Tags
          </Button>

          <Button
            size="sm"
            onClick={onDeleteAll}
            className="bg-red-500/20 text-red-400 hover:bg-red-500/30 border border-red-500/30"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Deletar
          </Button>

          <div className="h-6 w-px bg-[#1a2847]" />

          <Button
            size="sm"
            variant="ghost"
            onClick={onClearSelection}
            className="text-gray-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}