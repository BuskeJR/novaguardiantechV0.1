import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Shield, Trash2, Activity, Layers } from "lucide-react";
import { motion } from "framer-motion";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const categoryColors = {
  social_media: "bg-blue-500/10 text-blue-400 border-blue-500/30",
  streaming: "bg-purple-500/10 text-purple-400 border-purple-500/30",
  gaming: "bg-green-500/10 text-green-400 border-green-500/30",
  adult: "bg-red-500/10 text-red-400 border-red-500/30",
  gambling: "bg-orange-500/10 text-orange-400 border-orange-500/30",
  malware: "bg-red-700/10 text-red-600 border-red-700/30",
  phishing: "bg-red-600/10 text-red-500 border-red-600/30",
  ads: "bg-yellow-500/10 text-yellow-400 border-yellow-500/30",
  tracking: "bg-indigo-500/10 text-indigo-400 border-indigo-500/30",
  other: "bg-gray-500/10 text-gray-400 border-gray-500/30",
};

export default function DomainCard({ domain, onToggle, onDelete }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.03, y: -5 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      <Card className={`bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] hover:border-[#1284e1]/50 transition-all duration-300 shadow-xl hover:shadow-2xl ${
        domain.isActive ? 'hover:shadow-green-500/20' : 'hover:shadow-gray-500/20'
      } overflow-hidden group relative`}>
        {/* Animated glow effect */}
        <div className={`absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 ${
          domain.isActive 
            ? 'bg-gradient-to-br from-green-500/5 to-transparent' 
            : 'bg-gradient-to-br from-gray-500/5 to-transparent'
        }`} />
        
        {/* Shine effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />

        <CardHeader className="flex flex-row items-start justify-between pb-3 relative z-10">
          <div className="flex items-start gap-3 flex-1 min-w-0">
            <motion.div 
              className={`w-12 h-12 rounded-xl flex items-center justify-center shadow-lg ${
                domain.isActive 
                  ? 'bg-gradient-to-br from-green-500/20 to-green-600/10 shadow-green-500/20' 
                  : 'bg-gradient-to-br from-gray-500/20 to-gray-600/10 shadow-gray-500/20'
              }`}
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.6 }}
            >
              <Shield className={`w-6 h-6 ${domain.isActive ? 'text-green-400' : 'text-gray-400'}`} />
            </motion.div>
            <div className="flex-1 min-w-0">
              <CardTitle className="text-white text-base mb-2 break-all group-hover:text-[#1284e1] transition-colors">
                {domain.domain}
              </CardTitle>
              <Badge 
                variant="outline" 
                className={`${categoryColors[domain.category] || categoryColors.other} shadow-lg font-medium`}
              >
                {domain.category?.replace(/_/g, ' ')}
              </Badge>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="relative z-10">
          {domain.description && (
            <div className="mb-4 p-3 bg-[#1a2847]/50 rounded-lg border border-[#1a2847]">
              <p className="text-gray-400 text-sm">{domain.description}</p>
            </div>
          )}
          
          <div className="flex items-center justify-between mb-4 p-3 bg-[#1a2847]/30 rounded-lg">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#1284e1]" />
              <span className="text-sm text-gray-300 font-medium">
                {domain.blockCount || 0} bloqueios
              </span>
            </div>
            <motion.div whileTap={{ scale: 0.95 }}>
              <Switch
                checked={domain.isActive}
                onCheckedChange={onToggle}
                className="data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-green-500 data-[state=checked]:to-green-600"
              />
            </motion.div>
          </div>

          <div className="flex items-center justify-between pt-3 border-t border-[#1a2847]">
            <div className="flex items-center gap-2 text-xs text-gray-500">
              <Layers className="w-3 h-3" />
              <span>{domain.variations?.length || 0} variações</span>
            </div>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
                <AlertDialogHeader>
                  <AlertDialogTitle className="text-white">Remover Domínio</AlertDialogTitle>
                  <AlertDialogDescription className="text-gray-400">
                    Tem certeza que deseja remover <span className="font-semibold text-white">{domain.domain}</span>? 
                    Esta ação não pode ser desfeita.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]">
                    Cancelar
                  </AlertDialogCancel>
                  <AlertDialogAction
                    onClick={onDelete}
                    className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white shadow-lg shadow-red-500/20"
                  >
                    Remover
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}