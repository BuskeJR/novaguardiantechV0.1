import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

const colorClasses = {
  blue: {
    bg: "from-blue-500/20 to-blue-600/5",
    icon: "text-blue-400",
    border: "border-blue-500/30",
    glow: "shadow-blue-500/20"
  },
  red: {
    bg: "from-red-500/20 to-red-600/5",
    icon: "text-red-400",
    border: "border-red-500/30",
    glow: "shadow-red-500/20"
  },
  green: {
    bg: "from-green-500/20 to-green-600/5",
    icon: "text-green-400",
    border: "border-green-500/30",
    glow: "shadow-green-500/20"
  },
  purple: {
    bg: "from-purple-500/20 to-purple-600/5",
    icon: "text-purple-400",
    border: "border-purple-500/30",
    glow: "shadow-purple-500/20"
  }
};

export default function StatsCard({ title, value, icon: Icon, color, isLoading, trend }) {
  const colors = colorClasses[color] || colorClasses.blue;

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -5 }}
      transition={{ type: "spring", stiffness: 400, damping: 17 }}
    >
      <Card className={`bg-gradient-to-br ${colors.bg} border-[#1a2847] hover:border-[#1284e1]/50 transition-all duration-300 backdrop-blur-xl shadow-xl ${colors.glow} hover:shadow-2xl group relative overflow-hidden`}>
        {/* Animated background effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
        
        <CardHeader className="flex flex-row items-center justify-between pb-2 relative z-10">
          <CardTitle className="text-sm font-medium text-gray-400">
            {title}
          </CardTitle>
          <motion.div 
            className={`p-3 rounded-xl bg-gradient-to-br from-[#1a2847] to-[#0a1128] border ${colors.border} ${colors.glow} shadow-lg`}
            whileHover={{ rotate: 360 }}
            transition={{ duration: 0.6 }}
          >
            <Icon className={`w-5 h-5 ${colors.icon}`} />
          </motion.div>
        </CardHeader>
        <CardContent className="relative z-10">
          {isLoading ? (
            <Skeleton className="h-10 w-24 bg-[#1a2847]" />
          ) : (
            <>
              <motion.div 
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-3xl font-bold text-white mb-2"
              >
                {value.toLocaleString()}
              </motion.div>
              {trend && (
                <div className="flex items-center gap-1 text-green-400 text-sm">
                  <TrendingUp className="w-3 h-3" />
                  <span>{trend}</span>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}