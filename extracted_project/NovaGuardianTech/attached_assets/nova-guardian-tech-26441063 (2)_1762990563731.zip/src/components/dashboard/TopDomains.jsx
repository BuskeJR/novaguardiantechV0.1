import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, TrendingUp, Award, Medal, Trophy } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";

const medals = [Trophy, Award, Medal];

export default function TopDomains({ domains, isLoading }) {
  return (
    <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] shadow-xl backdrop-blur-xl overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/5 rounded-full blur-2xl" />
      <CardHeader className="relative z-10">
        <CardTitle className="text-white flex items-center gap-2">
          <div className="p-2 bg-gradient-to-br from-yellow-500/20 to-orange-500/10 rounded-lg">
            <TrendingUp className="w-5 h-5 text-yellow-400" />
          </div>
          Top 5 Domínios
        </CardTitle>
      </CardHeader>
      <CardContent className="relative z-10">
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center justify-between">
                <Skeleton className="h-4 w-32 bg-[#1a2847]" />
                <Skeleton className="h-6 w-16 bg-[#1a2847]" />
              </div>
            ))}
          </div>
        ) : domains.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200 }}
            >
              <Shield className="w-16 h-16 mx-auto mb-4 opacity-20" />
            </motion.div>
            <p>Nenhum domínio bloqueado ainda</p>
          </div>
        ) : (
          <div className="space-y-3">
            {domains.map((domain, index) => {
              const MedalIcon = medals[index] || Shield;
              return (
                <motion.div
                  key={domain.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02, x: 5 }}
                  className="group"
                >
                  <div className="flex items-center justify-between p-3 rounded-xl bg-[#1a2847]/50 hover:bg-[#1a2847] transition-all duration-300 border border-transparent hover:border-[#1284e1]/30">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm shadow-lg transition-transform group-hover:scale-110 ${
                        index === 0 ? 'bg-gradient-to-br from-yellow-500/30 to-orange-500/20 text-yellow-400 shadow-yellow-500/20' :
                        index === 1 ? 'bg-gradient-to-br from-gray-400/30 to-gray-500/20 text-gray-300 shadow-gray-500/20' :
                        index === 2 ? 'bg-gradient-to-br from-orange-600/30 to-orange-700/20 text-orange-400 shadow-orange-500/20' :
                        'bg-gradient-to-br from-blue-500/30 to-blue-600/20 text-blue-400 shadow-blue-500/20'
                      }`}>
                        <MedalIcon className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-white font-semibold text-sm group-hover:text-[#1284e1] transition-colors">
                          {domain.domain}
                        </p>
                        <p className="text-gray-400 text-xs capitalize">
                          {domain.category?.replace(/_/g, ' ')}
                        </p>
                      </div>
                    </div>
                    <Badge 
                      variant="outline" 
                      className="bg-red-500/10 text-red-400 border-red-500/30 font-bold shadow-lg shadow-red-500/10"
                    >
                      {domain.blockCount || 0}
                    </Badge>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}