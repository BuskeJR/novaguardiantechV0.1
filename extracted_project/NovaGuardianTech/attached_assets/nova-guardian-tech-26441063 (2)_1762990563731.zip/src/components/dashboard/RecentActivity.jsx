import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollText, Clock, CheckCircle, XCircle, Plus, Minus, Power } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Skeleton } from "@/components/ui/skeleton";
import { motion, AnimatePresence } from "framer-motion";

const actionConfig = {
  domain_added: {
    color: "bg-green-500/10 text-green-400 border-green-500/30",
    icon: Plus,
    label: "Adicionado"
  },
  domain_removed: {
    color: "bg-red-500/10 text-red-400 border-red-500/30",
    icon: Minus,
    label: "Removido"
  },
  domain_activated: {
    color: "bg-blue-500/10 text-blue-400 border-blue-500/30",
    icon: CheckCircle,
    label: "Ativado"
  },
  domain_deactivated: {
    color: "bg-gray-500/10 text-gray-400 border-gray-500/30",
    icon: XCircle,
    label: "Desativado"
  },
  domain_blocked: {
    color: "bg-orange-500/10 text-orange-400 border-orange-500/30",
    icon: Power,
    label: "Bloqueado"
  },
  user_created: {
    color: "bg-purple-500/10 text-purple-400 border-purple-500/30",
    icon: Plus,
    label: "Usuário Criado"
  },
  user_updated: {
    color: "bg-indigo-500/10 text-indigo-400 border-indigo-500/30",
    icon: CheckCircle,
    label: "Usuário Atualizado"
  },
};

export default function RecentActivity({ logs, isLoading }) {
  return (
    <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] shadow-xl backdrop-blur-xl">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <div className="p-2 bg-gradient-to-br from-[#1284e1]/20 to-[#0d5fb8]/10 rounded-lg">
            <ScrollText className="w-5 h-5 text-[#1284e1]" />
          </div>
          Atividade Recente
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-start gap-4">
                <Skeleton className="h-12 w-12 rounded-xl bg-[#1a2847]" />
                <div className="flex-1">
                  <Skeleton className="h-4 w-full mb-2 bg-[#1a2847]" />
                  <Skeleton className="h-3 w-32 bg-[#1a2847]" />
                </div>
              </div>
            ))}
          </div>
        ) : logs.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 200 }}
            >
              <Clock className="w-16 h-16 mx-auto mb-4 opacity-20" />
            </motion.div>
            <p>Nenhuma atividade registrada</p>
          </div>
        ) : (
          <div className="space-y-3">
            <AnimatePresence>
              {logs.map((log, index) => {
                const config = actionConfig[log.action] || actionConfig.domain_added;
                const ActionIcon = config.icon;
                
                return (
                  <motion.div
                    key={log.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ delay: index * 0.05 }}
                    whileHover={{ scale: 1.01, x: 5 }}
                    className="group"
                  >
                    <div className="flex items-start gap-4 p-4 rounded-xl bg-[#1a2847]/50 hover:bg-[#1a2847] transition-all duration-300 border border-transparent hover:border-[#1284e1]/30">
                      <motion.div 
                        className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#1a2847] to-[#0a1128] flex items-center justify-center shadow-lg border border-[#1284e1]/20"
                        whileHover={{ rotate: 360 }}
                        transition={{ duration: 0.6 }}
                      >
                        <ActionIcon className="w-5 h-5 text-[#1284e1]" />
                      </motion.div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                          <Badge variant="outline" className={`${config.color} shadow-lg`}>
                            {config.label}
                          </Badge>
                          {log.domain && (
                            <Badge variant="outline" className="bg-[#1284e1]/10 text-[#1284e1] border-[#1284e1]/30">
                              {log.domain}
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-gray-400">
                          <span className="font-medium text-gray-300">{log.userEmail}</span>
                          <span>•</span>
                          <span>{format(new Date(log.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}</span>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </CardContent>
    </Card>
  );
}