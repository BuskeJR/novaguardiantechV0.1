import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Clock, Edit, Trash2, Calendar, Shield, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const weekDays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

const categoryLabels = {
  social_media: "Redes Sociais",
  streaming: "Streaming",
  gaming: "Jogos",
  adult: "Adulto",
  gambling: "Apostas",
  malware: "Malware",
  ads: "Anúncios",
  other: "Outros"
};

export default function ScheduleList({ schedules, domains, isLoading, onEdit, onToggle, onDelete }) {
  const getDomainNames = (domainIds) => {
    if (!domainIds || domainIds.length === 0) return [];
    return domains
      .filter(d => domainIds.includes(d.id))
      .map(d => d.domain)
      .slice(0, 3);
  };

  if (isLoading) {
    return (
      <div className="grid gap-6">
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="bg-[#01081c] border-[#1a2847] animate-pulse">
            <CardContent className="p-6">
              <div className="h-6 bg-[#1a2847] rounded w-1/3 mb-4" />
              <div className="h-4 bg-[#1a2847] rounded w-2/3" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (schedules.length === 0) {
    return (
      <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847]">
        <CardContent className="p-12 text-center">
          <div className="w-20 h-20 mx-auto mb-6 bg-indigo-500/10 rounded-2xl flex items-center justify-center">
            <Clock className="w-10 h-10 text-indigo-400" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">Nenhum agendamento configurado</h3>
          <p className="text-gray-400 max-w-md mx-auto">
            Crie agendamentos para bloquear ou permitir domínios em horários específicos
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-6">
      {schedules.map((schedule, index) => {
        const domainNames = getDomainNames(schedule.domainIds);
        const hasCategories = schedule.categories && schedule.categories.length > 0;
        const hasDomains = schedule.domainIds && schedule.domainIds.length > 0;

        return (
          <motion.div
            key={schedule.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] hover:border-indigo-500/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-xl font-bold text-white">{schedule.name}</h3>
                      <Badge
                        variant="outline"
                        className={
                          schedule.action === "block"
                            ? "bg-red-500/10 text-red-400 border-red-500/30"
                            : "bg-green-500/10 text-green-400 border-green-500/30"
                        }
                      >
                        {schedule.action === "block" ? (
                          <><Shield className="w-3 h-3 mr-1" /> Bloquear</>
                        ) : (
                          <><CheckCircle className="w-3 h-3 mr-1" /> Permitir</>
                        )}
                      </Badge>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-gray-400 mb-3">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        <span>
                          {schedule.startTime || "00:00"} - {schedule.endTime || "23:59"}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span>
                          {schedule.daysOfWeek && schedule.daysOfWeek.length > 0
                            ? schedule.daysOfWeek.map(day => weekDays[day]).join(", ")
                            : "Todos os dias"}
                        </span>
                      </div>
                    </div>

                    {hasCategories && (
                      <div className="flex flex-wrap gap-2 mb-3">
                        <span className="text-xs text-gray-400">Categorias:</span>
                        {schedule.categories.map(cat => (
                          <Badge
                            key={cat}
                            variant="outline"
                            className="bg-blue-500/10 text-blue-400 border-blue-500/30 text-xs"
                          >
                            {categoryLabels[cat] || cat}
                          </Badge>
                        ))}
                      </div>
                    )}

                    {hasDomains && (
                      <div className="flex flex-wrap gap-2">
                        <span className="text-xs text-gray-400">Domínios:</span>
                        {domainNames.map(domain => (
                          <Badge
                            key={domain}
                            variant="outline"
                            className="bg-purple-500/10 text-purple-400 border-purple-500/30 text-xs"
                          >
                            {domain}
                          </Badge>
                        ))}
                        {schedule.domainIds && schedule.domainIds.length > 3 && (
                          <Badge
                            variant="outline"
                            className="bg-gray-500/10 text-gray-400 border-gray-500/30 text-xs"
                          >
                            +{schedule.domainIds.length - 3} mais
                          </Badge>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-3">
                    <Switch
                      checked={schedule.isActive}
                      onCheckedChange={(checked) => onToggle(schedule.id, checked)}
                      className="data-[state=checked]:bg-indigo-500"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-4 border-t border-[#1a2847]">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onEdit(schedule)}
                    className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Editar
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Excluir
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent className="bg-[#01081c] border-[#1a2847]">
                      <AlertDialogHeader>
                        <AlertDialogTitle className="text-white">Excluir Agendamento</AlertDialogTitle>
                        <AlertDialogDescription className="text-gray-400">
                          Tem certeza que deseja excluir o agendamento "{schedule.name}"?
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]">
                          Cancelar
                        </AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => onDelete(schedule.id)}
                          className="bg-red-500 hover:bg-red-600 text-white"
                        >
                          Excluir
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}