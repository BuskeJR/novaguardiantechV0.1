import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Mail, UserPlus, Shield, User } from "lucide-react";

export default function InviteUserDialog({ open, onClose, onInvite, isLoading }) {
  const [formData, setFormData] = useState({
    email: "",
    role: "user",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onInvite(formData);
    setFormData({ email: "", role: "user" });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] text-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-purple-400" />
            Convidar Novo Usuário
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Envie um convite por email para adicionar um novo membro à sua organização
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="space-y-6 py-4">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-gray-300">Email *</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  id="email"
                  type="email"
                  placeholder="usuario@exemplo.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  className="pl-10 bg-[#1a2847] border-[#1a2847] text-white focus:border-purple-500"
                />
              </div>
              <p className="text-xs text-gray-500">
                Um email de convite será enviado para este endereço
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="role" className="text-gray-300">Papel</Label>
              <Select
                value={formData.role}
                onValueChange={(value) => setFormData({ ...formData, role: value })}
              >
                <SelectTrigger className="bg-[#1a2847] border-[#1a2847] text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#01081c] border-[#1a2847] text-white">
                  <SelectItem value="user">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-blue-400" />
                      <div>
                        <div className="font-medium">Usuário</div>
                        <div className="text-xs text-gray-400">Acesso padrão ao sistema</div>
                      </div>
                    </div>
                  </SelectItem>
                  <SelectItem value="admin">
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-purple-400" />
                      <div>
                        <div className="font-medium">Administrador</div>
                        <div className="text-xs text-gray-400">Acesso completo e gerenciamento</div>
                      </div>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
              <h4 className="text-blue-400 font-medium mb-2 text-sm">O que acontece depois?</h4>
              <ul className="text-xs text-gray-400 space-y-1">
                <li>✓ Um email será enviado para o endereço fornecido</li>
                <li>✓ O convite expira em 7 dias</li>
                <li>✓ O usuário poderá criar sua senha ao aceitar</li>
                <li>✓ Ele será automaticamente adicionado à sua organização</li>
              </ul>
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={isLoading || !formData.email}
              className="bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white shadow-lg shadow-purple-500/20"
            >
              <Mail className="w-4 h-4 mr-2" />
              {isLoading ? "Enviando..." : "Enviar Convite"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}