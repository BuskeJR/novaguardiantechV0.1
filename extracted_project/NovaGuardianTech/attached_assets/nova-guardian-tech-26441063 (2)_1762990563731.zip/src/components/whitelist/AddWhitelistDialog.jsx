import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Globe } from "lucide-react";

export default function AddWhitelistDialog({ open, onClose, onAdd, isLoading }) {
  const [formData, setFormData] = useState({
    domain: "",
    description: "",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onAdd(formData);
    setFormData({ domain: "", description: "" });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] text-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="w-5 h-5 text-green-400" />
            Adicionar à Lista Branca
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Este domínio será sempre permitido, mesmo que esteja em uma categoria bloqueada
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="domain">Domínio *</Label>
              <div className="relative">
                <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  id="domain"
                  placeholder="exemplo.com"
                  value={formData.domain}
                  onChange={(e) => setFormData({ ...formData, domain: e.target.value })}
                  required
                  className="pl-10 bg-[#1a2847] border-[#1a2847] text-white focus:border-green-500"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Motivo (opcional)</Label>
              <Textarea
                id="description"
                placeholder="Por que este domínio deve ser permitido?"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-[#1a2847] border-[#1a2847] text-white focus:border-green-500"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={isLoading || !formData.domain}
              className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white shadow-lg shadow-green-500/20"
            >
              <Plus className="w-4 h-4 mr-2" />
              {isLoading ? "Adicionando..." : "Adicionar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}