import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit, Trash2, Shield, User } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function UserTable({ users, currentUserId, isLoading, onEdit, onDelete }) {
  if (isLoading) {
    return (
      <Table>
        <TableHeader>
          <TableRow className="border-[#1a2847] hover:bg-transparent">
            <TableHead className="text-gray-400">Usuário</TableHead>
            <TableHead className="text-gray-400">Email</TableHead>
            <TableHead className="text-gray-400">Empresa</TableHead>
            <TableHead className="text-gray-400">Papel</TableHead>
            <TableHead className="text-gray-400">Status</TableHead>
            <TableHead className="text-gray-400">Criado em</TableHead>
            <TableHead className="text-gray-400">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {[...Array(5)].map((_, i) => (
            <TableRow key={i} className="border-[#1a2847]">
              <TableCell><Skeleton className="h-4 w-32 bg-[#1a2847]" /></TableCell>
              <TableCell><Skeleton className="h-4 w-40 bg-[#1a2847]" /></TableCell>
              <TableCell><Skeleton className="h-4 w-32 bg-[#1a2847]" /></TableCell>
              <TableCell><Skeleton className="h-6 w-20 bg-[#1a2847]" /></TableCell>
              <TableCell><Skeleton className="h-6 w-20 bg-[#1a2847]" /></TableCell>
              <TableCell><Skeleton className="h-4 w-24 bg-[#1a2847]" /></TableCell>
              <TableCell><Skeleton className="h-8 w-20 bg-[#1a2847]" /></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    );
  }

  return (
    <Table>
      <TableHeader>
        <TableRow className="border-[#1a2847] hover:bg-transparent">
          <TableHead className="text-gray-400">Usuário</TableHead>
          <TableHead className="text-gray-400">Email</TableHead>
          <TableHead className="text-gray-400">Empresa</TableHead>
          <TableHead className="text-gray-400">Papel</TableHead>
          <TableHead className="text-gray-400">Status</TableHead>
          <TableHead className="text-gray-400">Criado em</TableHead>
          <TableHead className="text-gray-400">Ações</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {users.map((user) => (
          <TableRow key={user.id} className="border-[#1a2847] hover:bg-[#1a2847]">
            <TableCell>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#1284e1] to-[#0d5fb8] flex items-center justify-center text-white font-semibold">
                  {user.full_name?.charAt(0).toUpperCase() || "U"}
                </div>
                <div>
                  <p className="text-white font-medium">{user.full_name || "Sem nome"}</p>
                  {user.id === currentUserId && (
                    <p className="text-xs text-gray-400">(Você)</p>
                  )}
                </div>
              </div>
            </TableCell>
            <TableCell className="text-gray-300">{user.email}</TableCell>
            <TableCell className="text-gray-300">{user.company || "-"}</TableCell>
            <TableCell>
              <Badge 
                variant="outline" 
                className={user.role === 'admin' 
                  ? "bg-purple-500/10 text-purple-400 border-purple-500/20" 
                  : "bg-blue-500/10 text-blue-400 border-blue-500/20"
                }
              >
                {user.role === 'admin' ? (
                  <><Shield className="w-3 h-3 mr-1" /> Admin</>
                ) : (
                  <><User className="w-3 h-3 mr-1" /> Usuário</>
                )}
              </Badge>
            </TableCell>
            <TableCell>
              <Badge 
                variant="outline"
                className={
                  user.status === 'active' 
                    ? "bg-green-500/10 text-green-400 border-green-500/20"
                    : user.status === 'suspended'
                    ? "bg-red-500/10 text-red-400 border-red-500/20"
                    : "bg-gray-500/10 text-gray-400 border-gray-500/20"
                }
              >
                {user.status === 'active' ? 'Ativo' : user.status === 'suspended' ? 'Suspenso' : 'Inativo'}
              </Badge>
            </TableCell>
            <TableCell className="text-gray-400">
              {format(new Date(user.created_date), "dd/MM/yyyy", { locale: ptBR })}
            </TableCell>
            <TableCell>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onEdit(user)}
                  className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                >
                  <Edit className="w-4 h-4" />
                </Button>
                {user.id !== currentUserId && (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent className="bg-[#01081c] border-[#1a2847]">
                      <AlertDialogHeader>
                        <AlertDialogTitle className="text-white">Remover Usuário</AlertDialogTitle>
                        <AlertDialogDescription className="text-gray-400">
                          Tem certeza que deseja remover <span className="font-semibold text-white">{user.full_name}</span>?
                          Esta ação não pode ser desfeita.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]">
                          Cancelar
                        </AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => onDelete(user.id)}
                          className="bg-red-500 hover:bg-red-600 text-white"
                        >
                          Remover
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                )}
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}