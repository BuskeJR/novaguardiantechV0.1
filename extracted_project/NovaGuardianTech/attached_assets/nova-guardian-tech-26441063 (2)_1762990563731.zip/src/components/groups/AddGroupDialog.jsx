import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Layers } from "lucide-react";

const COLORS = [
  "#1284e1", "#10b981", "#f59e0b", "#ef4444", 
  "#8b5cf6", "#ec4899", "#06b6d4", "#84cc16"
];

export default function AddGroupDialog({ open, onClose, group, domains, onSave, isLoading }) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    color: COLORS[0],
    domainIds: [],
    isActive: true,
  });

  useEffect(() => {
    if (group) {
      setFormData({
        name: group.name || "",
        description: group.description || "",
        color: group.color || COLORS[0],
        domainIds: group.domainIds || [],
        isActive: group.isActive !== undefined ? group.isActive : true,
      });
    } else {
      setFormData({
        name: "",
        description: "",
        color: COLORS[0],
        domainIds: [],
        isActive: true,
      });
    }
  }, [group, open]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  const toggleDomain = (domainId) => {
    if (formData.domainIds.includes(domainId)) {
      setFormData({
        ...formData,
        domainIds: formData.domainIds.filter(id => id !== domainId)
      });
    } else {
      setFormData({
        ...formData,
        domainIds: [...formData.domainIds, domainId]
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-gradient-to-br from-[#01081c] to-[#0a1128] border-[#1a2847] text-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-amber-400" />
            {group ? "Editar Grupo" : "Novo Grupo"}
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Organize seus domínios em grupos para melhor gerenciamento
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="space-y-6 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome do Grupo *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="bg-[#1a2847] border-[#1a2847] text-white"
                placeholder="Ex: Redes Sociais Empresariais"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-[#1a2847] border-[#1a2847] text-white"
                placeholder="Descrição opcional do grupo"
              />
            </div>

            <div className="space-y-2">
              <Label>Cor do Grupo</Label>
              <div className="flex gap-3">
                {COLORS.map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setFormData({ ...formData, color })}
                    className={`w-10 h-10 rounded-lg transition-all ${
                      formData.color === color 
                        ? 'ring-2 ring-offset-2 ring-offset-[#01081c] scale-110' 
                        : 'hover:scale-105'
                    }`}
                    style={{ 
                      backgroundColor: color,
                      ringColor: color
                    }}
                  />
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Domínios no Grupo ({formData.domainIds.length} selecionados)</Label>
              <div className="max-h-64 overflow-y-auto p-3 bg-[#1a2847]/50 rounded-lg space-y-2">
                {domains.length === 0 ? (
                  <p className="text-sm text-gray-400 text-center py-4">
                    Nenhum domínio disponível
                  </p>
                ) : (
                  domains.map((domain) => (
                    <div
                      key={domain.id}
                      className="flex items-center space-x-3 p-2 rounded hover:bg-[#1a2847] cursor-pointer"
                      onClick={() => toggleDomain(domain.id)}
                    >
                      <Checkbox
                        checked={formData.domainIds.includes(domain.id)}
                        className="border-gray-500"
                      />
                      <div className="flex-1">
                        <span className="text-sm text-white">{domain.domain}</span>
                        {domain.category && (
                          <span className="text-xs text-gray-400 ml-2">
                            ({domain.category.replace(/_/g, ' ')})
                          </span>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="bg-transparent border-[#1a2847] text-white hover:bg-[#1a2847]"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white shadow-lg shadow-amber-500/20"
            >
              <Plus className="w-4 h-4 mr-2" />
              {isLoading ? "Salvando..." : group ? "Atualizar" : "Criar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}