import { base44 } from './base44Client';


export const Domain = base44.entities.Domain;

export const BlockLog = base44.entities.BlockLog;

export const Invitation = base44.entities.Invitation;

export const Whitelist = base44.entities.Whitelist;

export const Notification = base44.entities.Notification;

export const BlockSchedule = base44.entities.BlockSchedule;

export const DomainGroup = base44.entities.DomainGroup;

export const SystemConfig = base44.entities.SystemConfig;

export const Subscription = base44.entities.Subscription;

export const Alert = base44.entities.Alert;



// auth sdk:
export const User = base44.auth;